<?php
declare(strict_types=1);
namespace hcf\blocks;

use hcf\{AlpineCore, AlpinePlayer, tile\BrewingStand as BrewingStandTile};
use pocketmine\block\{Block, BrewingStand as PMBrewingStand};
use pocketmine\item\Item;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\{CompoundTag, IntTag, StringTag};
use pocketmine\Player;
use pocketmine\tile\Tile;
use pocketmine\utils\TextFormat as TF;

class BrewingStand extends PMBrewingStand
{

    public function place(Item $item, Block $blockReplace, Block $blockClicked, int $face, Vector3 $clickVector, Player $player = \null): bool
    {
        $parent = parent::place($item, $blockReplace, $blockClicked, $face, $clickVector, $player);
        if (!$blockReplace->getSide(Vector3::SIDE_DOWN)->isTransparent()) {
            $nbt = new CompoundTag("", [new StringTag(Tile::TAG_ID, Tile::BREWING_STAND), new IntTag(Tile::TAG_X, (int)$this->x), new IntTag(Tile::TAG_Y, (int)$this->y), new IntTag(Tile::TAG_Z, (int)$this->z),]);
            $nbt->setInt(BrewingStandTile::TAG_BREW_TIME, BrewingStandTile::MAX_BREW_TIME);
            $nbt->setInt("Bottles", 0);
            $nbt->setInt("NetherWart", 0);
            $nbt->setInt("Sugar", 0);
            $nbt->setInt("MagmaCream", 0);
            $nbt->setInt("FermentedSpiderEye", 0);
            $nbt->setInt("GoldenCarrot", 0);
            $nbt->setInt("Redstone", 0);
            $nbt->setInt("Glowstone", 0);
            $nbt->setInt("Gunpowder", 0);
            $nbt->setInt("GlisteringMelon", 0);
            $nbt->setInt(BrewingStandTile::TAG_SETTINGS, BrewingStandTile::NO_SETTINGS);
            if ($item->hasCustomName()) $nbt->setString("CustomName", $item->getCustomName());
            new BrewingStandTile($player->getLevel(), $nbt);
        }
        return $parent;
    }

    public function getLightLevel(): int
    {
        return 1;
    }

    public function getBlastResistance(): float
    {
        return 2.5;
    }

    public function onActivate(Item $item, Player $player = \null): bool
    {
        if ($player instanceof AlpinePlayer) {
            $parent = parent::onActivate($item, $player);
            $tile = $player->getLevel()->getTile($this);
            if ($tile instanceof \hcf\tile\BrewingStand) {
                if ($item->getId() == Item::POTION || $item->getId() == Item::GLASS_BOTTLE) {
                    $tile->setPotion($tile->getPotion() + $item->getCount());
                    $player->getInventory()->setItemInHand(Item::get(Item::AIR));
                    $player->sendMessage(TF::GREEN . " Added x" . $item->getCount() . " " . $item->getName());
                } elseif ($item->getId() == Item::NETHER_WART) {
                    $tile->setNetherWart($tile->getNetherWart() + $item->getCount());
                    $player->getInventory()->setItemInHand(Item::get(Item::AIR));
                    $player->sendMessage(TF::GREEN . " Added x" . $item->getCount() . " " . $item->getName());
                } elseif ($item->getId() == Item::SUGAR) {
                    $tile->setSugar($tile->getSugar() + $item->getCount());
                    $player->getInventory()->setItemInHand(Item::get(Item::AIR));
                    $player->sendMessage(TF::GREEN . " Added x" . $item->getCount() . " " . $item->getName());
                } elseif ($item->getId() == Item::MAGMA_CREAM) {
                    $tile->setMagmaCream($tile->getMagmaCream() + $item->getCount());
                    $player->getInventory()->setItemInHand(Item::get(Item::AIR));
                    $player->sendMessage(TF::GREEN . " Added x" . $item->getCount() . " " . $item->getName());
                } elseif ($item->getId() == Item::FERMENTED_SPIDER_EYE) {
                    $tile->setFermentedSpiderEye($tile->getFermentedSpiderEye() + $item->getCount());
                    $player->getInventory()->setItemInHand(Item::get(Item::AIR));
                    $player->sendMessage(TF::GREEN . " Added x" . $item->getCount() . " " . $item->getName());
                } elseif ($item->getId() == Item::GOLDEN_CARROT) {
                    $tile->setGoldenCarrot($tile->getGoldenCarrot() + $item->getCount());
                    $player->getInventory()->setItemInHand(Item::get(Item::AIR));
                    $player->sendMessage(TF::GREEN . " Added x" . $item->getCount() . " " . $item->getName());
                } elseif ($item->getId() == Item::GLOWSTONE_DUST) {
                    $tile->setGlowstoneDust($tile->getGlowstoneDust() + $item->getCount());
                    $player->getInventory()->setItemInHand(Item::get(Item::AIR));
                    $player->sendMessage(TF::GREEN . " Added x" . $item->getCount() . " " . $item->getName());
                } elseif ($item->getId() == Item::GUNPOWDER) {
                    $tile->setGunpowder($tile->getGunpowder() + $item->getCount());
                    $player->getInventory()->setItemInHand(Item::get(Item::AIR));
                    $player->sendMessage(TF::GREEN . " Added x" . $item->getCount() . " " . $item->getName());
                } elseif ($item->getId() == Item::REDSTONE) {
                    $tile->setRedstone($tile->getRedstone() + $item->getCount());
                    $player->getInventory()->setItemInHand(Item::get(Item::AIR));
                    $player->sendMessage(TF::GREEN . " Added x" . $item->getCount() . " " . $item->getName());
                } elseif ($item->getId() == Item::GLISTERING_MELON) {
                    $tile->setGlisteringMelon($tile->getGlisteringMelon() + $item->getCount());
                    $player->getInventory()->setItemInHand(Item::get(Item::AIR));
                    $player->sendMessage(TF::GREEN . " Added x" . $item->getCount() . " " . $item->getName());
                } else {
                    $tile->sendMenu($player);
                }
            } else {
                $nbt = new CompoundTag("", [new StringTag(Tile::TAG_ID, Tile::BREWING_STAND), new IntTag(Tile::TAG_X, (int)$this->x), new IntTag(Tile::TAG_Y, (int)$this->y), new IntTag(Tile::TAG_Z, (int)$this->z),]);
                $nbt->setInt(BrewingStandTile::TAG_BREW_TIME, BrewingStandTile::MAX_BREW_TIME);
                $nbt->setInt(BrewingStandTile::TAG_SETTINGS, BrewingStandTile::NO_SETTINGS);
                if ($item->hasCustomName()) {
                    $nbt->setString("CustomName", $item->getCustomName());
                }
                $nbt->setInt("Bottles", 0);
                $nbt->setInt("NetherWart", 0);
                $nbt->setInt("Sugar", 0);
                $nbt->setInt("MagmaCream", 0);
                $nbt->setInt("FermentedSpiderEye", 0);
                $nbt->setInt("GoldenCarrot", 0);
                $nbt->setInt("Redstone", 0);
                $nbt->setInt("Glowstone", 0);
                $nbt->setInt("Gunpowder", 0);
                $nbt->setInt("GlisteringMelon", 0);
                $tile = new BrewingStandTile($player->getLevel(), $nbt);
            }
            
        }
        return $parent;
    }
}