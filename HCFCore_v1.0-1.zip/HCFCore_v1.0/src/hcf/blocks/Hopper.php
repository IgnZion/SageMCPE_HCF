<?php
declare(strict_types=1);
namespace hcf\blocks;

use hcf\AlpineCore;
use hcf\tile\Tile;
use hcf\tile\Hopper as HopperTile;
use pocketmine\nbt\tag\{IntTag, ListTag, StringTag, CompoundTag};
use pocketmine\{block\Block, block\BlockToolType, block\Transparent, item\Item, math\Vector3, Player};

class Hopper extends Transparent {
    protected $id = self::HOPPER_BLOCK;

    /**
     * @param int $meta
     */
    public function __construct(int $meta = 0){
        return $this->meta = $meta;
    }

    /**
     * @return bool
     */
    public function canBeActivated(): bool {
        return true;
    }

    /**
     * @return int
     */
    public function getToolType(): int {
        return BlockToolType::TYPE_PICKAXE;
    }

    /**
     * @return string
     */
    public function getName(): string {
        return "Hopper";
    }

    /**
     * @return float
     */
    public function getHardness(): float {
        return 3;
    }

    /**
     * @return float
     */
    public function getBlastResistance(): float {
        return 24;
    }

    /**
     * Item $item
     * Player $player
     * @return bool
     */
    public function onActivate(Item $item, Player $player = null): bool {
        if($player instanceof Player){
            $tile = $this->getLevel()->getTile($this);
            if($tile instanceof HopperTile){
                if($player->isCreative()){
                    return true;
                }
                $player->addWindow($tile->getInventory());
            } else {
                $nbt = new CompoundTag("", [new ListTag("Items", []), new StringTag("id", Tile::HOPPER), new IntTag("x", $this->x), new IntTag("y", $this->y), new IntTag("z", $this->z),]);
                $tile = Tile::createTile(Tile::HOPPER, $this->getLevel(), $nbt);
                if($player->isCreative()) return true;
                $player->addWindow($tile->getInventory());
            }
        }
        return true;
    }

    /**
     * Item $item
     * Block $blockReplace
     * Block $blockClicked
     * int $face
     * Vector3 $clickVector
     * Player $player
     * @return bool
     */
    public function place(Item $item, Block $blockReplace, Block $blockClicked, int $face, Vector3 $clickVector, Player $player = null): bool {
        $faces = [0 => 0, 1 => 0, 2 => 3, 3 => 2, 4 => 5, 5 => 4];
        $this->meta = $faces[$face];
        $this->getLevel()->setBlock($blockReplace, $this, true, true);
        $nbt = new CompoundTag("", [new ListTag("Items", []), new StringTag("id", Tile::HOPPER), new IntTag("x", $this->x), new IntTag("y", $this->y), new IntTag("z", $this->z),]);
        if($item->hasCustomName()) $nbt->setString("CustomName", $item->getCustomName());
        if($item->hasCustomBlockData()){
            foreach($item->getCustomBlockData() as $key => $v){
                $nbt->{$key} = $v;
            }
        }
        Tile::createTile(Tile::HOPPER, $this->getLevel(), $nbt);
        return true;
    }

    /**
     * @param Item $item
     * @return array
     */
    public function getDrops(Item $item): array {
        return [Item::get(Item::HOPPER, 0, 1)];
    }
}