<?php
declare(strict_types=1);
namespace hcf\blocks;

use pocketmine\block\{
   Block, BlockFactory
};

class BlocksManager {
   public static function init() {
      BlockFactory::registerBlock(new Hopper(), true);
      BlockFactory::registerBlock(new Portal(), true);
      BlockFactory::registerBlock(new Obsidian(), true);
      BlockFactory::registerBlock(new EndPortal(), true);
      //BlockFactory::registerBlock(new BrewingStand(), true);
      BlockFactory::registerBlock(new EndPortalFrame(), true);
      //BlockFactory::registerBlock(new MonsterSpawner(), true);

   }
}