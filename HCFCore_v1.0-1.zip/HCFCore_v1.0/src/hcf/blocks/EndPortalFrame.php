<?php
declare(strict_types=1);
namespace hcf\blocks;

use hcf\{AlpineCore, AlpinePlayer};

use pocketmine\Player;
use pocketmine\item\Item;
use pocketmine\math\Vector3;
use pocketmine\block\{Block, EndPortalFrame as PMEndPortalFrame};

class EndPortalFrame extends PMEndPortalFrame {

    /**
     * @param int $meta
     */
    public function __construct(int $meta = 0){
        return $this->meta = $meta;
    }

    /**
     * Item $item
     * Block $blockReplace
     * Block $blockClicked
     * int $face
     * Vector3 $clickVector
     * Player $player
     * @return bool
     */
    public function place(Item $item, Block $blockReplace, Block $blockClicked, int $face, Vector3 $clickVector, Player $player = null): bool {
        $faces = [0 => 3, 1 => 0, 2 => 1, 3 => 2];
        $this->meta = $faces[$player instanceof Player ? $player->getDirection() : 0];
        $this->getLevel()->setBlock($blockReplace, $this, true, true);
        return true;
    }

    /**
     * Item $item
     * Player|null $player
     * @return bool
     */
    public function onActivate(Item $item, Player $player = null): bool {
        if(($this->getDamage() & 0x04) === 0 && $player instanceof Player && $item->getId() === Item::ENDER_EYE){
            $this->setDamage($this->getDamage() + 4);
            $this->getLevel()->setBlock($this, $this, true, true);
            return true;
        }
        return false;
    }
}