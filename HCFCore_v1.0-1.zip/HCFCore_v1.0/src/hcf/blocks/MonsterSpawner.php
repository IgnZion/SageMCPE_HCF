<?php
declare(strict_types=1);
namespace hcf\blocks;

use hcf\{AlpineCore, AlpinePlayer, tile\MobSpawner};
use pocketmine\item\{Item, ItemFactory};
use pocketmine\nbt\tag\{CompoundTag, IntTag, StringTag};
use pocketmine\{tile\Tile, block\Block, block\MonsterSpawner as PMSpawner, math\Vector3, block\Solid, Player};

class MonsterSpawner extends PMSpawner {
    /**
     * @param int $meta
     */
    public function __construct(int $meta = 0){
        return $this->meta = $meta;
    }

    /**
     * @return bool
     */
    public function canBeActivated(): bool {
        return true;
    }

    /**
     * Item $item
     * Player|null $player
     * @return bool
     */
    public function onActivate(Item $item, Player $player = null): bool {
        if($item->getId() != Item::SPAWN_EGG) return false;
        $tile = $this->getLevel()->getTile($this);
        if(!$tile instanceof MobSpawner){
            $nbt = MobSpawner::createNBT($this);
            $tile = Tile::createTile(Tile::MOB_SPAWNER, $this->getLevel(), $nbt);
            if($tile instanceof MobSpawner){
                $tile->setEntityId($item->getDamage());
                if(!$player->isCreative()){
                    $item->pop();
                    $player->getInventory()->setItemInHand($item);
                }
                return true;
            }
        }
        return false;
    }

    /**
     * Item $item
     * Block $blockReplace
     * Block $blockClicked
     * int $face
     * Vector3 $clickVector
     * Player|null $player
     * @return bool
     */
    public function place(Item $item, Block $blockReplace, Block $blockClicked, int $face, Vector3 $clickVector, Player $player = null): bool {
        parent::place($item, $blockReplace, $blockClicked, $face, $clickVector, $player);
        $eID = null;
        $nbt = MobSpawner::createNBT($this, $face, $item, $player);
        if($item->getNamedTag()->getTag(MobSpawner::TAG_ENTITY_ID) !== null){
            $tags = [MobSpawner::TAG_ENTITY_ID, MobSpawner::TAG_DELAY, MobSpawner::TAG_MIN_SPAWN_DELAY, MobSpawner::TAG_MAX_SPAWN_DELAY, MobSpawner::TAG_SPAWN_COUNT, MobSpawner::TAG_SPAWN_RANGE];
            foreach($tags as $tag_name){
                $tag = $item->getNamedTag()->getTag($tag_name);
                if($tag !== null){
                    $nbt->setTag($tag);
                }
            }
        } elseif($item->getDamage() != 0){
            $nbt->setInt(MobSpawner::TAG_ENTITY_ID, $item->getDamage());
        } else {
            return true;
        }
        Tile::createTile(Tile::MOB_SPAWNER, $this->getLevel(), $nbt);
        return true;
    }

    /**
     * @param Item $item
     * @return array
     */
    public function getDrops(Item $item): array {
        return [];
    }

    /**
     * @param Item $item
     * @return array
     */
    public function getSilkTouchDrops(Item $item): array {
        return [];
    }

    /**
     * @return bool
     */
    public function isAffectedBySilkTouch(): bool {
        return false;
    }
}