<?php
declare(strict_types=1);
namespace hcf\tasks;

use hcf\{AlpinePlayer, AlpineCore};
use Heisenburger69\BurgerSpawners\Entities\Zombie;
use pocketmine\scheduler\Task;

class ZombieTask extends Task {

    private $plugin;
    private $time = 60;
    private $entity;
    private $player;

    /**
     * ZombieTask constructor.
     *
     * @param AlpineCore $plugin
     * @param Zombie $entity
     * @param AlpinePlayer $player
     */
    public function __construct(AlpineCore $plugin, Zombie $entity, AlpinePlayer $player) {
        $this->setPlugin($plugin);
        $this->entity = $entity;
        $this->player = $player;
        $this->setHandler(AlpineCore::getInstance()->getScheduler()->scheduleRepeatingTask($this, 20));
    }

    /**
     * Actions to execute when run
     *
     * @param int $currentTick
     *
     * @return void
     */
    public function onRun(int $currentTick) {
        if($this->entity instanceof Zombie and $this->entity != null) {
            $this->setTime($this->getTime() - 1);
            if ($this->getTime() <= 0) {
                $this->cancel();
                AlpineCore::getLoggerManager()->removeZombie($this->entity->getNameTag());
                if($this->entity !== null) $this->entity->close();
                return;
            }
        } else {
            $this->cancel();
        }
    }

    /**
     *
     */
    public function cancel() {
        $this->getHandler()->cancel();
    }

    /**
     * @return mixed
     */
    public function getPlugin() : AlpineCore {
        return $this->plugin;
    }

    /**
     * @param mixed $plugin
     */
    public function setPlugin(AlpineCore $plugin) {
        $this->plugin = $plugin;
    }

    /**
     * @return int
     */
    public function getTime(): int {
        return $this->time;
    }

    /**
     * @param int $time
     */
    public function setTime(int $time) {
        $this->time = $time;
    }
}