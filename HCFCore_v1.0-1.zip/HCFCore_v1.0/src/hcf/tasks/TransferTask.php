<?php
declare(strict_types=1);
namespace hcf\tasks;

use hcf\{
   AlpineCore, AlpinePlayer
};
use pocketmine\math\Vector3;
use pocketmine\scheduler\Task;

class TransferTask extends Task {

   private $plugin;
   private $player;

   /* TransferTask constructor.
    *
    * @param AlpineCore $plugin
    * @param AlpinePlayer $player
    */
   public function __construct(AlpineCore $plugin, AlpinePlayer $player){
      $this->plugin = $plugin;
      $this->setPlayer($player);
   }

   /**
    * @param int $currentTick
    * @return void
    */
   public function onRun(int $currentTick): void {
      $player = $this->getPlayer();
      if($player instanceof AlpinePlayer){
         $player->transfer("51.79.96.40", 19132);
      }
   }

   /**
     * @return mixed
     */
   public function getPlayer(): AlpinePlayer {
      return $this->player;
   }

   /**
     * @param mixed $player
     */
   public function setPlayer(AlpinePlayer $player) {
      $this->player = $player;
   }
}