<?php
declare(strict_types=1);
namespace hcf\tasks;

use hcf\{
   AlpineCore, AlpinePlayer
};
use pocketmine\scheduler\Task;
use pocketmine\{
   item\Item,
   item\ItemIds,
   entity\Effect,
   entity\EffectInstance};

class SetsTask extends Task {
   private $plugin;

   /**
    * SetsTask constructor.
    *
    * @param AlpineCore $plugin
    */
   public function __construct(AlpineCore $plugin){
      $this->plugin = $plugin;
   }

   /**
    * @param int $currentTick
    * @return void
    */
   public function onRun(int $currentTick) {
      $mgr = AlpineCore::getFactionsManager();
      $server = $this->plugin->getServer();
      $players = $server->getOnlinePlayers();
      foreach($players as $player){
         if($player instanceof AlpinePlayer){
             if($player->isDeathBanned() == "true"){
                 if($player->getDeathBanTime() <= 0){
                     $player->resetPvPTimer();
                     $player->setDeathBanned("false");
                 }
             }
             if($player->isZombieLogger() == "true"){
                 $player->setZombieLogger("false");
                 $rank = $player->getRank();
                 if($rank == "Pioneer"){
                     $time = time() + (60 * 25);
                 } elseif($rank == "Voyager"){
                     $time = time() + (60 * 15);
                 } elseif($rank == "NitroBooster"){
                     $time = time() + (60 * 20);
                 } elseif($rank == "Alpinist"){
                     $time = time() + (60 * 10);
                 } elseif($rank == "Trainee"){
                     $time = time() + (60 * 15);
                 } elseif($rank == "Mod"){ 
                     $time = time() + (60 * 10);
                 } elseif($rank == "SrMod"){
                     $time = time() + (60 * 10);
                 } elseif($rank == "Admin"){
                     $time = time() + (60 * 10);
                 } elseif($rank == "SrAdmin"){
                     $time = time() + (60 * 10);
                 } elseif($rank == "Manager"){
                     $time = time() + (60 * 10);
                 } elseif($rank == "Owner"){
                     $time = time() + (60 * 5);
                 } elseif($rank == "Partner"){
                     $time = time() + (60 * 10);
                 } elseif($rank == "YouTuber"){
                     $time = time() + (60 * 15);
                 } else {
                     $time = time() + (60 * 30);
                 }
                 $player->getInventory()->clearAll();
                 $player->getArmorInventory()->clearAll();
                 $player->setDeathBanned("true");
                 $player->setDeathBanTime($time);
                 $player->saveIt();
                 AlpineCore::getInstance()->getScheduler()->scheduleDelayedTask(new TransferTask(AlpineCore::getInstance(), $player), 40);
             }
             if($player->hasPermission("core.cmd.staffmode")){
                 $deathbantime = $player->getDeathBanTime() - time();
                 if($deathbantime >= 1){
                     if(!$player->isStaffMode()){
                         $player->enterStaffMode();
                     }
                 }
             }
            $player->checkSets();
            $player->updateScoreboard();
            $current = $player->getPvPTimer();
            if(!$mgr->isSpawnClaim($player, $player->getLevel())){
               if($current < 0){
                  $player->unsetPvPTimer();
               } else {
                  $player->setPvPTimer($current - 1);
               }
            }
            if($player->getSpawntagTime() > 0) $player->setSpawntagTime($player->getSpawntagTime() - 1);
            if($player->isSpawntagged() && $player->getSpawntagTime() <= 0) $player->setSpawnTagged(false);
            if($player->getArchertagTime() > 0) $player->setArchertagTime($player->getArchertagTime() - 1);
            if($player->isArcherTagged() == true && $player->getArchertagTime() <= 0) $player->setArcherTagged(false);
            if($player->isBard()){

               $item = $player->getInventory()->getItemInHand();
               if($player->isInFaction()){
                 $f = $player->getFaction();
                 $l = $mgr->getOnlineMembers($f);
                  switch($item->getId()){
                     case ItemIds::BLAZE_POWDER:

                        foreach($l as $member){
                           $distance = $member->distanceSquared($player);
                           if($distance <= 64){
                              $member->addEffect(new EffectInstance(Effect::getEffect(Effect::STRENGTH), 20 * 3, 0));
                           }
                        }
                     break;

                     case ItemIds::MAGMA_CREAM:

                        foreach($l as $member){
                           $distance = $member->distanceSquared($player);
                           if($distance <= 64){
                              $member->addEffect(new EffectInstance(Effect::getEffect(Effect::FIRE_RESISTANCE), 20 * 3, 0));
                           }
                        }
                     break;

                     case ItemIds::GOLDEN_CARROT:

                        foreach($l as $member){
                           $distance = $member->distanceSquared($player);
                           if($distance <= 64){
                              $member->addEffect(new EffectInstance(Effect::getEffect(Effect::NIGHT_VISION), 20 * 3, 0));
                           }
                        }
                     break;

                     case ItemIds::GHAST_TEAR:

                        foreach($l as $member){
                           $distance = $member->distanceSquared($player);
                           if($distance <= 64){
                              $member->addEffect(new EffectInstance(Effect::getEffect(Effect::REGENERATION), 20 * 3, 0));
                           }
                        }
                     break;

                     case ItemIds::SUGAR:

                        foreach($l as $member){
                           $distance = $member->distanceSquared($player);
                           if($distance <= 64){
                              $member->addEffect(new EffectInstance(Effect::getEffect(Effect::SPEED), 20 * 3, 2));
                           }
                        }
                     break;

                     case ItemIds::FEATHER:

                        foreach($l as $member){
                           $distance = $member->distanceSquared($player);
                           if($distance <= 64){
                              $member->addEffect(new EffectInstance(Effect::getEffect(Effect::JUMP), 20 * 3, 0));
                           }
                        }
                     break;
                  }
               }
               if($player->getBardDelay() > 0) $player->setBardDelay($player->getBardDelay() - 1);
               if($player->getBardEnergy() < 120) $player->setBardEnergy($player->getBardEnergy() + 1);
            }
         }
      }
   }
}