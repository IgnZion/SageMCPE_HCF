<?php
declare(strict_types=1);
namespace hcf\tasks;

use hcf\{
   AlpineCore, AlpinePlayer
};
use pocketmine\math\Vector3;
use pocketmine\scheduler\Task;

class NinjaTeleport extends Task {
   /** var AlpineCore */
   private $plugin;
   private $player;
   private $pos;

   public function __construct(AlpineCore $plugin, AlpinePlayer $player, $x, $y, $z){
      $this->plugin = $plugin;
      $this->setPlayer($player);
      $this->setPos(new Vector3($x, $y, $z));
   }

   /**
    * @param int $currentTick
    * @return void
    */
   public function onRun(int $currentTick): void {
      $player = $this->getPlayer();
      if($player != null){
         $player->setLastHit("");
         $player->teleport($this->getPos());
      }
   }

   /**
     * @return mixed
     */
   public function getPlayer(): AlpinePlayer {
      return $this->player;
   }

   /**
     * @param mixed $player
     */
   public function setPlayer(AlpinePlayer $player) {
      $this->player = $player;
   }

   /**
     * @return Vector3
     */
   public function getPos(): Vector3 {
      return $this->pos;
   }

   /**
     * @param Vector3 $pos
     */
   public function setPos(Vector3 $pos) {
      $this->pos = $pos;
   }
}