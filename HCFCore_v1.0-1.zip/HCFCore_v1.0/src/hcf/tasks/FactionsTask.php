<?php
declare(strict_types=1);
namespace hcf\tasks;

use hcf\{
   AlpineCore, AlpinePlayer
};
use pocketmine\scheduler\Task;

class FactionsTask extends Task {
   /** var AlpineCore */
   private $plugin;

   /**
    * FactionsTask constructor.
    *
    * @param AlpineCore $plugin
    */
   public function __construct(AlpineCore $plugin){
      $this->plugin = $plugin;
   }

   /**
    * @param int $currentTick
    * @return void
    */
   public function onRun(int $currentTick) {
      $mgr = AlpineCore::getFactionsManager();
      $server = $this->plugin->getServer();
      $players = $server->getOnlinePlayers();
      $factions = [];
      foreach($players as $player){
         if($player instanceof AlpinePlayer){
            if($player->isInFaction()){
               $faction = $player->getFaction();
               if(!in_array($faction, $factions)){
                  $factions[] = $faction;
               }
            }
         }
      }
      if(count($factions) > 0) {
         foreach($factions as $faction){
            $mgr->addDTR($faction);
         }
      }
   }
}