<?php
declare(strict_types=1);
namespace hcf\tasks;

use hcf\{
   AlpineCore, AlpinePlayer
};
use pocketmine\scheduler\Task;

class ClosureTask extends Task {
   /** var AlpineCore */
   private $plugin;

   /**
    * FactionsTask constructor.
    *
    * @param AlpineCore $plugin
    */
   public function __construct(AlpineCore $plugin){
      $this->plugin = $plugin;
   }

   /**
    * @param int $currentTick
    * @return void
    */
   public function onRun(int $currentTick) {
      AlpineCore::getInstance()->autoSave();
   }
}