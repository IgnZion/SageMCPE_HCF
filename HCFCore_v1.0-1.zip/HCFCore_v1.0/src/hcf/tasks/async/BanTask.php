<?php
declare(strict_types=1);
namespace hcf\tasks\async;

use mysqli;
use hcf\{
    AlpineCore, AlpinePlayer, utils\Utils
};
use pocketmine\scheduler\AsyncTask;
use pocketmine\Server;
use pocketmine\utils\TextFormat as TF;

class BanTask extends AsyncTask {
    private $time;
    private $banner;
    private $banned;
    private $reason;
    private $silent;

    /**
     * BanTask constructor.
     *
     * @param string $banner
     * @param string $banned
     * @param string $reason
     * @param int $time
     * @param bool $silent
     */
    public function __construct(string $banner, string $banned, string $reason, int $time, bool $silent) {
        $this->setTime($time);
        $this->setBanner($banner);
        $this->setBanned($banned);
        $this->setReason($reason);
        $this->setSilent($silent);
    }

    /**
     * Actions to execute when run
     *
     * @return void
     */
    public function onRun(){
        $results = array();
        $db = new mysqli("na02-db.cus.mc-panel.net", "db_195488", "4a721b4368", "db_195488", 3306);
        $banner = $this->getBanner();
        $banned = $this->getBanned();
        $reason = $this->getReason();
        $time = $this->getTime();
        if($this->isRegistered($db, $banned)){
            $results["registered-banned"] = "true";
            $data = $db->prepare("SELECT bannedtimes FROM playerdata WHERE username=?");
            $data->bind_param("s", $banned);
            $data->bind_result($bannedtimes);
            $data->execute();
            while($data->fetch()){
                $results["bannedtimes"] = (int) $bannedtimes;
                $newbannedtimes = $bannedtimes + 1;
            }
            $ban = 1;
            $pdata = $db->prepare("UPDATE playerdata SET banned=?, bannedtimes=?, banduration=? WHERE username=?");
            $pdata->bind_param("iiis", $ban, $newbannedtimes, $time, $banned);
            $pdata->execute();
            $pdata->close();
            if(!$this->wasBannedBefore($db, $banned)){
                $hdata = $db->prepare("INSERT INTO bandata(username, bannedby, reason, duration) VALUES (?, ?, ?, ?)");
                $hdata->bind_param("sssi", $banned, $banner, $reason, $time);
                $hdata->execute();
                $hdata->close();
            } else {
                $hdata = $db->prepare("UPDATE bandata SET bannedby=?, reason=?, duration=? WHERE username=?");
                $hdata->bind_param("ssis", $banner, $reason, $time, $banned);
                $hdata->execute();
                $hdata->close();
            }
        } else $results["registered-banned"] = "false";
        $this->setResult($results);
    }

    /**
     * @param Server $server
     */
    public function onCompletion(Server $server) {
        $player = $server->getPlayer($this->getBanner());
        $banned = $server->getPlayer($this->getBanned());
        $time = $this->getTime() - time();
        if($player !== null){
            if($this->getResult()["registered-banned"] == "true"){
                if($banned !== null){
                    $banned->setPlayerBanned(true);
                    $banned->setPlayerBanTime($this->getTime());
                    $banned->setTotalBannedTimes(1 + $banned->getTotalBannedTimes());
                    $reason = TF::GRAY . "You have been banned from AlpineHCF for " . TF::RED . Utils::intToTime($time) . TF::RESET . "\n" . TF::GRAY . "Banned By: " . TF::RED . $player->getName() . TF::RESET . "\n" . TF::GRAY . "Reason: " . TF::RED . $this->getReason();
                    $banned->kick($reason, false);
                }
                if($this->isSilent()){
                    foreach($server->getOnlinePlayers() as $staff){
                        if($staff->hasPermission("core.seesilentbans")){
                            $staff->sendMessage(TF::BOLD . TF::DARK_RED . "SILENT " . TF::RESET . TF::RED . $player->getName() . " banned " . $this->getBanned() . " for " . Utils::intToTime($time) . TF::RESET . "\n" . TF::GRAY . "Reason: " . TF::RED . $this->getReason());
                        }
                    }
                } else $server->broadcastMessage(TF::RESET . TF::RED . $player->getName() . " banned " . $this->getBanned() . " for " . Utils::intToTime($time) . TF::RESET . "\n" . TF::GRAY . "Reason: " . TF::RED . $this->getReason());
            } else $player->sendMessage(TF::RESET . TF::GRAY . $this->getBanned() . " isn't registered on our server! Make sure to enter IGN correctly!");
        }
    }

    /**
     * @return int
     */
    public function getTime(): int {
        return $this->time;
    }

    /**
     * @param int $time
     */
    public function setTime(int $time){
        $this->time = $time;
    }

    /**
     * @return string
     */
    public function getBanner(): string {
        return $this->banner;
    }

    /**
     * @param string $banner
     */
    public function setBanner(string $banner) {
        $this->banner = $banner;
    }

    /**
     * @return string
     */
    public function getBanned(): string {
        return $this->banned;
    }

    /**
     * @param string $banned
     */
    public function setBanned(string $banned) {
        $this->banned = $banned;
    }

    /**
     * @return string
     */
    public function getReason(): string {
        return $this->reason;
    }

    /**
     * @param string $reason
     */
    public function setReason(string $reason) {
        $this->reason = $reason;
    }

    /**
     * @return bool
     */
    public function isSilent(): bool {
        return $this->silent;
    }

    /**
     * @param bool $silent
     */
    public function setSilent(bool $silent) {
        $this->silent = $silent;
    }

    /**
     * @param mysqli $db
     * @param string $player
     * @return bool
     */
    public function isRegistered(mysqli $db, string $player): bool {
        $result = $db->query("SELECT * FROM playerdata WHERE username='" . $db->real_escape_string($player) . "'");
        return $result->num_rows > 0 ? true : false;
    }

    /**
     * @param mysqli $db
     * @param string $player
     * @return bool
     */
    public function wasBannedBefore(mysqli $db, string $player): bool {
        $result = $db->query("SELECT * FROM bandata WHERE username='" . $db->real_escape_string($player) . "'");
        return $result->num_rows > 0 ? true : false;
    }
}