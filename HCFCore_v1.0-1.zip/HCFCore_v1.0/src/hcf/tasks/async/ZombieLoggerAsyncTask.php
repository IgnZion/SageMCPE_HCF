<?php
declare(strict_types=1);
namespace hcf\tasks\async;

use mysqli;
use hcf\{AlpineCore, AlpinePlayer, utils\Utils};
use pocketmine\scheduler\AsyncTask;
use pocketmine\Server;
use pocketmine\utils\TextFormat as TF;

class ZombieLoggerAsyncTask extends AsyncTask {
    private $player;

    /**
     * ZombieLoggerAsyncTask constructor.
     * @param string $player
     */
    public function __construct(string $player) {
        $this->setPlayer($player);
    }

    /**
     * Actions to execute when run
     *
     * @return void
     */
    public function onRun(){
        $results = array();
        $db = new mysqli("na02-db.cus.mc-panel.net", "db_195488", "4a721b4368", "db_195488", 3306);
        $player = $this->getPlayer();
        if($this->isRegistered($db, $player)){
            $zombie = "true";
            $update = $db->prepare("UPDATE deathbandata SET zombielogger=? WHERE username=?");
            $update->bind_param("ss", $zombie, $player);
            $update->execute();
            $update->close();
        }
    }

    /**
     * @param Server $server
     */
    public function onCompletion(Server $server) {
    }

    /**
     * @return string
     */
    public function getPlayer(): string {
        return $this->player;
    }

    /**
     * @param string $player
     */
    public function setPlayer(string $player) {
        $this->player = $player;
    }

    /**
     * @param mysqli $db
     * @param string $player
     * @return bool
     */
    public function isRegistered(mysqli $db, string $player): bool {
        $result = $db->query("SELECT * FROM deathbandata WHERE username='" . $db->real_escape_string($player) . "'");
        return $result->num_rows > 0 ? true : false;
    }
}
