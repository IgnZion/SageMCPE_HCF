<?php
declare(strict_types=1);
namespace hcf\tasks\async;

use mysqli;
use hcf\{
    AlpineCore, AlpinePlayer, utils\Utils
};
use pocketmine\scheduler\AsyncTask;
use pocketmine\Server;
use pocketmine\utils\TextFormat as TF;

class MuteOfflineTask extends AsyncTask {
    private $time;
    private $muter;
    private $mutee;

    /**
     * MuteOfflineTask constructor.
     *
     * @param string $player
     */
    public function __construct(int $time, string $muter, string $mutee) {
        $this->setTime($time);
        $this->setMuter($muter);
        $this->setMutee($mutee);
    }

    /**
     * Actions to execute when run
     *
     * @return void
     */
    public function onRun(){
        $results = array();
        $db = new mysqli("na02-db.cus.mc-panel.net", "db_195488", "4a721b4368", "db_195488", 3306);
        $mutee = $this->getMutee();
        $time = $this->getTime();
        if($this->isRegistered($db, $mutee)){
            $results["registered-mutee"] = "true";
            $data = $db->prepare("UPDATE playerdata SET muted=? WHERE username=?");
            $data->bind_param("is", $time, $mutee);
            $data->execute();
            $data->close();
        } else $results["registered-mutee"] = "false";
        $this->setResult($results);
    }

    /**
     * @param Server $server
     */
    public function onCompletion(Server $server) {
        $player = $server->getPlayer($this->getMuter());
        if($player !== null){
            if($this->getResult()["registered-mutee"] == "true"){
                $player->sendMessage(TF::GRAY . "You successfully muted " . TF::GREEN . $this->getMutee() . " for " . Utils::intToTime($this->getTime()));
            } else $player->sendMessage(TF::RESET . TF::GRAY . $this->getPlayer() . " isn't registered on our server! Make sure to enter IGN correctly!");
        }
    }

    /**
     * @return int
     */
    public function getTime(): int {
        return $this->time;
    }

    /**
     * @param int $time
     */
    public function setTime(int $time){
        $this->time = $time;
    }

    /**
     * @return string
     */
    public function getMuter(): string {
        return $this->muter;
    }

    /**
     * @param string $muter
     */
    public function setMuter(string $muter) {
        $this->muter = $muter;
    }

    /**
     * @return string
     */
    public function getMutee(): string {
        return $this->mutee;
    }

    /**
     * @param string $mutee
     */
    public function setMutee(string $mutee) {
        $this->mutee = $mutee;
    }

    /**
     * @param mysqli $db
     * @param string $player
     * @return bool
     */
    public function isRegistered(mysqli $db, string $player): bool {
        $result = $db->query("SELECT * FROM playerdata WHERE username='" . $db->real_escape_string($player) . "'");
        return $result->num_rows > 0 ? true : false;
    }
}
