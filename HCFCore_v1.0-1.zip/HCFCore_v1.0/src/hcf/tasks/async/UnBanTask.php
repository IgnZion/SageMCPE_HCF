<?php
declare(strict_types=1);
namespace hcf\tasks\async;

use mysqli;
use hcf\{
    AlpineCore, AlpinePlayer, utils\Utils
};
use pocketmine\scheduler\AsyncTask;
use pocketmine\Server;
use pocketmine\utils\TextFormat as TF;

class UnBanTask extends AsyncTask {

    private $banner;
    private $banned;

    /**
     * UnBanTask constructor.
     *
     * @param string $banner
     * @param string $banned
     */
    public function __construct(string $banner, string $banned) {
        $this->setBanner($banner);
        $this->setBanned($banned);
    }

    /**
     * Actions to execute when run
     *
     * @return void
     */
    public function onRun(){
        $results = array();
        $db = new mysqli("na02-db.cus.mc-panel.net", "db_195488", "4a721b4368", "db_195488", 3306);
        $banner = $this->getBanner();
        $banned = $this->getBanned();
        $time = 0;
        if($this->isRegistered($db, $banned)){
            $results["registered-banned"] = "true";
            $ban = 0;
            $pdata = $db->prepare("UPDATE playerdata SET banned=?, banduration=? WHERE username=?");
            $pdata->bind_param("iis", $ban, $time, $banned);
            $pdata->execute();
            $pdata->close();
            $reason = "";
            $hdata = $db->prepare("UPDATE bandata SET bannedby=?, reason=?, duration=? WHERE username=?");
            $hdata->bind_param("ssis", $banner, $reason, $time, $banned);
            $hdata->execute();
            $hdata->close();
        } else $results["registered-banned"] = "false";
        $this->setResult($results);
    }

    /**
     * @param Server $server
     */
    public function onCompletion(Server $server) {
        $player = $server->getPlayer($this->getBanner());
        if($player !== null){
            if($this->getResult()["registered-banned"] == "true"){
                $player->sendMessage(TF::BOLD . TF::DARK_RED . "You unbanned " . $this->getBanned());
            } else $player->sendMessage(TF::RESET . TF::GRAY . $this->getBanned() . " isn't registered on our server! Make sure to enter IGN correctly!");
        }
    }

    /**
     * @return string
     */
    public function getBanner(): string {
        return $this->banner;
    }

    /**
     * @param string $banner
     */
    public function setBanner(string $banner) {
        $this->banner = $banner;
    }

    /**
     * @return string
     */
    public function getBanned(): string {
        return $this->banned;
    }

    /**
     * @param string $banned
     */
    public function setBanned(string $banned) {
        $this->banned = $banned;
    }

    /**
     * @param mysqli $db
     * @param string $player
     * @return bool
     */
    public function isRegistered(mysqli $db, string $player): bool {
        $result = $db->query("SELECT * FROM playerdata WHERE username='" . $db->real_escape_string($player) . "'");
        return $result->num_rows > 0 ? true : false;
    }
}