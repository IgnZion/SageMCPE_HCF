<?php
declare(strict_types=1);
namespace hcf\tasks\async;

use mysqli;
use hcf\{
   AlpineCore, AlpinePlayer, utils\Utils
};
use pocketmine\scheduler\AsyncTask;
use pocketmine\Server;
use pocketmine\utils\TextFormat as TF;

class LoadItTask extends AsyncTask {
   private $database;
   private $player;

   /**
     * LoadItTask constructor.
     * @param mysqli $database
     * @param string $player
     */
   public function __construct (mysqli $database, string $player) {

        $this->setDatabase(new mysqli("na02-db.cus.mc-panel.net", "db_195488", "4a721b4368", "db_195488", 3306));
        $this->setPlayer($player);
   }
   /**
     * Actions to execute when run
     *
     * @return void
     */
   public function onRun(){
      $results = array();
      $db = new mysqli("na02-db.cus.mc-panel.net", "db_195488", "4a721b4368", "db_195488");
      $name = $this->getPlayer();
      $data = $db->prepare("SELECT money, kills, deaths, pvpenabled, pvptime, gapcooldown, reclaim, staffmode, inventory, helmet, chestplate, leggings, boots FROM hcfdata WHERE username=?");
      $data->bind_param("s", $name);
      $data->bind_result($money, $kills, $deaths, $pvpenabled, $pvptime, $gapcooldown, $reclaim, $staffmode, $inventory, $helmet, $chestplate, $leggings, $boots);
      $data->execute();
      while($data->fetch()){
          $results["money"] = $money;
          $results["kills"] = $kills;
          $results["deaths"] = $deaths;
          $results["pvpenabled"] = $pvpenabled;
          $results["pvptime"] = $pvptime;
          $results["gapcooldown"] = $gapcooldown;
          $results["reclaim"] = $reclaim;
          $results["staffmode"] = $staffmode;
          $results["inventory"] = $inventory;
          $results["helmet"] = $helmet;
          $results["chestplate"] = $chestplate;
          $results["leggings"] = $leggings;
          $results["boots"] = $boots;
      }
      $pdata = $db->prepare("SELECT rank, permissions, tags, elo, banned, bannedtimes, banduration, warnings, muted, ip, cid, skin FROM playerdata WHERE username=?");
      $pdata->bind_param("s", $name);
      $pdata->bind_result($rank, $permissions, $tags, $elo, $banned, $bannedtimes, $banduration, $warnings, $muted, $ip, $cid, $skin);
      $pdata->execute();
      while($pdata->fetch()){
          $results["rank"] = $rank;
          $results["permissions"] = $permissions;
          $results["tags"] = $tags;
          $results["elo"] = $elo;
          $results["banned"] = $banned;
          $results["bannedtimes"] = $bannedtimes;
          $results["banduration"] = $banduration;
          $results["warnings"] = $warnings;
          $results["ip"] = $ip;
          $results["cid"] = $cid;
          $results["skin"] = $skin;
          $results["muted"] = $muted;
      }
      $lives = $db->prepare("SELECT lives, time, deathbanned, zombielogger FROM deathbandata WHERE username=?");
      $lives->bind_param("s", $name);
      $lives->bind_result($totallives, $time, $deathbanned, $zombielogger);
      $lives->execute();
      while($lives->fetch()){
          $results["lives"] = $totallives;
          $results["deathbantime"] = $time;
          $results["deathbanned"] = $deathbanned;
          $results["zombielogger"] = $zombielogger;
      }
      $kits = $db->prepare("SELECT starter, bard, miner, rogue, diamond, archer, master, brewer, builder FROM kitsdata WHERE username=?");
      $kits->bind_param("s", $name);
      $kits->bind_result($starter, $bard, $miner, $rogue, $diamond, $archer, $master, $brewer, $builder);
      $kits->execute();
      while($kits->fetch()){
          $results["starter"] = $starter;
          $results["bard"] = $bard;
          $results["miner"] = $miner;
          $results["rogue"] = $rogue;
          $results["diamond"] = $diamond;
          $results["archer"] = $archer;
          $results["master"] = $master;
          $results["brewer"] = $brewer;
          $results["builder"] = $builder;
      }
      $this->setResult($results);
   }

    /**
     * @param Server $server
     */
    public function onCompletion(Server $server) {
        $player = $server->getPlayer($this->getPlayer());
        if($player !== null){
            $player->setRank((string) $this->getResult()["rank"]);
            $player->setFirstCID((string) $this->getResult()["cid"]);
            $player->setPlayerSkinData((string) $this->getResult()["skin"]);
            $player->setPlayerBanned((bool) $this->getResult()["banned"]);
            $player->setPlayerBanTime((int) $this->getResult()["banduration"]);
            $player->setTotalBannedTimes((int) $this->getResult()["bannedtimes"]);
            $player->setWarnings((int) $this->getResult()["warnings"]);
            $player->setMoney((int) $this->getResult()["money"]);
            $player->addKill((int) $this->getResult()["kills"]);
            $player->addDeath((int) $this->getResult()["deaths"]);
            $player->setPvP((bool) $this->getResult()["pvpenabled"]);
            $player->setReclaim((bool) $this->getResult()["reclaim"]);
            $player->setPvP((bool) $this->getResult()["pvpenabled"]);
            $player->setPvPTimer((int) $this->getResult()["pvptime"]);
            $player->setStaffMode((bool) $this->getResult()["staffmode"]);
            $player->setMutedTime((int) $this->getResult()["muted"]);
            $player->setGappleCooldown((int) $this->getResult()["gapcooldown"]);
            $player->setElo((int) $this->getResult()["elo"]);
            $player->setLives((int) $this->getResult()["lives"]);
            $player->setDeathbanned((string) $this->getResult()["deathbanned"]);
            $player->setZombieLogger((string) $this->getResult()["zombielogger"]);
            $player->setDeathbanTime((int) $this->getResult()["deathbantime"]);
            $player->setKitCooldown("starter", (int) $this->getResult()["starter"]);
            $player->setKitCooldown("bard", (int) $this->getResult()["bard"]);
            $player->setKitCooldown("miner", (int) $this->getResult()["miner"]);
            $player->setKitCooldown("rogue", (int) $this->getResult()["rogue"]);
            $player->setKitCooldown("diamond", (int) $this->getResult()["diamond"]);
            $player->setKitCooldown("archer", (int) $this->getResult()["archer"]);
            $player->setKitCooldown("master", (int) $this->getResult()["master"]);
            $player->setKitCooldown("brewer", (int) $this->getResult()["brewer"]);
            $player->setKitCooldown("builder", (int) $this->getResult()["builder"]);
            $player->setArmorInventoryHelmet(json_decode($this->getResult()["helmet"]));
            $player->setArmorInventoryChestplate(json_decode($this->getResult()["chestplate"]));
            $player->setArmorInventoryLeggings(json_decode($this->getResult()["leggings"]));
            $player->setArmorInventoryBoots(json_decode($this->getResult()["boots"]));

            $permissions = json_decode($this->getResult()["permissions"], true);
            if($permissions != null){
                foreach($permissions as $permission){
                    $player->addPermission($permission);
                }
            }

            $ips = (array) json_decode($this->getResult()["ip"], true);
            if($ips != null){
                foreach($ips as $ip){
                    $player->setAlpinePlayerIP($ip);
                }
            }

            $inventory = json_decode($this->getResult()["inventory"], true);
            if($inventory != null){
                foreach($inventory as $item){
                    $player->setInventoryItems($item);
                }
            }
            if(($this->getResult()["banduration"] - time()) >= 1){
                $time = $this->getResult()["banduration"] - time();
                $reason = TF::GRAY . "You have been banned from AlpineHCF for " . TF::RED . Utils::intToTime($time) . TF::RESET . "\n" . TF::GRAY . "Banned By: " . TF::RED . "STAFF" . TF::RESET . "\n" . TF::RED . "If you feel this is a mistake contact a staff member";
                $player->kick($reason, false);
            }
        }
    }

    /**
     * @return mysqli
     */
    public function getDatabase(): mysqli {
        return $this->database;
    }

    /**
     * @param mysqli $database
     */
    public function setDatabase(mysqli $database) {
        $this->database = $database;
    }

    /**
     * @return string
     */
    public function getPlayer(): string {
        return $this->player;
    }

    /**
     * @param string $player
     */
    public function setPlayer(string $player) {
        $this->player = $player;
    }
}