<?php
declare(strict_types=1);
namespace hcf\tasks\async;

use mysqli;
use jojoe77777\FormAPI\{
    CustomForm, SimpleForm, ModalForm};
use hcf\{
    AlpineCore, AlpinePlayer, utils\Utils};
use pocketmine\scheduler\AsyncTask;
use pocketmine\Server;
use pocketmine\utils\TextFormat as TF;

class PlayerInfoTask extends AsyncTask {

    private $banner;
    private $banned;

    /**
     * PlayerInfoTask constructor.
     *
     * @param string $banner
     * @param string $banned
     */
    public function __construct (string $banner, string $banned) {
        $this->setBanner($banner);
        $this->setBanned($banned);
    }

    /**
     * Actions to execute when run
     *
     * @return void
     */
    public function onRun(){
        $results = array();
      $db = new mysqli("na02-db.cus.mc-panel.net", "db_195488", "4a721b4368", "db_195488");;
        $name = $this->getBanned();
        if($this->isRegistered($db, $name)){
            $results["registered"] = "true";
            $data = $db->prepare("SELECT rank, banned, bannedtimes, banduration, warnings, muted FROM playerdata WHERE username=?");
            $data->bind_param("s", $name);
            $data->bind_result($rank, $banned, $bannedtimes, $banduration, $warnings, $muted);
            $data->execute();
            while($data->fetch()){
                $results["rank"] = $rank;
                $results["banned"] = $banned;
                $results["bannedtimes"] = $bannedtimes;
                $results["banduration"] = $banduration;
                $results["warnings"] = $warnings;
                $results["muted"] = $muted;
            }
        } else $results["registered"] = "false";
        $this->setResult($results);
    }

    /**
     * @param Server $server
     */
    public function onCompletion(Server $server) {
        if($this->getResult()["registered"] == "false") return;
        $player = $server->getPlayer($this->getBanner());
        $rank = TF::GREEN . $this->getBanned() . "'s Info" . TF::RESET . "\n\n" . TF::GRAY . "Rank: " . TF::GREEN . $this->getResult()["rank"];
        $time = $this->getResult()["banduration"] - time();
        if($time >= 1){
            $banned = $rank . TF::RESET . "\n" . TF::GRAY . "Banned: " . TF::RED . "true" . TF::RESET . "\n" . TF::GRAY . "Duration: " . TF::RED . Utils::intToTime((int) $this->getResult()["banduration"] - time());
        } else {
            $banned = $rank . TF::RESET . "\n" . TF::GRAY . "Banned: " . TF::GREEN . "false";
        }
        $times = $banned . TF::RESET . "\n" . TF::GRAY . "Banned Times: " . TF::DARK_RED . $this->getResult()["bannedtimes"] . TF::RESET . "\n" . TF::GRAY . "Total Warnings: " . TF::DARK_RED . $this->getResult()["warnings"] . TF::RESET . "\n" . TF::GRAY . "Mute Duration: " . TF::RED . Utils::intToTime((int) $this->getResult()["muted"] - time());
        if($player != null){
            $form = new SimpleForm(function (AlpinePlayer $player, int $data = null) {
                $result = $data;
                if($result === null) return true;
                switch($result){
                    case 0:
                        AlpineCore::getPunishManager()->openPunishMenu($player);
                        break;
                }
            });
            $form->setTitle("Player Info Menu");
            $form->setContent($times);
            $form->addButton("Go Back");
            $form->sendToPlayer($player);
        }
    }

    /**
     * @return string
     */
    public function getBanner(): string {
        return $this->banner;
    }

    /**
     * @param string $banner
     */
    public function setBanner(string $banner) {
        $this->banner = $banner;
    }

    /**
     * @return string
     */
    public function getBanned(): string {
        return $this->banned;
    }

    /**
     * @param string $banned
     */
    public function setBanned(string $banned) {
        $this->banned = $banned;
    }

    /**
     * @param mysqli $db
     * @param string $player
     * @return bool
     */
    public function isRegistered(mysqli $db, string $player): bool {
        $result = $db->query("SELECT * FROM playerdata WHERE username='" . $db->real_escape_string($player) . "'");
        return $result->num_rows > 0 ? true : false;
    }
}