<?php
declare(strict_types=1);
namespace hcf\tasks\async;

use mysqli;
use hcf\{
   AlpineCore, AlpinePlayer, utils\Utils
};
use pocketmine\scheduler\AsyncTask;
use pocketmine\Server;
use pocketmine\utils\TextFormat as TF;

class SaveItTask extends AsyncTask {
   private $data;
   private $kits;
   private $pvp;
   private $player;

   /**
     * SaveItTask constructor.
     * @param array $data
     * @param array $kits
     * @param array $pvp
     * @param string $player
     */
   public function __construct (array $data, array $kits, array $pvp, string $player) {
        $this->setData($data);
        $this->setKitsData($kits);
        $this->setPvPData($pvp);
        $this->setPlayer($player);
   }
   /**
     * Actions to execute when run
     *
     * @return void
     */
   public function onRun(){
      $results = array();
      $db = new mysqli("na02-db.cus.mc-panel.net", "db_195488", "90adea0f52", "db_195488");
      $name = $this->getPlayer();
      $money = (int) $this->getData()["money"];
      $kills = (int) $this->getData()["kills"];
      $deaths = (int) $this->getData()["deaths"];
      $pvpenabled = (int) $this->getPvPData()["enabled"];
      $pvptime = (int) $this->getPvPData()["timeleft"];
      $gapcooldown = (int) $this->getData()["gapcooldown"];
      $reclaim = (int) $this->getData()["reclaim"];
      $staffmode = (int) $this->getData()["staffmode"];
      $inventory = json_encode($this->getData()["inventory"]);
      $helmet = json_encode($this->getData()["helmet"]);
      $chestplate = json_encode($this->getData()["chestplate"]);
      $leggings = json_encode($this->getData()["leggings"]);
      $boots = json_encode($this->getData()["boots"]);
      $data = $db->prepare("UPDATE hcfdata SET money=?, kills=?, deaths=?, pvpenabled=?, pvptime=?, gapcooldown=?, reclaim=?, staffmode=?, inventory=?, helmet=?, chestplate=?, leggings=?, boots=? WHERE username=?");
      $data->bind_param("iiiiiiiissssss", $money, $kills, $deaths, $pvpenabled, $pvptime, $gapcooldown, $reclaim, $staffmode, $inventory, $helmet, $chestplate, $leggings, $boots, $name);
      $data->execute();
      $data->close();

      $rank = (string) $this->getData()["rank"];
      $permissions = json_encode($this->getData()["permissions"]);
      $elo = (int) $this->getData()["elo"];
      $tags = json_encode($this->getData()["tags"]);
      $banned = (int) $this->getData()["banned"];
      $bannedtimes = (int) $this->getData()["bannedtimes"];
      $banduration = (int) $this->getData()["banduration"];
      $muted = (int) $this->getData()["muted"];
      $warnings = (int) $this->getData()["warnings"];
      $ip = json_encode($this->getData()["ips"]);
      $skin = (string) $this->getData()["skin"];
      $pdata = $db->prepare("UPDATE playerdata SET rank=?, permissions=?, elo=?, tags=?, banned=?, bannedtimes=?, banduration=?, warnings=?, muted=?, ip=?, skin=? WHERE username=?");
      $pdata->bind_param("ssisiiiiisss", $rank, $permissions, $elo, $tags, $banned, $bannedtimes, $banduration, $warnings, $muted, $ip, $skin, $name);
      $pdata->execute();
      $pdata->close();

      $lives = (int) $this->getData()["lives"];
      $time = (int) $this->getData()["deathbantime"];
      $deathbanned = (string) $this->getData()["deathbanned"];
      $zombielogger = (string) $this->getData()["zombielogger"];
      $deathban = $db->prepare("UPDATE deathbandata SET lives=?, time=?, deathbanned=?, zombielogger=? WHERE username=?");
      $deathban->bind_param("iisss", $lives, $time, $deathbanned, $zombielogger, $name);
      $deathban->execute();
      $deathban->close();

      $starter = (int) $this->getKitsData()["starter"];
      $bard = (int) $this->getKitsData()["bard"];
      $miner = (int) $this->getKitsData()["miner"];
      $rogue = (int) $this->getKitsData()["rogue"];
      $diamond = (int) $this->getKitsData()["diamond"];
      $archer = (int) $this->getKitsData()["archer"];
      $master = (int) $this->getKitsData()["master"];
      $builder = (int) $this->getKitsData()["builder"];
      $brewer  = (int) $this->getKitsData()["brewer"];
      $kits = $db->prepare("UPDATE kitsdata SET starter=?, bard=?, miner=?, rogue=?, diamond=?, archer=?, master=?, brewer=?, builder=? WHERE username=?");
      $kits->bind_param("iiiiiiiiis", $starter, $bard, $miner, $rogue, $diamond, $archer, $master, $brewer, $builder, $name);
      $kits->execute();
      $kits->close();
   }

    /**
     * @param Server $server
     */
    public function onCompletion(Server $server) {
    }

    /**
     * @return array
     */
    public function getData(): array {
        return (array) $this->data;
    }

    /**
     * @param array $data
     */
    public function setData(array $data) {
        $this->data = $data;
    }

    /**
     * @return array
     */
    public function getKitsData(): array {
        return (array) $this->kits;
    }

    /**
     * @param array $data
     */
    public function setKitsData(array $data) {
        $this->kits = $data;
    }

    /**
     * @return array
     */
    public function getPvPData(): array {
        return (array) $this->pvp;
    }

    /**
     * @param array $data
     */
    public function setPvPData(array $data) {
        $this->pvp = $data;
    }

    /**
     * @return string
     */
    public function getPlayer(): string {
        return $this->player;
    }

    /**
     * @param string $player
     */
    public function setPlayer(string $player) {
        $this->player = $player;
    }
}