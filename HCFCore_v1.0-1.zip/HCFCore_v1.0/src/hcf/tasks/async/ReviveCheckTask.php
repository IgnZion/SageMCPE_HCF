<?php
declare(strict_types=1);
namespace hcf\tasks\async;

use mysqli;
use hcf\{
    AlpineCore, AlpinePlayer, utils\Utils
};
use pocketmine\scheduler\AsyncTask;
use pocketmine\Server;
use pocketmine\utils\TextFormat as TF;

class ReviveCheckTask extends AsyncTask {
    private $player;
    private $reviver;

    /**
     * ReviveCheckTask constructor.
     * @param string $player
     */
    public function __construct(string $player, string $reviver) {
        $this->setPlayer($player);
        $this->setReviver($reviver);
    }

    /**
     * Actions to execute when run
     *
     * @return void
     */
    public function onRun(){
        $results = array();
        $db = new mysqli("na02-db.cus.mc-panel.net", "db_195488", "4a721b4368", "db_195488", 3306);
        $revivee = $this->getPlayer();
        $reviver = $this->getReviver();
        if($this->isRegistered($db, $revivee)){
            $results["registered-revivee"] = "true";
            $data = $db->prepare("SELECT lives FROM deathbandata WHERE username=?");
            $data->bind_param("s", $reviver);
            $data->bind_result($lives);
            $data->execute();
            while($data->fetch()){
                $lives = (int) $lives;
                $results["lives"] = $lives;
            }
            if($results["lives"] >= 1){
                $results["enough-lives"] = "true";
                $db = new mysqli("127.0.0.1", "root", "#Dequan12", "hcf_data", 3306);
                $rdata = $db->prepare("SELECT deathbanned, time FROM deathbandata WHERE username=?");
                $rdata->bind_param("s", $revivee);
                $rdata->bind_result($deathbanned, $deathbantime);
                $rdata->execute();
                while($rdata->fetch()){
                    $results["deathbanned"] = $deathbanned;
                    $results["deathbantime"] = (int) $deathbantime;
                }
                if(($results["deathbantime"] - time()) >= 1){
                    $results["is-deathbanned"] = "true";
                    $deathbant = (int) 0;
                    $isdeathbanned = "true";
                    $update = $db->prepare("UPDATE deathbandata SET time=?, deathbanned=? WHERE username=?");
                    $update->bind_param("iss", $deathbant, $isdeathbanned, $revivee);
                    $update->execute();
                    $update->close();
                    $newlives = $results["lives"] - 1;
                    $db = new mysqli("127.0.0.1", "root", "#Dequan12", "hcf_data", 3306);
                    $updater = $db->prepare("UPDATE deathbandata SET lives=? WHERE username=?");
                    $updater->bind_param("is", $newlives, $reviver);
                    $updater->execute();
                    $updater->close();
                } else $results["is-deathbanned"] = "false";
            } else $results["enough-lives"] = "false";
        } else $results["registered-revivee"] = "false";
        $this->setResult($results);
    }

    /**
     * @param Server $server
     */
    public function onCompletion(Server $server) {
        $player = $server->getPlayer($this->getReviver());
        $revive = $server->getPlayer($this->getPlayer());
        if($revive != null){
            if($this->getResult()["enough-lives"] == "true"){
                if($this->getResult()["is-deathbanned"] == "true"){
                    $revive->setDeathBanTime(0);
                }
            }
        }
        if($player !== null){
            if($this->getResult()["registered-revivee"] == "true"){
                if($this->getResult()["enough-lives"] == "true"){
                    if($this->getResult()["is-deathbanned"] == "true"){
                        $player->setLives($player->getLives() - 1);
                        $player->sendMessage(TF::RESET . TF::GREEN . "Revive" . TF::BOLD . " >> " . TF::RESET . TF::GRAY . "You successfully revived " . $this->getPlayer() . "!");
                    } else $player->sendMessage(TF::RESET . TF::RED . "Revive" . TF::BOLD . " >> " . TF::RESET . TF::GRAY . $this->getPlayer() . " isn't deathbanned!");
                } else $player->sendMessage(TF::RESET . TF::RED . "Revive" . TF::BOLD . " >> " . TF::RESET . TF::GRAY . " You do not have enough lives to revive a player!");
            } else $player->sendMessage(TF::RESET . TF::RED . "Revive" . TF::BOLD . " >> " . TF::RESET . TF::GRAY . $this->getPlayer() . " isn't registered on our server! Make sure to enter IGN correctly!");
        }
    }

    /**
     * @return string
     */
    public function getPlayer(): string {
        return $this->player;
    }

    /**
     * @param string $player
     */
    public function setPlayer(string $player) {
        $this->player = $player;
    }

    /**
     * @return string
     */
    public function getReviver(): string {
        return $this->reviver;
    }

    /**
     * @param string $reviver
     */
    public function setReviver(string $reviver) {
        $this->reviver = $reviver;
    }

    /**
     * @param mysqli $db
     * @param string $player
     * @return bool
     */
    public function isRegistered(mysqli $db, string $player): bool {
        $result = $db->query("SELECT * FROM deathbandata WHERE username='" . $db->real_escape_string($player) . "'");
        return $result->num_rows > 0 ? true : false;
    }
}
