<?php
declare(strict_types=1);
namespace hcf\tasks;

use hcf\AlpineCore;
use pocketmine\Server;

class Tasks {

   public static function init(): void {
      $instance = AlpineCore::getInstance();
      $data = $instance->getData();
      $server = $instance->getServer();
      $task = $instance->getScheduler();

      $task->scheduleRepeatingTask(new SetsTask($instance), 20);
      $task->scheduleRepeatingTask(new ClearEntities($instance), 20 * 120);
      $task->scheduleRepeatingTask(new FactionsTask($instance), 20 * 60);
      $server->getLogger()->notice("Tasks Registered");
   }
}