<?php
declare(strict_types=1);
namespace hcf\tasks;

use mysqli;
use hcf\{
   AlpineCore, AlpinePlayer
};
use pocketmine\scheduler\Task;

class PingTask extends Task {

   private $plugin;
   private $mysqli;

   /* PingTask constructor.
    *
    * @param AlpineCore $plugin
    * @param mysqli $mysqli
    */
   public function __construct(AlpineCore $plugin, mysqli $mysqli){
      $this->plugin = $plugin;
      $this->mysqli = $mysqli;
   }

   /**
    * @param int $currentTick
    * @return void
    */
   public function onRun(int $currentTick): void {
       if(!$this->mysqli->ping()){
           AlpineCore::getInstance()->setPlayerDatabase(new mysqli("127.0.0.1", "root", "#Dequan12", "hcf_data", 3306));
       }
   }
}