<?php
declare(strict_types=1);
namespace hcf\tasks;

use hcf\{AlpineCore, AlpinePlayer};
use pocketmine\entity\Zombie;
use pocketmine\utils\TextFormat as TF;
use pocketmine\scheduler\Task;

class ClearEntities extends Task {
    /** @var AlpineCore */
    private $plugin;

    /**
     * ClearEntities constructor.
     *
     * @param AlpineCore $plugin
     */
    public function __construct(AlpineCore $plugin){
        $this->plugin = $plugin;
    }

    /**
     * @param int $currentTick
     * @return void
     */
    public function onRun(int $currentTick) {
        $total = 0;
        $server = AlpineCore::getInstance()->getServer();
        foreach($server->getLevels() as $level){
            foreach($level->getEntities() as $entity){
                $total++;
                if(!$entity instanceof AlpinePlayer && !$entity instanceof Zombie){
                    $entity->close();
                }
            }
        }
        $server->broadcastMessage(TF::RESET . TF::DARK_GREEN . TF::BOLD . "ENTITIES " . TF::RESET . TF::GREEN . $total . TF::GRAY . " Entities cleared!");
    }
}