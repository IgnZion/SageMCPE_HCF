<?php
declare(strict_types=1);
namespace hcf\manager;

use hcf\{AlpineCore, AlpinePlayer};
use pocketmine\item\Item;
use pocketmine\item\enchantment\{Enchantment, EnchantmentInstance};
use pocketmine\nbt\tag\{StringTag, IntTag ,CompoundTag, ListTag, ByteTag};
use muqsit\invmenu\{InvMenu, InvMenuHandler};
use pocketmine\tile\Sign;
use pocketmine\utils\Config;
use pocketmine\math\Vector3;
use pocketmine\level\particle\FloatingTextParticle;
use pocketmine\utils\TextFormat as C;

class CratesManager {

   const VOTE_CRATE = 0;
   const KOTH_CRATE = 1;
   const PARTNER_CRATE = 2;
   const VOYAGER_CRATE = 3;
   const PIONEER_CRATE = 4;
   const ALPINIST_CRATE = 5;
   const BUYCRAFT_LINK = "store.alpincehcf.net";
   private $plugin;
   private $crate;

   /**
     * @param AlpineCore $plugin
     */
   public function __construct(AlpineCore $plugin){
      $this->plugin = $plugin;
      $this->crate = [
         self::VOTE_CRATE => [
            "coords" => "-27:70:38",
            "name" => "§l§8[" . C::GREEN . "Vote§8] §7Crate",
            "key" => C::GREEN . "Vote Key",
            "lore" => [
                C::GRAY . "You can redeem this key at " . C::GREEN . "Vote Crate",
                C::BOLD . C::GREEN . " * " . C::RESET . C::GRAY . "Right-Click Crate with key to redeem!",
                C::BOLD . C::GREEN . " * " . C::RESET . C::GRAY . "Right-Click Crate w/o a key to view rewards!",
                "",
                C::GRAY . "Get this key by voting!"
            ]
         ],
         self::PARTNER_CRATE => [
            "coords" => "-31:70:39",
            "name" => "§l§8[" . C::DARK_PURPLE . "Partner§8] §7Crate",
            "key" => C::DARK_PURPLE . "Partner Key",
            "lore" => [
                C::GRAY . "You can redeem this key at " . C::DARK_PURPLE . "Partner Crate",
                C::BOLD . C::DARK_PURPLE . " * " . C::RESET . C::GRAY . "Right-Click Crate with key to redeem!",
                C::BOLD . C::DARK_PURPLE . " * " . C::RESET . C::GRAY . "Right-Click Crate w/o a key to view rewards!",
                "",
                C::GRAY . "Get this key by buying keys at " . C::DARK_PURPLE . self::BUYCRAFT_LINK
            ]
         ],
         self::KOTH_CRATE => [
            "coords" => "-35:70:38",
            "name" => "§l§8[" . C::DARK_RED . "KOTH§8] §7Crate",
            "key" => C::DARK_RED . "KOTH Key",
            "lore" => [
                C::GRAY . "You can redeem this key at " . C::DARK_RED . "KOTH Crate",
                C::BOLD . C::DARK_RED . " * " . C::RESET . C::GRAY . "Right-Click Crate with key to redeem!",
                C::BOLD . C::DARK_RED . " * " . C::RESET . C::GRAY . "Right-Click Crate w/o a key to view rewards!",
                "",
                C::GRAY . "Get this key by buying keys at " . C::DARK_RED . self::BUYCRAFT_LINK
            ]
         ],
         self::PIONEER_CRATE => [
            "coords" => "-38:70:35",
            "name" => "§l§8[" . C::DARK_BLUE . "Pioneer§8] §7Crate",
            "key" => C::DARK_BLUE . "Pioneer Key",
            "lore" => [
                C::GRAY . "You can redeem this key at " . C::DARK_BLUE . "Pioneer Crate",
                C::BOLD . C::DARK_BLUE . " * " . C::RESET . C::GRAY . "Right-Click Crate with key to redeem!",
                C::BOLD . C::DARK_BLUE . " * " . C::RESET . C::GRAY . "Right-Click Crate w/o a key to view rewards!",
                "",
                C::GRAY . "Get this key by buying keys at " . C::DARK_BLUE . self::BUYCRAFT_LINK
            ]
         ],
         self::ALPINIST_CRATE => [
            "coords" => "-39:70:31",
            "name" => "§l§8[" . C::DARK_GREEN . "Alpinist§8] §7Crate",
            "key" => C::DARK_GREEN . "Alpinist Key",
            "lore" => [
                C::GRAY . "You can redeem this key at " . C::DARK_GREEN . "Alpinist Crate",
                C::BOLD . C::DARK_GREEN . " * " . C::RESET . C::GRAY . "Right-Click Crate with key to redeem!",
                C::BOLD . C::DARK_GREEN . " * " . C::RESET . C::GRAY . "Right-Click Crate w/o a key to view rewards!",
                "",
                C::GRAY . "Get this key by buying keys at " . C::DARK_GREEN . self::BUYCRAFT_LINK
            ]
         ],
         self::VOYAGER_CRATE => [
            "coords" => "-38:70:27",
            "name" => "§l§8[" . C::RED . "Voyager§8] §7Crate",
            "key" => C::RED . "Voyager Key",
            "lore" => [
                C::GRAY . "You can redeem this key at " . C::RED . "Voyager Crate",
                C::BOLD . C::RED . " * " . C::RESET . C::GRAY . "Right-Click Crate with key to redeem!",
                C::BOLD . C::RED . " * " . C::RESET . C::GRAY . "Right-Click Crate w/o a key to view rewards!",
                "",
                C::GRAY . "Get this key by buying keys at " . C::RED . self::BUYCRAFT_LINK
            ]
         ]];
   }

   /**
      * @param AlpinePlayer $player
      * @param int $type
      * @param int $amount
      */
   public function giveKey(AlpinePlayer $player, int $type, int $amount = 1){
      $key = Item::get(Item::TRIPWIRE_HOOK);
      for($i = $amount; $i > 0; $i--){
         $name = $this->crate[$type]["key"];
         $nametag = $key->getNamedTag();
         $nametag->setInt("keynbt", $type);
         $key->setNamedTag($nametag);
         $key->setCustomName($name);
         $key->setLore($this->crate[$type]["lore"]);
         $key->setNamedTagEntry(new ListTag("ench"));
         $player->getInventory()->addItem($key);
      }
   }

      /**
      * @param AlpinePlayer $player
      */
   public function spawnFloatingText(AlpinePlayer $player){
      $spawnlevel = AlpineCore::$overworldLevel;
      $votecoords = explode(":", $this->crate[0]["coords"]);
      $spawnlevel->addParticle(new FloatingTextParticle(new Vector3((int) $votecoords[0], (int) $votecoords[1] + 2, (int) $votecoords[2]), C::GREEN . "Vote Crate" . C::RESET . "\n" . " " . "\n\n" . "Click with Vote Key for rewards" . "\n" . "Click without Key to view rewards."), [$player]);
      $kothcoords = explode(":", $this->crate[1]["coords"]);
      $spawnlevel->addParticle(new FloatingTextParticle(new Vector3((int) $kothcoords[0], (int) $kothcoords[1] + 2, (int) $kothcoords[2]), C::DARK_RED . "KOTH Crate" . C::RESET . "\n" . " " . "\n\n" . "Click with KOTH Key for rewards" . "\n" . "Click without Key to view rewards."), [$player]);
      $partnercoords = explode(":", $this->crate[2]["coords"]);
      $spawnlevel->addParticle(new FloatingTextParticle(new Vector3((int) $partnercoords[0], (int) $partnercoords[1] + 2, (int) $partnercoords[2]), C::DARK_PURPLE . "Partner Crate" . C::RESET . "\n" . " " . "\n\n" . "Click with Partner Key for rewards" . "\n" . "Click without Key to view rewards."), [$player]);
      $voyagercoords = explode(":", $this->crate[3]["coords"]);
      $spawnlevel->addParticle(new FloatingTextParticle(new Vector3((int) $voyagercoords[0], (int) $voyagercoords[1] + 2, (int) $voyagercoords[2]), C::RED . "Voyager Crate" . C::RESET . "\n" . " " . "\n\n" . "Click with Voyager Key for rewards" . "\n" . "Click without Key to view rewards."), [$player]);
      $pioneercoords = explode(":", $this->crate[4]["coords"]);
      $spawnlevel->addParticle(new FloatingTextParticle(new Vector3((int) $pioneercoords[0], (int) $pioneercoords[1] + 2, (int) $pioneercoords[2]), C::DARK_BLUE . "Pioneer Crate" . C::RESET . "\n" . " " . "\n\n" . "Click with Pioneer Key for rewards" . "\n" . "Click without Key to view rewards."), [$player]);
      $alpinistcoords = explode(":", $this->crate[5]["coords"]);
      $spawnlevel->addParticle(new FloatingTextParticle(new Vector3((int) $alpinistcoords[0], (int) $alpinistcoords[1] + 2, (int) $alpinistcoords[2]), C::DARK_GREEN . "Alpinist Crate" . C::RESET . "\n" . " " . "\n\n" . "Click with Alpinist Key for rewards" . "\n" . "Click without Key to view rewards."), [$player]);
   }

   /**
     * @param int $type
     * @param int $x
     * @param int $y
     * @param int $z
     * @return bool
     */
   public function isCrate(int $type, int $x, int $y, int $z): bool{
       $coords = $this->crate[$type]["coords"];
       $stringedcoords = $x . ":" . $y . ":" . $z;
       if($coords == $stringedcoords){
           return true;
       } else {
           return false;
       }
   }

   /**
     * @param int $type
     * @param Item $item
     * @return bool
     */
   public function isKey(int $type, Item $item): bool{
       $nametag = $item->getNamedTag();
       if($nametag->hasTag("keynbt", IntTag::class)){
           $tag = $nametag->getInt("keynbt");
           if($tag == $type){
               return true;
           } else return false;
       } else return false;
   }

   /**
     * @param AlpinePlayer $player
     * @param int $type
     */
   public function showRewards(AlpinePlayer $player, int $type){
       if($type == 0){
           $menu = InvMenu::create(InvMenu::TYPE_CHEST);
           $menu->readonly();
           $menu->setName("§r§l§1Vote Crate");
           $inventory = $menu->getInventory();
           foreach($this->getItems(0) as $item){
               $inventory->addItem($item);
           }
           $menu->send($player);
       } elseif($type == 1){
           $menu = InvMenu::create(InvMenu::TYPE_CHEST);
           $menu->readonly();
           $menu->setName("§r§l§1KOTH Crate");
           $inventory = $menu->getInventory();
           foreach($this->getItems(1) as $item){
               $inventory->addItem($item);
           }
           $menu->send($player);
       } elseif($type == 2){
           $menu = InvMenu::create(InvMenu::TYPE_CHEST);
           $menu->readonly();
           $menu->setName("§r§l§1Partner Crate");
           $inventory = $menu->getInventory();
           foreach($this->getItems(2) as $item){
               $inventory->addItem($item);
           }
           $menu->send($player);
       } elseif($type == 3){
           $menu = InvMenu::create(InvMenu::TYPE_CHEST);
           $menu->readonly();
           $menu->setName("§r§l§1Voyager Crate");
           $inventory = $menu->getInventory();
           foreach($this->getItems(3) as $item){
               $inventory->addItem($item);
           }
           $menu->send($player);
       } elseif($type == 4){
           $menu = InvMenu::create(InvMenu::TYPE_CHEST);
           $menu->readonly();
           $menu->setName("§r§l§1Pioneer Crate");
           $inventory = $menu->getInventory();
           foreach($this->getItems(4) as $item){
               $inventory->addItem($item);
           }
           $menu->send($player);
       } elseif($type == 5){
           $menu = InvMenu::create(InvMenu::TYPE_CHEST);
           $menu->readonly();
           $menu->setName("§r§l§1Alpinist Crate");
           $inventory = $menu->getInventory();
           foreach($this->getItems(5) as $item){
               $inventory->addItem($item);
           }
           $menu->send($player);
       }
   }
 
   /**
     * @param AlpinePlayer $player
     * @param int $type
     */
   public function openCrate(AlpinePlayer $player, int $type){
       if($type == 0){
           $items = $this->getItems(0);
           $player->getInventory()->addItem($items[array_rand($items)]);
           $player->getInventory()->addItem($items[array_rand($items)]);
       } elseif($type == 1){
           $items = $this->getItems(1);
           $player->getInventory()->addItem($items[array_rand($items)]);
           $player->getInventory()->addItem($items[array_rand($items)]);
       } elseif($type == 2){
           $items = $this->getItems(2);
           $player->getInventory()->addItem($items[array_rand($items)]);
           $player->getInventory()->addItem($items[array_rand($items)]);
       } elseif($type == 3){
           $items = $this->getItems(3);
           $player->getInventory()->addItem($items[array_rand($items)]);
           $player->getInventory()->addItem($items[array_rand($items)]);
       } elseif($type == 4){
           $items = $this->getItems(4);
           $player->getInventory()->addItem($items[array_rand($items)]);
           $player->getInventory()->addItem($items[array_rand($items)]);
       } elseif($type == 5){
           $items = $this->getItems(5);
           $player->getInventory()->addItem($items[array_rand($items)]);
           $player->getInventory()->addItem($items[array_rand($items)]);
       }
   }

   /**
     * @param int $type
     * @returm array
     */
   public function getItems(int $type): array{
       $efficiency = Enchantment::getEnchantment(Enchantment::EFFICIENCY);
       $protection = Enchantment::getEnchantment(Enchantment::PROTECTION);
       $sharpness = Enchantment::getEnchantment(Enchantment::SHARPNESS);
       $lootingenc = Enchantment::getEnchantment(Enchantment::LOOTING);
       $fireaspect = Enchantment::getEnchantment(Enchantment::FIRE_ASPECT);
       $fortune = Enchantment::getEnchantment(Enchantment::FORTUNE);
       $silktouchenc = Enchantment::getEnchantment(Enchantment::SILK_TOUCH);
       $unbreaking = Enchantment::getEnchantment(Enchantment::UNBREAKING);
       $falling = Enchantment::getEnchantment(Enchantment::FEATHER_FALLING);

       if($type == 0){ //vote
 
           $helmet = Item::get(Item::DIAMOND_HELMET);
           $helmet->addEnchantment(new EnchantmentInstance($protection, 1));
           $helmet->addEnchantment(new EnchantmentInstance($unbreaking, 1));
           $helmet->setCustomName("" . "§r§l§7[§bVote§7]§r §7Helmet");
           $chestplate = Item::get(Item::DIAMOND_CHESTPLATE);
           $chestplate->addEnchantment(new EnchantmentInstance($protection, 1));
           $chestplate->addEnchantment(new EnchantmentInstance($unbreaking, 1));
           $chestplate->setCustomName("" . "§r§l§7[" . C::AQUA . "Vote§7]§r §7Chestplate");
           $leggings = Item::get(Item::DIAMOND_LEGGINGS);
           $leggings->addEnchantment(new EnchantmentInstance($protection, 1));
           $leggings->addEnchantment(new EnchantmentInstance($unbreaking, 1));
           $leggings->setCustomName("" . "§r§l§7[" . C::AQUA . "Vote§7]§r §7Leggings");
           $boots = Item::get(Item::DIAMOND_BOOTS);
           $boots->addEnchantment(new EnchantmentInstance($protection, 1));
           $boots->addEnchantment(new EnchantmentInstance($falling, 1));
           $boots->addEnchantment(new EnchantmentInstance($unbreaking, 1));
           $boots->setCustomName("" . "§r§l§7[" . C::AQUA . "Vote§7]§r §7Boots");
           $sword = Item::get(Item::DIAMOND_SWORD);
           $sword->addEnchantment(new EnchantmentInstance($sharpness, 1));
           $sword->addEnchantment(new EnchantmentInstance($unbreaking, 1));
           $looting = Item::get(Item::DIAMOND_SWORD);
           $looting->addEnchantment(new EnchantmentInstance($lootingenc, 1));
           $looting->addEnchantment(new EnchantmentInstance($unbreaking, 1));
           $pickaxe = Item::get(Item::DIAMOND_PICKAXE);
           $pickaxe->addEnchantment(new EnchantmentInstance($efficiency, 1));
           $pickaxe->addEnchantment(new EnchantmentInstance($unbreaking, 1));
           $effpickaxe = Item::get(Item::DIAMOND_PICKAXE);
           $effpickaxe->addEnchantment(new EnchantmentInstance($unbreaking, 1));
           $effpickaxe->addEnchantment(new EnchantmentInstance($fortune, 1));
           $effpickaxe->addEnchantment(new EnchantmentInstance($efficiency, 1));
           $silktouch = Item::get(Item::DIAMOND_PICKAXE);
           $silktouch->addEnchantment(new EnchantmentInstance($unbreaking, 1));
           $silktouch->addEnchantment(new EnchantmentInstance($silktouchenc, 1));
           $silktouch->addEnchantment(new EnchantmentInstance($efficiency, 1));
           $key = Item::get(Item::TRIPWIRE_HOOK, 0, 2);
           $name = $this->crate[4]["key"];
           $nametag = $key->getNamedTag();
           $nametag->setInt("keynbt", 4);
           $key->setNamedTag($nametag);
           $key->setCustomName($name);
           $key->setLore($this->crate[4]["lore"]);
           $key->setNamedTagEntry(new ListTag("ench"));
           $lives = Item::get(Item::DYE, 1);
           $livestag = $lives->getNamedTag();
           $livestag->setInt("lives", 3);
           $lives->setNamedTag($livestag);
           $lives->setCustomName(C::RESET . C::RED . " Lives" . C::GRAY . " Note");
           $lives->setLore(["", C::RESET . C::GRAY . "Redeem Lives from this note!", C::BOLD . C::DARK_GREEN . " * " . C::RESET . C::GRAY . "Right-Click to redeem 3 Lives!", C::BOLD . C::DARK_GREEN . " * " . C::RESET . C::GRAY . "Lives can be used to revive after Deathban!"]);
           $lives->setNamedTagEntry(new ListTag("ench"));
           return [$lives, $helmet, $chestplate, $leggings, $boots, Item::get(Item::BOTTLE_O_ENCHANTING, 0, 8), $pickaxe, $effpickaxe, $silktouch, $looting, $sword, Item::get(Item::APPLE, 0, 1), Item::get(Item::APPLE, 1, 3), Item::get(Item::GOLDEN_APPLE, 0, 3), Item::get(Item::ENCHANTED_GOLDEN_APPLE, 0, 1), $key, Item::get(Item::GOLD_BLOCK, 0, 12), Item::get(Item::IRON_BLOCK, 0, 12), Item::get(Item::DIAMOND_BLOCK, 0, 8), Item::get(Item::EMERALD_BLOCK, 0, 4)];
       } elseif($type == 1){
           $helmet = Item::get(Item::DIAMOND_HELMET);
           $helmet->addEnchantment(new EnchantmentInstance($protection, 3));
           $helmet->addEnchantment(new EnchantmentInstance($unbreaking, 4));
           $helmet->setCustomName("" . "§r§l§7[§cKOTH§7]§r §7Helmet");
           $chestplate = Item::get(Item::DIAMOND_CHESTPLATE);
           $chestplate->addEnchantment(new EnchantmentInstance($protection, 3));
           $chestplate->addEnchantment(new EnchantmentInstance($unbreaking, 4));
           $chestplate->setCustomName("" . "§r§l§7[" . C::RED . "KOTH§7]§r §7Chestplate");
           $leggings = Item::get(Item::DIAMOND_LEGGINGS);
           $leggings->addEnchantment(new EnchantmentInstance($protection, 3));
           $leggings->addEnchantment(new EnchantmentInstance($unbreaking, 4));
           $leggings->setCustomName("" . "§r§l§7[" . C::RED . "KOTH§7]§r §7Leggings");
           $boots = Item::get(Item::DIAMOND_BOOTS);
           $boots->addEnchantment(new EnchantmentInstance($protection, 3));
           $boots->addEnchantment(new EnchantmentInstance($falling, 3));
           $boots->addEnchantment(new EnchantmentInstance($unbreaking, 4));
           $boots->setCustomName("" . "§r§l§7[" . C::RED . "KOTH§7]§r §7Boots");
           $sword = Item::get(Item::DIAMOND_SWORD);
           $sword->addEnchantment(new EnchantmentInstance($sharpness, 3));
           $sword->addEnchantment(new EnchantmentInstance($unbreaking, 4));
           $sword->setCustomName("" . "§r§l§7[" . C::RED . "KOTH Sharpness§7]§r §7Sword");
           $fire = Item::get(Item::DIAMOND_SWORD);
           $fire->addEnchantment(new EnchantmentInstance($sharpness, 2));
           $fire->addEnchantment(new EnchantmentInstance($fireaspect, 1));
           $fire->setCustomName("" . "§r§l§7[" . C::RED . "KOTH Fire§7]§r §7Sword");
           $looting = Item::get(Item::DIAMOND_SWORD);
           $looting->addEnchantment(new EnchantmentInstance($lootingenc, 3));
           $looting->addEnchantment(new EnchantmentInstance($unbreaking, 4));
           $pickaxe = Item::get(Item::DIAMOND_PICKAXE);
           $pickaxe->addEnchantment(new EnchantmentInstance($efficiency, 3));
           $pickaxe->addEnchantment(new EnchantmentInstance($unbreaking, 4));
           $effpickaxe = Item::get(Item::DIAMOND_PICKAXE);
           $effpickaxe->addEnchantment(new EnchantmentInstance($unbreaking, 4));
           $effpickaxe->addEnchantment(new EnchantmentInstance($fortune, 3));
           $effpickaxe->addEnchantment(new EnchantmentInstance($efficiency, 2));
           $silktouch = Item::get(Item::DIAMOND_PICKAXE);
           $silktouch->addEnchantment(new EnchantmentInstance($unbreaking, 3));
           $silktouch->addEnchantment(new EnchantmentInstance($silktouchenc, 1));
           $silktouch->addEnchantment(new EnchantmentInstance($efficiency, 2));
           $key = Item::get(Item::TRIPWIRE_HOOK, 0, 5);
           $name = $this->crate[4]["key"];
           $nametag = $key->getNamedTag();
           $nametag->setInt("keynbt", 4);
           $key->setNamedTag($nametag);
           $key->setCustomName($name);
           $key->setLore($this->crate[4]["lore"]);
           $key->setNamedTagEntry(new ListTag("ench"));
           $voyager = Item::get(Item::TRIPWIRE_HOOK, 0, 5);
           $voyagername = $this->crate[3]["key"];
           $voyagertag = $voyager->getNamedTag();
           $voyagertag->setInt("keynbt", 3);
           $voyager->setNamedTag($voyagertag);
           $voyager->setCustomName($voyagername);
           $voyager->setLore($this->crate[3]["lore"]);
           $voyager->setNamedTagEntry(new ListTag("ench"));
           $alpinist = Item::get(Item::TRIPWIRE_HOOK, 0, 3);
           $alpinistname = $this->crate[5]["key"];
           $alpinisttag = $alpinist->getNamedTag();
           $alpinisttag->setInt("keynbt", 5);
           $alpinist->setNamedTag($alpinisttag);
           $alpinist->setCustomName($alpinistname);
           $alpinist->setLore($this->crate[5]["lore"]);
           $alpinist->setNamedTagEntry(new ListTag("ench"));
           $partner = Item::get(Item::TRIPWIRE_HOOK, 0, 2);
           $partnername = $this->crate[2]["key"];
           $partnertag = $partner->getNamedTag();
           $partnertag->setInt("keynbt", 2);
           $partner->setNamedTag($partnertag);
           $partner->setCustomName($partnername);
           $partner->setLore($this->crate[2]["lore"]);
           $partner->setNamedTagEntry(new ListTag("ench"));
           $lives = Item::get(Item::DYE, 1);
           $livestag = $lives->getNamedTag();
           $livestag->setInt("lives", 12);
           $lives->setNamedTag($livestag);
           $lives->setCustomName(C::RESET . C::DARK_RED . " Lives" . C::GRAY . " Note");
           $lives->setLore(["", C::RESET . C::GRAY . "Redeem Lives from this note!", C::BOLD . C::DARK_GREEN . " * " . C::RESET . C::GRAY . "Right-Click to redeem 12 Lives!", C::BOLD . C::DARK_GREEN . " * " . C::RESET . C::GRAY . "Lives can be used to revive after Deathban!"]);
           $lives->setNamedTagEntry(new ListTag("ench"));
           return [$looting, $pickaxe, $effpickaxe, $silktouch, $lives, $helmet, $chestplate, $leggings, $boots, $key, $voyager, $alpinist, $partner, $sword, $fire, Item::get(Item::GOLDEN_APPLE, 0, 16), Item::get(Item::ENCHANTED_GOLDEN_APPLE, 0, 3), Item::get(Item::GOLD_BLOCK, 0, 48), Item::get(Item::IRON_BLOCK, 0, 48), Item::get(Item::DIAMOND_BLOCK, 0, 32), Item::get(Item::EMERALD_BLOCK, 0, 24)];
       } elseif($type == 2){
           $bone = Item::get(Item::BONE, 0, 3);
           $bone->setNamedTagEntry(new ListTag("ench"));
           $bone->setCustomName(C::RESET . C::RED . "Tax's" . C::RESET. C::GRAY . " Magical Bone");
           $bone->setLore(["", C::GRAY . " Hit a player with this bone and they won't be", C::GRAY . " able to place or break blocks for 15 seconds!", "", C::BOLD . C::RED . "WARNING:" . C::RESET . C::RED . " 2 Minute Cooldown!"]);
           $bonetag = $bone->getNamedTag();
           $bonetag->setString("partneritem", "taxmagicalbone");
           $bone->setNamedTag($bonetag);
           $bard = Item::get(Item::DYE, 14, 3);
           $bard->setNamedTagEntry(new ListTag("ench"));
           $bard->setCustomName(C::RESET . C::GOLD . "Deadly's" . C::RESET. C::GRAY . " Portable Bard");
           $bard->setLore(["", C::GRAY . " Losing a fight to someone with a Bard?", C::GRAY . " use this item to get a few Bard Effects!", "", C::BOLD . C::RED . "WARNING:" . C::RESET . C::RED . " 3 Minute Cooldown!"]);
           $bardtag = $bard->getNamedTag();
           $bardtag->setString("partneritem", "portablebard");
           $bard->setNamedTag($bardtag);
           $epremover = Item::get(Item::STICK, 0, 2);
           $epremover->setNamedTagEntry(new ListTag("ench"));
           $epremover->setCustomName(C::RESET . C::GOLD . "Lord's" . C::RESET. C::GRAY . " EP Cooldown Remover");
           $epremover->setLore(["", C::GRAY . " Are you in a jam and need to make a quick", C::GRAY . " getaway? Use this to remove you on ep cooldown!", "", C::BOLD . C::RED . "WARNING:" . C::RESET . C::RED . " Total of 10 uses!"]);
           $epremovertag = $epremover->getNamedTag();
           $epremovertag->setInt("uses", 10);
           $epremovertag->setString("partneritem", "pearlcooldownremover");
           $epremover->setNamedTag($epremovertag);
           $ninja = Item::get(Item::NETHER_STAR, 0, 1);
           $ninja->setNamedTagEntry(new ListTag("ench"));
           $ninja->setCustomName(C::RESET . C::GOLD . "Anonymous'" . C::RESET. C::GRAY . " Ninja Star");
           $ninja->setLore(["", C::GRAY . " Are you trapped and getting killed? Use this", C::GRAY . " to teleport to the last person that hit you!", "", C::BOLD . C::RED . "WARNING:" . C::RESET . C::RED . " Total of 5 uses! Player also gets a warning!"]);
           $ninjatag = $ninja->getNamedTag();
           $ninjatag->setInt("uses", 5);
           $ninjatag->setString("partneritem", "ninjaability");
           $ninja->setNamedTag($ninjatag);
           $snowball = Item::get(Item::SNOWBALL, 0, 16);
           $snowball->setNamedTagEntry(new ListTag("ench"));
           $snowball->setCustomName(C::BOLD . C::AQUA . "Swapper" . C::RESET. C::GRAY . " Ball");
           $snowball->setLore([C::GRAY . " Switch Positions with anyone that is", C::GRAY . " hit by this ball. Great for trapping!", "", C::BOLD . C::RED . "WARNING:" . C::RESET . C::RED . " 10 Seconds Cooldown!"]);
           $snowball->setCustomBlockData(new CompoundTag("", [new ByteTag("kenzoball", 1)]));
           return [$bone, $bard, $epremover, $ninja, $snowball];
      } elseif($type == 4){
           $helmet = Item::get(Item::DIAMOND_HELMET);
           $helmet->addEnchantment(new EnchantmentInstance($protection, 1));
           $helmet->addEnchantment(new EnchantmentInstance($unbreaking, 2));
           $chestplate = Item::get(Item::DIAMOND_CHESTPLATE);
           $chestplate->addEnchantment(new EnchantmentInstance($protection, 1));
           $chestplate->addEnchantment(new EnchantmentInstance($unbreaking, 2));
           $leggings = Item::get(Item::DIAMOND_LEGGINGS);
           $leggings->addEnchantment(new EnchantmentInstance($protection, 1));
           $leggings->addEnchantment(new EnchantmentInstance($unbreaking, 2));
           $boots = Item::get(Item::DIAMOND_BOOTS);
           $boots->addEnchantment(new EnchantmentInstance($protection, 1));
           $boots->addEnchantment(new EnchantmentInstance($unbreaking, 2));
           $sword = Item::get(Item::DIAMOND_SWORD);
           $sword->addEnchantment(new EnchantmentInstance($sharpness, 1));
           $sword->addEnchantment(new EnchantmentInstance($unbreaking, 2));
           $looting = Item::get(Item::DIAMOND_SWORD);
           $looting->addEnchantment(new EnchantmentInstance($lootingenc, 1));
           $looting->addEnchantment(new EnchantmentInstance($unbreaking, 2));
           $pickaxe = Item::get(Item::DIAMOND_PICKAXE);
           $pickaxe->addEnchantment(new EnchantmentInstance($efficiency, 2));
           $pickaxe->addEnchantment(new EnchantmentInstance($unbreaking, 2));
           $effpickaxe = Item::get(Item::DIAMOND_PICKAXE);
           $effpickaxe->addEnchantment(new EnchantmentInstance($unbreaking, 2));
           $effpickaxe->addEnchantment(new EnchantmentInstance($fortune, 1));
           $effpickaxe->addEnchantment(new EnchantmentInstance($efficiency, 1));
           $silktouch = Item::get(Item::DIAMOND_PICKAXE);
           $silktouch->addEnchantment(new EnchantmentInstance($unbreaking, 1));
           $silktouch->addEnchantment(new EnchantmentInstance($silktouchenc, 1));
           $silktouch->addEnchantment(new EnchantmentInstance($efficiency, 1));
           $voyager = Item::get(Item::TRIPWIRE_HOOK, 0, 2);
           $voyagername = $this->crate[3]["key"];
           $voyagertag = $voyager->getNamedTag();
           $voyagertag->setInt("keynbt", 3);
           $voyager->setNamedTag($voyagertag);
           $voyager->setCustomName($voyagername);
           $voyager->setLore($this->crate[3]["lore"]);
           $voyager->setNamedTagEntry(new ListTag("ench"));
           $alpinist = Item::get(Item::TRIPWIRE_HOOK, 0, 1);
           $alpinistname = $this->crate[5]["key"];
           $alpinisttag = $alpinist->getNamedTag();
           $alpinisttag->setInt("keynbt", 5);
           $alpinist->setNamedTag($alpinisttag);
           $alpinist->setCustomName($alpinistname);
           $alpinist->setLore($this->crate[5]["lore"]);
           $alpinist->setNamedTagEntry(new ListTag("ench"));
           $lives = Item::get(Item::DYE, 1);
           $livestag = $lives->getNamedTag();
           $livestag->setInt("lives", 4);
           $lives->setNamedTag($livestag);
           $lives->setCustomName(C::RESET . C::DARK_RED . " Lives" . C::GRAY . " Note");
           $lives->setLore(["", C::RESET . C::GRAY . "Redeem Lives from this note!", C::BOLD . C::DARK_GREEN . " * " . C::RESET . C::GRAY . "Right-Click to redeem 4 Lives!", C::BOLD . C::DARK_GREEN . " * " . C::RESET . C::GRAY . "Lives can be used to revive after Deathban!"]);
           $lives->setNamedTagEntry(new ListTag("ench"));
           return [$lives, $helmet, $chestplate, $leggings, $boots, $voyager, $alpinist, $sword, $looting, $pickaxe, $effpickaxe, $silktouch, Item::get(Item::GOLDEN_APPLE, 0, 4), Item::get(Item::ENCHANTED_GOLDEN_APPLE, 0, 1), Item::get(Item::GOLD_BLOCK, 0, 16), Item::get(Item::IRON_BLOCK, 0, 16), Item::get(Item::DIAMOND_BLOCK, 0, 16), Item::get(Item::EMERALD_BLOCK, 0, 16)];
      } elseif($type == 3){
           $helmet = Item::get(Item::DIAMOND_HELMET);
           $helmet->addEnchantment(new EnchantmentInstance($protection, 1));
           $helmet->addEnchantment(new EnchantmentInstance($unbreaking, 3));
           $chestplate = Item::get(Item::DIAMOND_CHESTPLATE);
           $chestplate->addEnchantment(new EnchantmentInstance($protection, 1));
           $chestplate->addEnchantment(new EnchantmentInstance($unbreaking, 3));
           $leggings = Item::get(Item::DIAMOND_LEGGINGS);
           $leggings->addEnchantment(new EnchantmentInstance($protection, 1));
           $leggings->addEnchantment(new EnchantmentInstance($unbreaking, 3));
           $boots = Item::get(Item::DIAMOND_BOOTS);
           $boots->addEnchantment(new EnchantmentInstance($protection, 1));
           $boots->addEnchantment(new EnchantmentInstance($unbreaking, 3));
           $sword = Item::get(Item::DIAMOND_SWORD);
           $sword->addEnchantment(new EnchantmentInstance($sharpness, 1));
           $sword->addEnchantment(new EnchantmentInstance($unbreaking, 3));
           $looting = Item::get(Item::DIAMOND_SWORD);
           $looting->addEnchantment(new EnchantmentInstance($lootingenc, 2));
           $looting->addEnchantment(new EnchantmentInstance($unbreaking, 3));
           $pickaxe = Item::get(Item::DIAMOND_PICKAXE);
           $pickaxe->addEnchantment(new EnchantmentInstance($efficiency, 2));
           $pickaxe->addEnchantment(new EnchantmentInstance($unbreaking, 3));
           $effpickaxe = Item::get(Item::DIAMOND_PICKAXE);
           $effpickaxe->addEnchantment(new EnchantmentInstance($unbreaking, 2));
           $effpickaxe->addEnchantment(new EnchantmentInstance($fortune, 2));
           $effpickaxe->addEnchantment(new EnchantmentInstance($efficiency, 2));
           $silktouch = Item::get(Item::DIAMOND_PICKAXE);
           $silktouch->addEnchantment(new EnchantmentInstance($unbreaking, 2));
           $silktouch->addEnchantment(new EnchantmentInstance($silktouchenc, 1));
           $silktouch->addEnchantment(new EnchantmentInstance($efficiency, 1));
           $alpinist = Item::get(Item::TRIPWIRE_HOOK, 0, 2);
           $alpinistname = $this->crate[5]["key"];
           $alpinisttag = $alpinist->getNamedTag();
           $alpinisttag->setInt("keynbt", 5);
           $alpinist->setNamedTag($alpinisttag);
           $alpinist->setCustomName($alpinistname);
           $alpinist->setLore($this->crate[5]["lore"]);
           $alpinist->setNamedTagEntry(new ListTag("ench"));
           $lives = Item::get(Item::DYE, 1);
           $livestag = $lives->getNamedTag();
           $livestag->setInt("lives", 6);
           $lives->setNamedTag($livestag);
           $lives->setCustomName(C::RESET . C::DARK_RED . " Lives" . C::GRAY . " Note");
           $lives->setLore(["", C::RESET . C::GRAY . "Redeem Lives from this note!", C::BOLD . C::DARK_GREEN . " * " . C::RESET . C::GRAY . "Right-Click to redeem 6 Lives!", C::BOLD . C::DARK_GREEN . " * " . C::RESET . C::GRAY . "Lives can be used to revive after Deathban!"]);
           $lives->setNamedTagEntry(new ListTag("ench"));
           return [$lives, $helmet, $chestplate, $leggings, $boots, $alpinist, $sword, $looting, $pickaxe, $effpickaxe, $silktouch, Item::get(Item::GOLDEN_APPLE, 0, 8), Item::get(Item::ENCHANTED_GOLDEN_APPLE, 0, 1), Item::get(Item::GOLD_BLOCK, 0, 24), Item::get(Item::IRON_BLOCK, 0, 24), Item::get(Item::DIAMOND_BLOCK, 0, 24), Item::get(Item::EMERALD_BLOCK, 0, 24)];
      } elseif($type == 5){
           $helmet = Item::get(Item::DIAMOND_HELMET);
           $helmet->addEnchantment(new EnchantmentInstance($protection, 2));
           $helmet->addEnchantment(new EnchantmentInstance($unbreaking, 1));
           $chestplate = Item::get(Item::DIAMOND_CHESTPLATE);
           $chestplate->addEnchantment(new EnchantmentInstance($protection, 2));
           $chestplate->addEnchantment(new EnchantmentInstance($unbreaking, 1));
           $leggings = Item::get(Item::DIAMOND_LEGGINGS);
           $leggings->addEnchantment(new EnchantmentInstance($protection, 2));
           $leggings->addEnchantment(new EnchantmentInstance($unbreaking, 1));
           $boots = Item::get(Item::DIAMOND_BOOTS);
           $boots->addEnchantment(new EnchantmentInstance($protection, 2));
           $boots->addEnchantment(new EnchantmentInstance($unbreaking, 1));
           $sword = Item::get(Item::DIAMOND_SWORD);
           $sword->addEnchantment(new EnchantmentInstance($sharpness, 2));
           $sword->addEnchantment(new EnchantmentInstance($unbreaking, 1));
           $looting = Item::get(Item::DIAMOND_SWORD);
           $looting->addEnchantment(new EnchantmentInstance($lootingenc, 3));
           $looting->addEnchantment(new EnchantmentInstance($unbreaking, 2));
           $pickaxe = Item::get(Item::DIAMOND_PICKAXE);
           $pickaxe->addEnchantment(new EnchantmentInstance($efficiency, 3));
           $pickaxe->addEnchantment(new EnchantmentInstance($unbreaking, 1));
           $effpickaxe = Item::get(Item::DIAMOND_PICKAXE);
           $effpickaxe->addEnchantment(new EnchantmentInstance($unbreaking, 1));
           $effpickaxe->addEnchantment(new EnchantmentInstance($fortune, 3));
           $effpickaxe->addEnchantment(new EnchantmentInstance($efficiency, 2));
           $silktouch = Item::get(Item::DIAMOND_PICKAXE);
           $silktouch->addEnchantment(new EnchantmentInstance($unbreaking, 3));
           $silktouch->addEnchantment(new EnchantmentInstance($silktouchenc, 1));
           $silktouch->addEnchantment(new EnchantmentInstance($efficiency, 1));
           $lives = Item::get(Item::DYE, 1);
           $livestag = $lives->getNamedTag();
           $livestag->setInt("lives", 8);
           $lives->setNamedTag($livestag);
           $lives->setCustomName(C::RESET . C::DARK_RED . " Lives" . C::GRAY . " Note");
           $lives->setLore(["", C::RESET . C::GRAY . "Redeem Lives from this note!", C::BOLD . C::DARK_GREEN . " * " . C::RESET . C::GRAY . "Right-Click to redeem 8 Lives!", C::BOLD . C::DARK_GREEN . " * " . C::RESET . C::GRAY . "Lives can be used to revive after Deathban!"]);
           $lives->setNamedTagEntry(new ListTag("ench"));
           return [$lives, $helmet, $chestplate, $leggings, $boots, $sword, $looting, $pickaxe, $effpickaxe, $silktouch, Item::get(Item::GOLDEN_APPLE, 0, 16), Item::get(Item::ENCHANTED_GOLDEN_APPLE, 0, 2), Item::get(Item::GOLD_BLOCK, 0, 32), Item::get(Item::IRON_BLOCK, 0, 32), Item::get(Item::DIAMOND_BLOCK, 0, 32), Item::get(Item::EMERALD_BLOCK, 0, 32)];
       }
   }
}