<?php
declare(strict_types=1);
namespace hcf\manager;

use hcf\{
    AlpineCore, AlpinePlayer, utils\Utils,
    tasks\async\MuteOfflineTask, tasks\async\BanTask, tasks\async\UnBanTask, tasks\async\PlayerInfoTask};
use jojoe77777\FormAPI\{
    CustomForm, SimpleForm, ModalForm};
use pocketmine\utils\TextFormat as TF;

class PunishManager {

    private $plugin;

    /**
     * @param AlpineCore $plugin
     */
    public function __construct(AlpineCore $plugin){
        $this->plugin = $plugin;
    }

    /**
     * @param AlpinePlayer $player
     */
    public function openPunishMenu(AlpinePlayer $player){
        $form = new SimpleForm(function (AlpinePlayer $player, int $data = null) {
            $result = $data;
            if($result === null) return true;
            switch($result){
                case 0:
                    $this->openMuteMenu($player);
                    break;
                case 1:
                    $this->openKickMenu($player);
                    break;
                case 2:
                    $this->openBanMenu($player);
                    break;
                case 3:
                    $this->openUnBanMenu($player);
                    break;
                case 4:
                    $this->openPlayerInfoMenu($player);
                    break;
            }
        });
        $form->setTitle("Punishment Menu");
        $form->setContent("Welcome to Staff Menu, Choose to switch menus!");
        $form->addButton("Mute Menu");
        $form->addButton("Kick Menu");
        $form->addButton("Ban Menu");
        $form->addButton("Unban Player");
        $form->addButton("Player Info");
        $form->addButton("Close");
        $form->sendToPlayer($player);
    }

    /**
     * @param AlpinePlayer $player
     */
    public function openMuteMenu(AlpinePlayer $player){
        $form = new CustomForm(function (AlpinePlayer $player, array $data = null) {
            if(isset($data[0])){
                $punishee = AlpineCore::getInstance()->getServer()->getPlayer($player->getPunishee());
                if($punishee !== null){
                    $time = (int) time() + ($data[0] * 60);
                    $tme = (int) $data[0] * 60;
                    $punishee->setMutedTime($time);
                    $player->sendMessage(TF::GRAY . "You successfully muted " . TF::GREEN . $punishee->getName() . " for " . Utils::intToTime($tme));
                } else {
                    $time = (int) time() + ($data[0] * 60);
                    $tme = (int) $data[0] * 60;
                    $async = AlpineCore::getInstance()->getServer()->getAsyncPool();
                    $punishee = $player->getPunishee();
                    $async->submitTask(new MuteOfflineTask($time, $player->getName(), $punishee));
                }
            } else $this->openPunishMenu($player);
        });
        $form->setTitle("Mute Menu");
        $form->addInput("Mute Time (in minutes): ");
        $form->sendToPlayer($player);
    }

    /**
     * @param AlpinePlayer $player
     */
    public function openKickMenu(AlpinePlayer $player){
        $form = new CustomForm(function (AlpinePlayer $player, array $data = null) {
            if(isset($data[0])){
                $punishee = AlpineCore::getInstance()->getServer()->getPlayer($player->getPunishee());
                if($punishee !== null){
                    $msg = $data[0];
                    $reason = TF::RESET . TF::GRAY . "You have been kicked by " . TF::RED .  $player->getName() . TF::RESET . "\n" . TF::GRAY . "If you think was a mistake, report on our discord: " . TF::RED . "discord.alpinehcf.net" . TF::RESET . "\n\n" . TF::GRAY . "Reason: " . TF::RED . $msg;
                    $punishee->kick($reason, false);
                    $player->sendMessage(TF::GRAY . "You successfully kicked " . TF::GREEN . $punishee->getName());
                } else {
                    $player->sendMessage(TF::GRAY . "That player is offline cant kick");
                }
            } else $this->openPunishMenu($player);
        });
        $form->setTitle("Kick Menu");
        $form->addInput("Kick Reason: ");
        $form->sendToPlayer($player);
    }

    /**
     * @param AlpinePlayer $player
     */
    public function openBanMenu(AlpinePlayer $player){
        $form = new CustomForm(function (AlpinePlayer $player, array $data = null) {
            if(isset($data[0]) && isset($data[1]) && isset($data[2]) && isset($data[3])){
                $reason = $data[3];
                $punishee = AlpineCore::getInstance()->getServer()->getPlayer($player->getPunishee());
                if($player->hasPermission("core.ban")){
                    if($data[0] == true){
                        switch($data[1]){
                            case 0:
                                $multiplier = 60 * 60;
                                break;
                            case 1:
                                $multiplier = 60 * 60 * 24;
                                break;
                            case 2:
                                $multiplier = 60 * 60 * 24 * 7;
                                break;
                        }
                        $time = time() + (int) ($data[2] * $multiplier);
                        $async = AlpineCore::getInstance()->getServer()->getAsyncPool();
                        $async->submitTask(new BanTask($player->getName(), $player->getPunishee(), $reason, $time, true));
                    } else {
                        switch($data[1]){
                            case 0:
                                $multiplier = 60 * 60;
                                break;
                            case 1:
                                $multiplier = 60 * 60 * 24;
                                break;
                            case 2:
                                $multiplier = 60 * 60 * 24 * 7;
                                break;
                        }
                        $time = time() + (int) ($data[2] * $multiplier);
                        $async = AlpineCore::getInstance()->getServer()->getAsyncPool();
                        $async->submitTask(new BanTask($player->getName(), $player->getPunishee(), $reason, $time, false));
                    }
                }
            } else $this->openPunishMenu($player);
        });
        $form->setTitle("Ban Menu");
        $form->addToggle("Silent Ban");
        $form->addDropdown("Time Selector", ["Hours", "Days", "Weeks"]);
        $form->addInput("Insert Time: ");
        $form->addInput("Reason: ");
        $form->sendToPlayer($player);
    }


    /**
     * @param AlpinePlayer $player
     */
    public function openUnBanMenu(AlpinePlayer $player){
        $form = new SimpleForm(function (AlpinePlayer $player, int $data = null) {
            $result = $data;
            if($result === null) return true;
            switch($result){
                case 0:
                    $async = AlpineCore::getInstance()->getServer()->getAsyncPool();
                    $async->submitTask(new UnBanTask($player->getName(), $player->getPunishee()));
                    break;
                case 1:
                    $this->openPunishMenu($player);
                    break;
            }
        });
        $form->setTitle("UnBan Menu");
        $form->setContent("Are you sure you wish to unban this player?");
        $form->addButton("Confirm");
        $form->addButton("Go Back");
        $form->addButton("Close");
        $form->sendToPlayer($player);
    }

    /**
     * @param AlpinePlayer $player
     */
    public function openPlayerInfoMenu(AlpinePlayer $player){
        $async = AlpineCore::getInstance()->getServer()->getAsyncPool();
        $async->submitTask(new PlayerInfoTask($player->getName(), $player->getPunishee()));
    }
}