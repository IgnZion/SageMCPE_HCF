<?php
declare(strict_types=1);
namespace hcf\manager;

use hcf\{AlpineCore, AlpinePlayer, tasks\ZombieTask};
use pocketmine\item\Item;
use pocketmine\math\Vector3;
use pocketmine\entity\Entity;
use Heisenburger69\BurgerSpawners\Entities\Zombie;
use pocketmine\utils\TextFormat as TF;
use pocketmine\nbt\tag\{CompoundTag, ListTag, DoubleTag, FloatTag};

class LoggerManager {

    private $plugin;
    private $zombies = [];

    /**
     * @param AlpineCore $plugin
     */
    public function __construct(AlpineCore $plugin){
        $this->plugin = $plugin;
    }

    /**
     * @return array
     */
    public function getZombies(): array {
        return $this->zombies;
    }

    /**
     * @param string $name
     * @return bool
     */
    public function isZombie(string $name): bool {
        return isset($this->zombies[$name]);
    }

    /**
     * @param AlpinePlayer $player
     */
    public function spawnZombie(AlpinePlayer $player) {
        $nbt = new CompoundTag("", ["Pos" => new ListTag("Pos", [new DoubleTag("", $player->x), new DoubleTag("", $player->y + 1), new DoubleTag("", $player->z)]), "Motion" => new ListTag("Motion", [new DoubleTag("", 0), new DoubleTag("", 0), new DoubleTag("", 0)]), "Rotation" => new ListTag("Rotation", [new FloatTag("", mt_rand() / mt_getrandmax() * 360), new FloatTag("", 0)]),]);
        $entity = Entity::createEntity("Zombie", $player->getLevel(), $nbt);
        $entity->setMaxHealth(20);
        $entity->setHealth(20);
        $entity->setNameTagVisible(true);
        $entity->setNameTagAlwaysVisible(true);
        $entity->setNameTag($player->getName());
        $entity->spawnToAll();
        new ZombieTask(AlpineCore::getInstance(), $entity, $player);
        if($player->isInFaction()){
            $this->zombies[$player->getName()] = ["inv" => $player->getInventory()->getContents(), "armor" => $player->getArmorInventory()->getContents(), "faction" => $player->getFaction()];
        } else {
            $this->zombies[$player->getName()] = ["inv" => $player->getInventory()->getContents(), "armor" => $player->getArmorInventory()->getContents(), "faction" => "no-faction-for-entity"];
        }
    }

    /**
     * @param string $name
     * @return array
     */
    public function getInventoryDrops(string $name): array {
        return $this->getZombies()[$name]["inv"];
    }

    /**
     * @param string $name
     * @return array
     */
    public function getArmorDrops(string $name) : array {
        return $this->getZombies()[$name]["armor"];
    }

    /**
     * @param string $name
     * @return string
     */
    public function getFaction(string $name) : string {
        return $this->getZombies()[$name]["faction"];
    }

    /**
     * @param string $name
     */
    public function removeZombie(string $name) {
        unset($this->zombies[$name]);
    }
}