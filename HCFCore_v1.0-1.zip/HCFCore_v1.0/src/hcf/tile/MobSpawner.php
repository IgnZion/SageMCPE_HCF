<?php
declare(strict_types=1);
namespace hcf\tile;

use hcf\AlpineCore;
use pocketmine\{Player, entity\Entity, item\Item, tile\Spawnable};
use pocketmine\nbt\tag\{IntTag, CompoundTag, ShortTag, StringTag};

class MobSpawner extends Spawnable {

    /** @var string */
    public const
        TAG_ENTITY_ID = "EntityId",
        TAG_SPAWN_COUNT = "SpawnCount",
        TAG_SPAWN_RANGE = "SpawnRange",
        TAG_MIN_SPAWN_DELAY = "MinSpawnDelay",
        TAG_MAX_SPAWN_DELAY = "MaxSpawnDelay",
        TAG_DELAY = "Delay";

    /** @var int */
    protected $entityId = 0;
    /** @var int */
    protected $spawnCount = 4;
    /** @var int */
    protected $spawnRange = 4;
    /** @var int */
    protected $minSpawnDelay = 200;
    /** @var int */
    protected $maxSpawnDelay = 800;
    /** @var int */
    protected $delay;

    /**
     * @return string
     */
    public function getName(): string {
        return "Monster Spawner";
    }

    /**
     * @return bool
     */
    public function onUpdate(): bool {
        if($this->isClosed()) return false;
        $this->timings->startTiming();
        if($this->canUpdate()){
            if($this->delay <= 0){
                $success = false;
                for($i = 0; $i < $this->getSpawnCount(); $i++){
                    $pos = $this->add(mt_rand() / mt_getrandmax() * $this->getSpawnRange(),  mt_rand(-1, 1), mt_rand() / mt_getrandmax() * $this->getSpawnRange());
                    $target = $this->getLevel()->getBlock($pos);
                    if($target->getId() == Item::AIR){
                        $success = true;
                        $entity = Entity::createEntity($this->getEntityId(), $this->getLevel(), Entity::createBaseNBT($target->add(0.5, 0, 0.5), null, lcg_value() * 360, 0));
                        if($entity instanceof Entity){
                            $entity->spawnToAll();
                        }
                    }
                }
                if($success) $this->generateRandomDelay();
            } else {
                $this->delay--;
            }
        }
        $this->timings->stopTiming();
        return true;
    }

    /**
     * @return bool
     */
    public function canUpdate(): bool {
        if($this->getEntityId() != 0 && $this->getLevel()->isChunkLoaded($this->getX() >> 4, $this->getZ() >> 4)){
            $hasPlayer = false;
            $count = 0;
            foreach($this->getLevel()->getEntities() as $entity){
                if($entity instanceof Player && $entity->distance($this) <= 15){
                    $hasPlayer = true;
                }
                if($entity::NETWORK_ID == $this->getEntityId()){
                    $count++;
                }
            }
            return ($hasPlayer && $count < 15);
        }
        return false;
    }

    /**
     * @return int
     */
    protected function generateRandomDelay(): int {
        return ($this->delay = mt_rand($this->getMinSpawnDelay(), $this->getMaxSpawnDelay()));
    }

    /**
     * @param CompoundTag $nbt
     * @return void
     */
    public function addAdditionalSpawnData(CompoundTag $nbt): void {
        $this->applyBaseNBT($nbt);
    }

    /**
     * @param CompoundTag $nbt
     * @return void
     */
    public function applyBaseNBT(CompoundTag $nbt): void {
        $nbt->setInt(self::TAG_ENTITY_ID, $this->getEntityId());
        $nbt->setInt(self::TAG_SPAWN_COUNT, $this->getSpawnCount());
        $nbt->setInt(self::TAG_SPAWN_RANGE, $this->getSpawnRange());
        $nbt->setInt(self::TAG_MIN_SPAWN_DELAY, $this->getMinSpawnDelay());
        $nbt->setInt(self::TAG_MAX_SPAWN_DELAY, $this->getMaxSpawnDelay());
        $nbt->setInt(self::TAG_DELAY, $this->getDelay());
    }

    /**
     * @return int
     */
    public function getEntityId(): int {
        return $this->entityId;
    }

    /**
     * @param int $id
     * @return void
     */
    public function setEntityId(int $id): void {
        $this->entityId = $id;
        $this->onChanged();
        $this->scheduleUpdate();
    }

    /**
     * @return int
     */
    public function getSpawnCount(): int {
        return $this->spawnCount;
    }

    /**
     * @param int $count
     * @return void
     */
    public function setSpawnCount(int $count): void {
        $this->spawnCount = $count;
    }

    /**
     * @return int
     */
    public function getSpawnRange(): int {
        return $this->spawnRange;
    }

    /**
     * @param int $range
     * @return void
     */
    public function setSpawnRange(int $range): void {
        $this->spawnRange = $range;
    }

    /**
     * @return int
     */
    public function getMinSpawnDelay(): int {
        return $this->minSpawnDelay;
    }

    /**
     * @param int $delay
     * @return void
     */
    public function setMinSpawnDelay(int $delay): void {
        $this->minSpawnDelay = $delay;
    }

    /**
     * @return int
     */
    public function getMaxSpawnDelay(): int {
        return $this->maxSpawnDelay;
    }

    /**
     * @param int $delay
     * @return void
     */
    public function setMaxSpawnDelay(int $delay): void {
        $this->maxSpawnDelay = $delay;
    }

    /**
     * @return int
     */
    public function getDelay(): int {
        return $this->delay;
    }

    /**
     * @param int $delay
     * @return void
     */
    public function setDelay(int $delay): void {
        $this->delay = $delay;
    }

    /**
     * @param CompoundTag $nbt
     * @return void
     */
    protected function writeSaveData(CompoundTag $nbt): void {
        $this->applyBaseNBT($nbt);
    }

    /**
     * @param CompoundTag $nbt
     * @return void
     */
    public function readSaveData(CompoundTag $nbt): void {
        if($this->delay === null) $this->generateRandomDelay();
        if($nbt->hasTag(self::TAG_SPAWN_COUNT, ShortTag::class) || $nbt->hasTag(self::TAG_ENTITY_ID, StringTag::class)){
            $nbt->removeTag(self::TAG_ENTITY_ID);
            $nbt->removeTag(self::TAG_SPAWN_COUNT);
            $nbt->removeTag(self::TAG_SPAWN_RANGE);
            $nbt->removeTag(self::TAG_MIN_SPAWN_DELAY);
            $nbt->removeTag(self::TAG_MAX_SPAWN_DELAY);
            $nbt->removeTag(self::TAG_DELAY);
        }
        if(!$nbt->hasTag(self::TAG_ENTITY_ID, IntTag::class)){
            $nbt->setInt(self::TAG_ENTITY_ID, $this->entityId);
        }
        if(!$nbt->hasTag(self::TAG_SPAWN_COUNT, IntTag::class)){
            $nbt->setInt(self::TAG_SPAWN_COUNT, $this->spawnCount);
        }
        if(!$nbt->hasTag(self::TAG_SPAWN_RANGE, IntTag::class)){
            $nbt->setInt(self::TAG_SPAWN_RANGE, $this->spawnRange);
        }
        if(!$nbt->hasTag(self::TAG_MIN_SPAWN_DELAY, IntTag::class)){
            $nbt->setInt(self::TAG_MIN_SPAWN_DELAY, $this->minSpawnDelay);
        }
        if(!$nbt->hasTag(self::TAG_MAX_SPAWN_DELAY, IntTag::class)){
            $nbt->setInt(self::TAG_MAX_SPAWN_DELAY, $this->maxSpawnDelay);
        }
        if(!$nbt->hasTag(self::TAG_DELAY, IntTag::class)){
            $nbt->setInt(self::TAG_DELAY, $this->delay);
        }
        $this->delay = $nbt->getInt(self::TAG_MAX_SPAWN_DELAY, $this->delay);
        $this->scheduleUpdate();
    }
}