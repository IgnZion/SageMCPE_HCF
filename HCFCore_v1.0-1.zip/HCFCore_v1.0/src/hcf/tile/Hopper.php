<?php
declare(strict_types=1);
namespace hcf\tile;

use hcf\blocks\Hopper as HopperBlock;
use hcf\{AlpineCore, inventory\HopperInventory};
use pocketmine\{Player, Server};
use pocketmine\nbt\tag\{NBT, CompoundTag, ListTag};
use pocketmine\{entity\object\ItemEntity, item\Item, level\Level, math\Vector3};
use pocketmine\inventory\{ChestInventory, DoubleChestInventory, InventoryHolder};
use pocketmine\tile\{Chest, Container, ContainerTrait, Nameable, NameableTrait, Spawnable};

class Hopper extends Spawnable implements InventoryHolder, Container, Nameable {
    use NameableTrait;
    use ContainerTrait;
    /** @var HopperInventory */
    private $inventory = null;
    /** @var CompoundTag */
    private $nbt;

    /**
     * @param Level $level
     * @param CompoundTag $nbt
     */
    public function __construct(Level $level, CompoundTag $nbt){
        parent::__construct($level, $nbt);
        $this->inventory = new HopperInventory($this);
        $this->loadItems($nbt);
        $this->scheduleUpdate();
    }

    protected static function createAdditionalNBT(CompoundTag $nbt, Vector3 $pOS, ?int $face = null, ?Item $item = null, ?Player $player = null): void {
        $nbt->setTag(new ListTag("Items", [], NBT::TAG_Compound));
        if($item !== null && $item->hasCustomName()){
            $nbt->setString("CustomName", $item->getCustomName());
        }
    }

    public function getRealInventory(){
        return $this->inventory;
    }

    public function getInventory(){
        return $this->inventory;
    }

    public function getSize(): int {
        return 5;
    }

    public function getDefaultName(): string {
        return "Hopper";
    }

    public function addAdditioalSpawnData(CompoundTag $nbt): void {
        if($this->hasName()){
            $nbt->setTag($this->nbt->getTag("CustomName"));
        }
    }

    public function close(): void {
        if(!$this->isClosed()){
            foreach($this->getInventory()->getViewers() as $viewer){
                $viewer->removeWindow($this->getInventory());
            }
            parent::close();
        }
    }

    public function onUpdate(): bool{
        if((Server::getInstance()->getTick() % 8) == 0){
            if(!($this->getBlock() instanceof HopperBlock)){
                return false;
            }
            $bbox = $this->getBlock()->getBoundingBox();
            $bbox->maxY += round(($bbox->maxY + 1), 0, PHP_ROUND_HALF_UP);
            foreach($this->getLevel()->getNearbyEntities($bbox) as $entity){
                if(!($entity instanceof ItemEntity) || !$entity->isAlive() || $entity->isFlaggedForDespawn() || $entity->isClosed()){
                    continue;
                }
                $item = $entity->getItem();
                if($item instanceof Item){
                    if($item->isNull()){
                        $entity->kill();
                        continue;
                    }
                    $itemClone = clone $item;
                    $itemClone->setCount(1);
                    if($this->inventory->canAddItem($itemClone)){
                        $this->inventory->addItem($itemClone);
                        $item->count--;
                        if($item->getCount() <= 0){
                            $entity->flagForDespawn();
                        }
                    }
                }
            }
            $source = $this->getLevel()->getTile($this->getBlock()->getSide(Vector3::SIDE_UP));
            if($source instanceof Container){
                $inventory = $source->getInventory();
                $firstOccupied = null;
                for($index = 0; $index < $inventory->getSize(); $index++){
                    if(!$inventory->getItem($index)->isNull()){
                        $firstOccupied = $index;
                        break;
                    }
                }
                if($firstOccupied != null){
                    $item = clone $inventory->getItem($firstOccupied);
                    $item->setCount(1);
                    if(!$item->isNull()){
                        if($this->inventory->canAddItem($item)){
                            $this->inventory->addItem($item);
                            $inventory->removeItem($item);
                            $inventory->sendContents($inventory->getViewers());
                            if($source instanceof Chest){
                                if($source->isPaired()){
                                    $pair = $source->getPair();
                                    $pinv = $pair->getInventory();
                                    $pinv->sendContents($pinv->getViewers());
                                }
                            }
                        }
                    }
                }
            }
            if(!($this->getLevel()->getTile($this->getBlock()->getSide(Vector3::SIDE_DOWN)) instanceof Hopper)){
                $target = $this->getLevel()->getTile($this->getBlock()->getSide($this->getBlock()->getDamage()));
                if($target instanceof Container){
                    $inv = $target->getInventory();
                    foreach($this->inventory->getContents() as $item){
                        if($item->isNull()){
                            continue;
                        }
                        $targetItem = clone $item;
                        $targetItem->setCount(1);
                        if($inv instanceof DoubleChestInventory){
                            $left = $inv->getLeftSide();
                            $right = $inv->getRightSide();
                            if($right->canAddItem($targetItem)){
                                $inv = $right;
                            } else {
                                $inv = $left;
                            }
                        }
                        if($inv->canAddItem($targetItem)){
                            $inv->addItem($targetItem);
                            $this->inventory->removeItem($targetItem);
                            $inv->sendContents($inv->getViewers());
                        }
                        if($target instanceof Chest){
                            if($target->isPaired()){
                                $pair = $target->getPair();
                                $pinv = $pair->getInventory();
                                $pinv->sendContents($pinv->getViewers());
                            }
                        }
                    }
                }
            }
        }
        return true;
    }

    public function saveNBT(): CompoundTag {
        $this->saveItems($this->nbt);
        return parent::saveNBT();
    }

    protected function readSaveData(CompoundTag $nbt): void {
        $this->nbt = $nbt;
    }

    protected function writeSaveData(CompoundTag $nbt): void {
    }
}