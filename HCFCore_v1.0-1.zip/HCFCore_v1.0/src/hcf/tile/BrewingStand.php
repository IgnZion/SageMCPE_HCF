<?php
declare(strict_types = 1);
namespace hcf\tile;

use hcf\{AlpineCore, AlpinePlayer};
use pocketmine\inventory\{DoubleChestInventory, InventoryHolder};
use pocketmine\item\Item;
use pocketmine\level\Level;
use pocketmine\math\Vector3;
use jojoe77777\FormAPI\{CustomForm, SimpleForm, ModalForm};
use pocketmine\nbt\tag\{ByteTag, CompoundTag, IntTag, ShortTag};
use pocketmine\network\mcpe\protocol\{ContainerSetDataPacket, LevelSoundEventPacket};
use pocketmine\tile\{Chest, Container, ContainerTrait, Nameable, NameableTrait, Spawnable};

class BrewingStand extends Spawnable {

    /** @var string */
    public const
        TAG_BREW_TIME = "BrewTime",
        TAG_SETTINGS = "Potion";
    /** @var int */
    public const
        MAX_BREW_TIME = 400,
        NO_SETTINGS = 0,
        SPLASH_HEALING_I = 1,
        SPLASH_HEALING_II = 2,
        SPEED_I = 3,
        SPEED_II = 4,
        NIGHT_VISION = 5, 
        NIGHT_VISION_EXTENDED = 6,
        INVISIBILITY = 7,
        INVISIBILITY_EXTENDED = 8,
        FIRE_RESISTANCE = 9,
        FIRE_RESISTANCE_EXTENDED = 10;
    public $brewing = false;
    /** @var CompoundTag */
    private $nbt;

    public function __construct(Level $level, CompoundTag $nbt){
        parent::__construct($level, $nbt);
        if($nbt->hasTag(self::TAG_BREW_TIME, ShortTag::class)){
            $nbt->removeTag(self::TAG_BREW_TIME);
        }
        if(!$nbt->hasTag(self::TAG_BREW_TIME, IntTag::class)){
            $nbt->setInt(self::TAG_BREW_TIME, 0);
        }
        if(!$nbt->hasTag(self::TAG_SETTINGS, IntTag::class)){
            $nbt->setInt(self::TAG_SETTINGS, 0);
        }
        if(!$nbt->hasTag("Gunpowder", IntTag::class)){
            $nbt->setInt("Gunpowder", 0);
        }
        if(!$nbt->hasTag("Bottles", IntTag::class)){
            $nbt->setInt("Bottles", 0);
        }
        if(!$nbt->hasTag("NetherWart", IntTag::class)){
            $nbt->setInt("NetherWart", 0);
        }
        if(!$nbt->hasTag("Sugar", IntTag::class)){
            $nbt->setInt("Sugar", 0);
        }
        if(!$nbt->hasTag("MagmaCream", IntTag::class)){
            $nbt->setInt("MagmaCream", 0);
        }
        if(!$nbt->hasTag("FermentedSpiderEye", IntTag::class)){
            $nbt->setInt("FermentedSpiderEye", 0);
        }
        if(!$nbt->hasTag("GoldenCarrot", IntTag::class)){
            $nbt->setInt("GoldenCarrot", 0);
        }
        if(!$nbt->hasTag("Redstone", IntTag::class)){
            $nbt->setInt("Redstone", 0);
        }
        if(!$nbt->hasTag("Glowstone", IntTag::class)){
            $nbt->setInt("Glowstone", 0);
        }
        if(!$nbt->hasTag("GlisteringMelon", IntTag::class)){
            $nbt->setInt("GlisteringMelon", 0);
        }
        $this->scheduleUpdate();
    }

    public function getDefaultName(): string {
        return "Brewing Stand";
    }

    public function addAdditionalSpawnData(CompoundTag $nbt): void{
        $nbt->setShort(self::TAG_BREW_TIME, self::MAX_BREW_TIME);
    }

    /**
     * @return CompoundTag
     */
    public function getNBT(): CompoundTag {
        return $this->nbt;
    }

    /**
     * @return int
     */
    public function getPotion(): int {
        return $this->getNBT()->getInt("Bottles");
    }

    /**
     * @param int $count
     */
    public function setPotion(int $count){
        return $this->getNBT()->setInt("Bottles", $count);
    }

    /**
     * @return int
     */
    public function getNetherWart(): int {
        return $this->getNBT()->getInt("NetherWart");
    }

    /**
     * @param int $count
     */
    public function setNetherWart(int $count){
        return $this->getNBT()->setInt("NetherWart", $count);
    }

    /**
     * @return int
     */
    public function getSugar(): int {
        return $this->getNBT()->getInt("Sugar");
    }

    /**
     * @param int $count
     */
    public function setSugar(int $count){
        return $this->getNBT()->setInt("Sugar", $count);
    }

    /**
     * @return int
     */
    public function getMagmaCream(): int {
        return $this->getNBT()->getInt("MagmaCream");
    }

    /**
     * @param int $count
     */
    public function setMagmaCream(int $count){
        return $this->getNBT()->setInt("MagmaCream", $count);
    }

    /**
     * @return int
     */
    public function getFermentedSpiderEye(): int {
        return $this->getNBT()->getInt("FermentedSpiderEye");
    }

    /**
     * @param int $count
     */
    public function setFermentedSpiderEye(int $count){
        return $this->getNBT()->setInt("FermentedSpiderEye", $count);
    }

    /**
     * @return int
     */
    public function getGoldenCarrot(): int {
        return $this->getNBT()->getInt("GoldenCarrot");
    }

    /**
     * @param int $count
     */
    public function setGoldenCarrot(int $count){
        return $this->getNBT()->setInt("GoldenCarrot", $count);
    }

    /**
     * @return int
     */
    public function getGlowstoneDust(): int {
        return $this->getNBT()->getInt("Glowstone");
    }

    /**
     * @param int $count
     */
    public function setGlowstoneDust(int $count){
        return $this->getNBT()->setInt("Glowstone", $count);
    }

    /**
     * @return int
     */
    public function getGunpowder(): int {
        return $this->getNBT()->getInt("Gunpowder");
    }

    /**
     * @param int $count
     */
    public function setGunpowder(int $count){
        return $this->getNBT()->setInt("Gunpowder", $count);
    }

    /**
     * @return int
     */
    public function getRedstone(): int {
        return $this->getNBT()->getInt("Redstone");
    }

    /**
     * @param int $count
     */
    public function setRedstone(int $count){
        return $this->getNBT()->setInt("Redstone", $count);
    }

    /**
     * @return int
     */
    public function getGlisteringMelon(): int {
        return $this->getNBT()->getInt("GlisteringMelon");
    }

    /**
     * @param int $count
     */
    public function setGlisteringMelon(int $count){
        return $this->getNBT()->setInt("GlisteringMelon", $count);
    }

    /**
     * @return int
     */
    public function getBrewTime(): int {
        return $this->getNBT()->getInt(self::TAG_BREW_TIME);
    }

    /**
     * @param int $count
     */
    public function setBrewTime(int $count){
        return $this->getNBT()->setInt(self::TAG_BREW_TIME, $count);
    }

    /**
     * @return int
     */
    public function getSettings(): int {
        return $this->getNBT()->getInt(self::TAG_SETTINGS);
    }

    /**
     * @param int $count
     */
    public function setSettings(int $count){
        return $this->getNBT()->setInt(self::TAG_SETTINGS, $count);
    }

    /**
     * @param AlpinePlayer $player
     */
    public function sendMenu(AlpinePlayer $player){
        $form = new SimpleForm(function (AlpinePlayer $player, int $data = null) {
            $result = $data;
            if($result === null) return true;
            switch($result){
                case 0:
                    $this->openItemMenu($player);
                    break;
                case 1:
                    $this->openBrewMenu($player);
                    break;
            }
        });
        $form->setTitle("Brewing Menu");
        $form->setContent("Choose to take items from this brewer or set which potion you want to brew!");
        $form->addButton("Take Item Menu");
        $form->addButton("Brew Menu");
        $form->addButton("Close");
        $form->sendToPlayer($player);
    }

    /**
     * @param AlpinePlayer $player
     */
    public function openItemMenu(AlpinePlayer $player){
        $form = new SimpleForm(function (AlpinePlayer $player, int $data = null) {
            $result = $data;
            if($result === null) return true;
            switch($result){
                case 0:
                    if($this->getPotion() > 0){
                        $player->getInventory()->addItem(Item::get(Item::GLASS_BOTTLE, 0, $this->getPotion());
                        $this->setPotion(0);
                    }
                    break;
                case 1:
                    if($this->getNetherWart() > 0){
                        $player->getInventory()->addItem(Item::get(Item::NETHER_WART, 0, $this->getNetherWart());
                        $this->setNetherWart(0);
                    }
                    break;
                case 2:
                    if($this->getSugar() > 0){
                        $player->getInventory()->addItem(Item::get(Item::SUGAR, 0, $this->getSugar());
                        $this->setSugar(0);
                    }
                    break;
                case 3:
                    if($this->getMagmaCream() > 0){
                        $player->getInventory()->addItem(Item::get(Item::MAGMA_CREAM, 0, $this->getMagmaCream());
                        $this->setMagmaCream(0);
                    }
                    break;
                case 4:
                    if($this->getFermentedSpiderEye() > 0){
                        $player->getInventory()->addItem(Item::get(Item::FERMENTED_SPIDER_EYE, 0, $this->getFermentedSpiderEye());
                        $this->setFermentedSpiderEye(0);
                    }
                    break;
                case 5:
                    if($this->getGoldenCarrot() > 0){
                        $player->getInventory()->addItem(Item::get(Item::GOLDEN_CARROT, 0, $this->getGoldenCarrot());
                        $this->setGoldenCarrot(0);
                    }
                    break;
                case 6:
                    if($this->getRedstone() > 0){
                        $player->getInventory()->addItem(Item::get(Item::REDSTONE, 0, $this->getRedstone());
                        $this->setRedstone(0);
                    }
                    break;
                case 7:
                    if($this->getGlowstoneDust() > 0){
                        $player->getInventory()->addItem(Item::get(Item::GLOWSTONE_DUST, 0, $this->getGlowstoneDust());
                        $this->setGlowstoneDust(0);
                    }
                    break;
                case 8:
                    if($this->getGunpowder() > 0){
                        $player->getInventory()->addItem(Item::get(Item::GUNPOWDER, 0, $this->getGunpowder());
                        $this->setGunpowder(0);
                    }
                    break;
                case 9:
                    if($this->getGlisteringMelon() > 0){
                        $player->getInventory()->addItem(Item::get(Item::GLISTERING_MELON, 0, $this->getGlisteringMelon());
                        $this->setGlisteringMelon(0);
                    }
                    break;
            }
        });
        $form->setTitle("Choose Item");
        $form->setContent("Choose which item you wish to take! Ensure your inventory has space");
        $form->addButton("Bottles");
        $form->addButton("NetherWart");
        $form->addButton("Sugar");
        $form->addButton("Magma Cream");
        $form->addButton("Fermented Spider Eye");
        $form->addButton("Golden Carrot");
        $form->addButton("Redstone");
        $form->addButton("Glowstone");
        $form->addButton("Gunpowder");
        $form->addButton("Glistering Melon");
        $form->addButton("Back");
        $form->sendToPlayer($player);
    }

    /**
     * @param AlpinePlayer $player
     */
    public function openBrewMenu(AlpinePlayer $player){
        $form = new SimpleForm(function (AlpinePlayer $player, int $data = null) {
            $result = $data;
            if($result === null) return true;
            switch($result){
                case 0:
                    $this->setSettings(self::SPLASH_HEALING_I);
                    break;
                case 1:
                    $this->setSettings(self::SPLASH_HEALING_II);
                    break;
                case 2:
                    $this->setSettings(self::SPEED_I);
                    break;
                case 3:
                    $this->setSettings(self::SPEED_II);
                    break;
                case 4:
                    $this->setSettings(self::NIGHT_VISION);
                    break;
                case 5:
                    $this->setSettings(self::NIGHT_VISION_EXTENDED);
                    break;
                case 6:
                    $this->setSettings(self::INVISIBILITY);
                    break;
                case 7:
                    $this->setSettings(self::INVISIBILITY_EXTENDED);
                    break;
                case 8:
                    $this->setSettings(self::FIRE_RESISTANCE);
                    break;
                case 9:
                    $this->setSettings(self::FIRE_RESISTANCE_EXTENDED);
                    break;
            }
        });
        $form->setTitle("Choose Recipe");
        $form->setContent("Choose which potion you wish to brew");
        $form->addButton("Splash Healing I");
        $form->addButton("Splash Healing II");
        $form->addButton("Speed I (3:00)");
        $form->addButton("Speed II (1:30)");
        $form->addButton("Night Vision (3:00)");
        $form->addButton("Night Vision (8:00)");
        $form->addButton("Invisibility (3:00)");
        $form->addButton("Invisibility (8:00)");
        $form->addButton("Fire Resistance (3:00)");
        $form->addButton("Fire Resistance (8:00)");
        $form->addButton("Back");
        $form->sendToPlayer($player);
    }

    public function onUpdate(): bool {
        if($this->isClosed()) return false;
        $return = $canBrew = false;
        $this->timings->startTiming();
        if($this->getPotion() > 0){
            $canBrew = true;
        }
        if($canBrew){
            $return = true;
            $brewTime = $this->getBrewTime();
            $brewTime -= 1;
            $this->setBrewTime($brewTime);
            $this->brewing = true;
            $potion = $this->getPotion();
            $wart = $this->getNetherWart();
            $melon = $this->getGlisteringMelon();
            $sugar = $this->getSugar();
            $redstone = $this->getRedstone();
            $gunpowder = $this->getGunpowder();
            $carrot = $this->getGoldenCarrot();
            $eye = $this->getFermentedSpiderEye();
            $cream = $this->getMagmaCream();
            $glowstone = $this->getGlowstoneDust();
            if($brewTime <= 0){
                $settings = $this->getSettings();
                if($settings == self::SPLASH_HEALING_I){
                    if($wart > 0 && $melon > 0 && $glowstone < 0){
                        $this->setNetherWart($wart - 1);
                        $this->setGlisteringMelon($melon - 1);
                        $this->setGlowstoneDust($glowstone - 1);
                        $item = Item::get(438, 21, 1);
                    }
                }
                if($settings == self::SPLASH_HEALING_II){
                    if($wart > 0 && $melon < 0 && $glowstone < 0 && $gunpowder < 0){
                        $this->setNetherWart($wart - 1);
                        $this->setGlisteringMelon($melon - 1);
                        $this->setGlowstoneDust($glowstone - 1);
                        $this->setGunpowder($gunpowder - 1);
                        $item = Item::get(438, 22, 1);
                    }
                }
                if($settings == self::SPEED_I){
                    if($wart > 0 && $sugar > 0){
                        $this->setNetherWart($wart - 1);
                        $this->setSugar($sugar - 1);
                        $item = Item::get(373, 14, 1);
                    }
                }
                if($settings == self::SPEED_II){
                    if($wart > 0 && $sugar > 0 && $gunpowder < 0){
                        $this->setNetherWart($wart - 1);
                        $this->setSugar($sugar - 1);
                        $this->setGunpowder($gunpowder - 1);
                        $item = Item::get(373, 16, 1);
                    }
                }
                if($settings == self::NIGHT_VISION){
                    if($wart > 0 && $carrot < 0){
                        $this->setNetherWart($wart - 1);
                        $this->setGoldenCarrot($carrot - 1);
                        $item = Item::get(373, 5, 1);
                    }
                }
                if($settings == self::NIGHT_VISION_EXTENDED){
                    if($wart > 0 && $carrot < 0 && $redstone < 0){
                        $this->setNetherWart($wart - 1);
                        $this->setGoldenCarrot($carrot - 1);
                        $this->setRedstone($redstone - 1);
                        $item = Item::get(373, 6, 1);
                    }
                }
                if($settings == self::INVISIBILITY){
                    if($wart > 0 && $melon > 0 && $carrot < 0 && $eye < 0){
                        $this->setFermentedSpiderEye($eye - 1);
                        $this->setNetherWart($wart - 1);
                        $this->setGoldenCarrot($carrot - 1);
                        $item = Item::get(373, 7, 1);
                    }
                }
                if($settings == self::INVISIBILITY_EXTENDED){
                    if($wart > 0 && $melon > 0 && $carrot < 0 && $redstone < 0 && $eye < 0){
                        $this->setFermentedSpiderEye($eye - 1);
                        $this->setNetherWart($wart - 1);
                        $this->setGoldenCarrot($carrot - 1);
                        $this->setRedstone($redstone - 1);
                        $item = Item::get(373, 8, 1);
                    }
                }
                if($settings == self::FIRE_RESISTANCE){
                    if($wart > 0 && $cream > 0){
                        $this->setNetherWart($wart - 1);
                        $this->setMagmaCream($cream - 1);
                        $item = Item::get(373, 12, 1);
                    }
                }
                if($settings == self::FIRE_RESISTANCE_EXTENDED){
                    if($wart > 0 && $cream > 0 && $redstone < 0){
                        $this->setNetherWart($wart - 1);
                        $this->setMagmaCream($cream - 1);
                        $this->setRedstone($redstone - 1);
                        $item = Item::get(373, 13, 1);
                    }
                }
                $target = $this->getLevel()->getTile($this->getBlock()->getSide(Vector3::SIDE_DOWN);
                if($target instanceof Container){
                    $inv = $target->getInventory();
                    $targetItem = clone $item;
                    $targetItem->setCount(1);
                    if($inv instanceof DoubleChestInventory){
                        $left = $inv->getLeftSide();
                        $right = $inv->getRightSide();
                        if($right->canAddItem($targetItem)){
                            $inv = $right;
                        } else {
                            $inv = $left;
                        }
                    }
                    if($inv->canAddItem($targetItem)){
                        $inv->addItem($targetItem);
                        $inv->sendContents($inv->getViewers());
                    }
                    if($target instanceof Chest){
                        if($target->isPaired()){
                            $pair = $target->getPair();
                            $pinv = $pair->getInventory();
                            $pinv->sendContents($pinv->getViewers());
                        }
                    }
                }
                $this->brewing = false;
            } else {
                $this->setBrewTime(self::MAX_BREW_TIME);
                $this->brewing = false;
            }
        }
        $this->timings->stopTiming();
        return $return; 
    }

    protected function readSaveData(CompoundTag $nbt): void{
        $this->nbt = $nbt;
    }

    protected function writeSaveData(CompoundTag $nbt): void{
        $nbt->setShort(self::TAG_BREW_TIME, self::MAX_BREW_TIME);
    }
}
