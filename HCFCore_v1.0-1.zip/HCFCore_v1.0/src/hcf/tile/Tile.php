<?php
declare(strict_types=1);
namespace hcf\tile;

use hcf\AlpineCore;
use pocketmine\tile\Tile as PMTile;

abstract class Tile extends PMTile {
    /** @var string */
    public const
        MOB_SPAWNER = "MobSpawner",
        HOPPER = "Hopper";
    

    public static function init() {
        self::registerTile(Hopper::class);
        //self::registerTile(BrewingStand::class);
    }
}