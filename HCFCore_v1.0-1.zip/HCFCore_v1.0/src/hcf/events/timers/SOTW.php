<?php
declare(strict_types=1);
namespace hcf\events\timers;

use hcf\{
   AlpineCore, AlpinePlayer
};
use pocketmine\{
   event\Listener,
   event\entity\EntityDamageEvent
};

class SOTW implements Listener {

   private $plugin;
   private static $time = (60 * 60) * 2;
   /**
     * SOTW constructor.
     * @param AlpineCore $plugin
     */
   public function __construct(AlpineCore $plugin){
      $this->plugin = $plugin;
   }
   /**
     * @return bool
     */
   public function isEnabled(): bool {
      $dat = $this->plugin->getData();
      return $dat->getNested("Sotw.enabled");
   }
   /**
     * @return bool
     */
   public static function getEnabled(): bool {
      $dat = AlpineCore::getInstance()->getData();
      return $dat->getNested("Sotw.enabled");
   }
   /**
     * @param bool $true
     */
   public static function setEnabled(bool $true){
      $server = AlpineCore::getInstance();
      $data = $server->getData();
      $data->setNested("Sotw.enabled", $true);
   }
   public static function startTimer() {
      $time = time() + self::$time;
      $data = AlpineCore::getInstance()->getData();
      $data->setNested("Sotw.enabled", true);
      $data->setNested("Sotw.time", $time);
      $data->save();

   }
   public static function stopTimer() {
      $data = AlpineCore::getInstance()->getData();
      $data->setNested("Sotw.time", 0);
      $data->setNested("Sotw.enabled", false);
      $data->save();
   }
   /**
     * @return int
     */
   public static function getTime(): int {
      $data = AlpineCore::getInstance()->getData();
      return $data->getNested("Sotw.time");
   }
   /**
     * @return int
     */
   public static function getTimeLeft(): int {
      return (int) self::getTime() - time();
   }
   /**
     * @param EntityDamageEvent $event
     */
   public function onHit(EntityDamageEvent $event){
      $player = $event->getEntity();
      if($player instanceof AlpinePlayer && $event->getCause() != EntityDamageEvent::CAUSE_VOID){
         if($this->isEnabled()){
            $event->setCancelled();
         }
      }
   }
}