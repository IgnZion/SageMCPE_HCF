<?php
declare(strict_types=1);
namespace hcf\events\sets;

use hcf\{
   AlpineCore, AlpinePlayer
};
use pocketmine\{
   event\Listener,
   utils\TextFormat
};
use pocketmine\entity\{
   projectile\Arrow, Entity
};
use pocketmine\event\entity\{
   EntityDamageEvent,
   EntityDamageByChildEntityEvent
};

class ArcherSet implements Listener{

   private $plugin;
   public function __construct(AlpineCore $plugin){
        $this->plugin = $plugin;
   }

   /** 
     * @param EntityDamageEvent $event
     */
   public function onDamage(EntityDamageEvent $event){
      if($event instanceof EntityDamageByChildEntityEvent){
         $child = $event->getChild();
         if($child instanceof Arrow){
            $entity = $event->getEntity();
            $shoot = $event->getDamager();
            if($entity instanceof AlpinePlayer && $shoot instanceof AlpinePlayer){
               if($shoot->isArcher()){
                  $mgr = AlpineCore::getFactionsManager();
                  if($mgr->isSpawnClaim($entity, $entity->getLevel())){
                      $event->setCancelled(true);
                  }
                  if($mgr->isSpawnClaim($shoot, $shoot->getLevel())){
                      $event->setCancelled(true);
                  }
                  if($mgr->isNetherSpawnClaim($entity, $entity->getLevel())){
                      $event->setCancelled(true);
                  }
                  if($mgr->isNetherSpawnClaim($shoot, $shoot->getLevel())){
                      $event->setCancelled(true);
                  }
                  if($event->isCancelled()){
                     if($entity->isArcherTagged()){
                        $entity->setArchertagTime(45);
                        $heart = $entity->getHealth();
                        $entity->setHealth($heart - 1.5);
                     } else {
                        $entity->setArchertagTime(45);
                        $entity->setArcherTagged(true);
                     }
                  }
               }
            }
         }
      }
   }
}