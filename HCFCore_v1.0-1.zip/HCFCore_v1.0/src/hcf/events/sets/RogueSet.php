<?php
declare(strict_types=1);
namespace hcf\events\sets;

use hcf\{
   AlpineCore, AlpinePlayer
};
use pocketmine\{
   event\Listener,
   utils\TextFormat,
   item\Item
};
use pocketmine\entity\Entity;
use pocketmine\event\entity\{
   EntityDamageEvent,
   EntityDamageByEntityEvent
};

class RogueSet implements Listener{

   private $plugin;
   public function __construct(AlpineCore $plugin){
        $this->plugin = $plugin;
   }

   /** 
     * @param EntityDamageEvent $event
     */
   public function onDamage(EntityDamageEvent $event){
      if($event instanceof EntityDamageByEntityEvent){
            $entity = $event->getEntity();
            $damager = $event->getDamager();
            if($entity instanceof AlpinePlayer && $damager instanceof AlpinePlayer){
               if($damager->isRogue()){
                  if($damager->getInventory()->getItemInHand()->getId() == Item::GOLD_SWORD){
                     $damager->getInventory()->setItemInHand(Item::get(Item::AIR));
                     $heart = $entity->getHealth();
                     $damage = mt_rand(4, 6);
                     $entity->setHealth($heart - $damage);
                  }
                }
            }
        }
    }
}