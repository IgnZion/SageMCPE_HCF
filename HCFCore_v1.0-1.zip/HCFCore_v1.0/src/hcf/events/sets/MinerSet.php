<?php
declare(strict_types=1);
namespace hcf\events\sets;

use hcf\{
   AlpineCore, AlpinePlayer
};
use pocketmine\{
   item\Item,
   item\enchantment\Enchantment,
   block\Block,
   block\BlockIds,
   event\Listener,
   utils\TextFormat
};
use pocketmine\event\block\{
   BlockBreakEvent
};

class MinerSet implements Listener{

   private $plugin;
   public function __construct(AlpineCore $plugin){
        $this->plugin = $plugin;
   }

   /** 
     * @param BlockBreakEvent $event
     */
   public function onBreak(BlockBreakEvent $event){
      $player = $event->getPlayer();
      $item = $player->getInventory()->getItemInHand();
      $level = $item->getEnchantmentLevel(Enchantment::FORTUNE);
      if($player instanceof AlpinePlayer){
         $block = $event->getBlock();
         $inv = $player->getInventory();
         if($event->isCancelled() == false){
            switch($block->getId()){
               case BlockIds::COAL_ORE:
                  if($level > 0){
                     $add = 1 + rand(0, $level);
                     if($player->isMiner()){
                        $inv->addItem(Item::get(Item::COAL, 0, 1 + $add));
                        $event->setDrops([]);
                     } else {
                        $event->setDrops([Item::get(Item::COAL, 0, 1 + $add)]);
                     }
                  } else {
                     $event->setDrops([Item::get(Item::COAL, 0, 1)]);
                  }
                  break;
               case BlockIds::IRON_ORE:
                  if($level > 0){
                     $add = 1 + rand(0, $level);
                     if($player->isMiner()){
                        $add = 1 + rand(0, $level);
                        $inv->addItem(Item::get(Item::IRON_INGOT, 0, 1 + $add));
                        $event->setDrops([]);
                     } else {
                        $event->setDrops([Item::get(Item::IRON_INGOT, 0, 1 + $add)]);
                     }
                  } else {
                     $event->setDrops([Item::get(Item::IRON_INGOT, 0, 1)]);
                  }
                  break;
               case BlockIds::GOLD_ORE:
                  if($level > 0){
                     $add = 1 + rand(0, $level);
                     if($player->isMiner()){
                        $inv->addItem(Item::get(Item::GOLD_INGOT, 0, 1 + $add));
                        $event->setDrops([]);
                     } else {
                        $event->setDrops([Item::get(Item::GOLD_INGOT, 0, 1 + $add)]);
                     }
                  } else {
                     $event->setDrops([Item::get(Item::GOLD_INGOT, 0, 1)]);
                  }
                  break;
               case BlockIds::DIAMOND_ORE:
                  if($level > 0){
                     $add = 1 + rand(0, $level);
                     if($player->isMiner()){
                        $inv->addItem(Item::get(Item::DIAMOND, 0, 1 + $add));
                        $event->setDrops([]);
                     } else {
                        $event->setDrops([Item::get(Item::DIAMOND, 0, 1 + $add)]);
                     }
                  } else {
                     $event->setDrops([Item::get(Item::DIAMOND, 0, 1)]);
                  }
                  break;
               case BlockIds::EMERALD_ORE:
                  if($level > 0){
                     $add = 1 + rand(0, $level);
                     if($player->isMiner()){
                        $inv->addItem(Item::get(Item::EMERALD, 0, 1 + $add));
                        $event->setDrops([]);
                     } else {
                        $event->setDrops([Item::get(Item::EMERALD, 0, 1 + $add)]);
                     }
                  } else {
                     $event->setDrops([Item::get(Item::EMERALD, 0, 1)]);
                  }
                  break;
               case BlockIds::REDSTONE_ORE:
                  if($level > 0){
                     $add = 1 + rand(0, $level);
                     if($player->isMiner()){
                        $inv->addItem(Item::get(Item::REDSTONE, 0, rand(4, 8) + $add));
                        $event->setDrops([]);
                     } else {
                        $event->setDrops([Item::get(Item::REDSTONE, 0, rand(4, 8) + $add)]);
                     }
                  } else {
                     $event->setDrops([Item::get(Item::REDSTONE, 0, rand(4, 8))]);
                  }
                  break;
               case BlockIds::LAPIS_ORE:
                  if($level > 0){
                     $add = 1 + rand(0, $level);
                     if($player->isMiner()){
                        $inv->addItem(Item::get(Item::DYE, 4, rand(4, 8) + $add));
                        $event->setDrops([]);
                     } else {
                        $event->setDrops([Item::get(Item::DYE, 4, rand(4, 8) + $add)]);
                     }
                  } else {
                     $event->setDrops([Item::get(Item::DYE, 4, rand(4, 8))]);
                  }
                  break;
               case BlockIds::LEAVES:
                  if($level > 0){
                     if(rand(0, 100) <= $level * 2){
                        if($player->isMiner()){
                           $inv->addItem(Item::get(Item::APPLE));
                           $event->setDrops([]);
                        } else {
                           $event->setDrops([Item::get(Item::APPLE)]);
                        }
                     }
                  }
                  break;      
               case BlockIds::NETHER_QUARTZ_ORE:
                  if($level > 0){
                     $add = 1 + rand(0, $level);
                     if($player->isMiner()){
                        $inv->addItem(Item::get(Item::NETHER_QUARTZ, 0, rand(4, 8) + $add));
                        $event->setDrops([]);
                     } else {
                        $event->setDrops([Item::get(Item::NETHER_QUARTZ, 0, rand(4, 8) + $add)]);
                     }
                  } else {
                     $event->setDrops([Item::get(Item::NETHER_QUARTZ, 0, rand(4, 8))]);
                  }
                  break;
            }
         }
      }
   }
}
