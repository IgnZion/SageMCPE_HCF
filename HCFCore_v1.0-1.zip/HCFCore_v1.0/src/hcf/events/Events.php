<?php
declare(strict_types=1);
namespace hcf\events;

use hcf\AlpineCore;
use pocketmine\Server;
use hcf\events\sets\{MinerSet, ArcherSet, RogueSet};
use hcf\events\timers\{SOTW};
use hcf\events\partneritems\{TaxMagicalBone, PortableBard, NinjaAbility, PearlCooldownRemover};
use hcf\events\listener\{CheatListener, ClaimListener, StaffListener, ShopListener, CratesListener, PlayerListener, FactionListener};
class Events {

   public static function init(): void {
      $instance = AlpineCore::getInstance();
      $server = $instance->getServer();
      $mgr = $server->getPluginManager();

      $mgr->registerEvents(new SOTW($instance), $instance);
      $mgr->registerEvents(new PlayerJoin($instance), $instance);
      $mgr->registerEvents(new Elevator($instance), $instance);
      $mgr->registerEvents(new MinerSet($instance), $instance);
      $mgr->registerEvents(new ArcherSet($instance), $instance);
      $mgr->registerEvents(new RogueSet($instance), $instance);
      $mgr->registerEvents(new BardItems($instance), $instance);
      $mgr->registerEvents(new Border($instance), $instance);
      $mgr->registerEvents(new PartnerItems($instance), $instance);
      $mgr->registerEvents(new PortableBard($instance), $instance);
      $mgr->registerEvents(new TaxMagicalBone($instance), $instance);
      $mgr->registerEvents(new PearlCooldownRemover($instance), $instance);
      $mgr->registerEvents(new NinjaAbility($instance), $instance);
      $mgr->registerEvents(new FoundDiamonds($instance), $instance);
      $mgr->registerEvents(new CheatListener($instance), $instance);
      $mgr->registerEvents(new ClaimListener($instance), $instance);
      $mgr->registerEvents(new StaffListener($instance), $instance);
      $mgr->registerEvents(new ShopListener($instance), $instance);
      $mgr->registerEvents(new CratesListener($instance), $instance);
      $mgr->registerEvents(new PlayerListener($instance), $instance);
      $mgr->registerEvents(new FactionListener($instance), $instance);
      $server->getLogger()->notice("Events Registered");
   }
}