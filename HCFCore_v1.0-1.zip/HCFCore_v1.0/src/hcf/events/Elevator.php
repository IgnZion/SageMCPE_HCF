<?php
declare(strict_types=1);
namespace hcf\events;

use hcf\{
   AlpineCore, AlpinePlayer
};
use pocketmine\tile\Sign;

use pocketmine\math\Vector3;
use pocketmine\event\Listener;
use pocketmine\utils\TextFormat as TF;
use pocketmine\event\block\SignChangeEvent;
use pocketmine\event\player\PlayerInteractEvent;

class Elevator implements Listener {

   private $plugin;
   public function __construct(AlpineCore $plugin){
      $this->plugin = $plugin;
    }

   /** 
     * @param SignChangeEvent $event
     */
   public function sign(SignChangeEvent $event){
      $player = $event->getPlayer();
      $block = $event->getBlock();
      if($event->getLine(0) != "[Elevator]") return;
      if(strtolower($event->getLine(1)) == "up" || strtolower($event->getLine(1)) == "down"){
         $event->setLine(0, TF::BLUE . 
"[Elevator]" . TF::RESET);
         $line = strtolower($event->getLine(1));
         $event->setLine(1, $line);
         $event->setLine(2, "");
         $event->setLine(3, "");
      }
   }

	/** 
     * @param PlayerInteractEvent $event
     */
   public function onTap(PlayerInteractEvent $event){
      $player = $event->getPlayer();
      $block = $event->getBlock();
      $loc = new Vector3($block->getX(), $block->getY(), $block->getZ());
      $tile = $player->getLevel()->getTile($loc);
      if($tile instanceof Sign){
         if($player->isSneaking()) return;
         $line = $tile->getText();
         if($line[0] == TF::BLUE . "[Elevator]" . TF::RESET){
            if(strtolower($line[1]) == "up"){
               $this->sendTo($player, strtolower($line[1]), $loc);
            }
            if(strtolower($line[1]) == "down"){
               $this->sendTo($player, strtolower($line[1]), $loc);
            }
         }
      }
   }
	/**
     * @param AlpinePlayer $player
     * @param string $dir
     * @param Vector3 $loc
     */
   public function sendTo(AlpinePlayer $player, $dir, Vector3 $loc){
      $lvl = $player->getLevel();
      $up = $this->getClosestUp($lvl, $loc);
      $low = $this->getClosestDown($lvl, $loc);

      if($dir == "up"){
         $player->teleport(new Vector3($loc->getX(), $up, $loc->getZ()));
      }
      if($dir == "down"){
         $player->teleport(new Vector3($loc->getX(), $low, $loc->getZ()));
      }
   }

   public function getClosestUp($lvl, Vector3 $loc){
      for($i = $loc->getY()+1; $i < 128; $i++){
         $block = $lvl->getTile(new Vector3($loc->getX(), $i, $loc->getZ()));
         if($block instanceof Sign){
            $line = $block->getText();
            if($line[0] == TF::BLUE . "[Elevator]" . TF::RESET){
               return $i;
            }
         }
      }
      return $loc->getY();
   }
   public function getClosestDown($lvl, Vector3 $loc){
      for($i = $loc->getY()-1; $i > 0; $i--){
         $block = $lvl->getTile(new Vector3($loc->getX(), $i, $loc->getZ()));
         if($block instanceof Sign){
            $line = $block->getText();
             if($line[0] == TF::BLUE . "[Elevator]" . TF::RESET){
               return $i;
            }
         }
      }
      return $loc->getY();
   }
}