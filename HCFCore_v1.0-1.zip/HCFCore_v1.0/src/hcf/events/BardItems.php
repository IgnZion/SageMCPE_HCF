<?php
declare(strict_types=1);
namespace hcf\events;

use hcf\{
   AlpineCore, AlpinePlayer
};
use pocketmine\{
   item\Item, item\ItemIds,
   event\Listener,
   utils\TextFormat
};
use pocketmine\entity\{
   Effect, EffectInstance
};
use pocketmine\event\player\{
   PlayerInteractEvent, PlayerItemHeldEvent
};

class BardItems implements Listener{

   private $plugin;
   public function __construct(AlpineCore $plugin){
        $this->plugin = $plugin;
   }

   /** 
     * @param PlayerInteractEvent $event
     */
   public function onTap(PlayerInteractEvent $event){
      $player = $event->getPlayer();
      $manager = AlpineCore::getFactionsManager();
      if($player instanceof AlpinePlayer){
         $item = $event->getItem();
         if($player->isBard()){
            $energy = $player->getBardEnergy();
            $delay = $player->getBardDelay();
            $inv = $player->getInventory();
            switch($item->getId()){
               case ItemIds::SUGAR:
                  if($energy >= 20 && $delay == 0){
                     if($player->isInFaction()){
                        $mem = $manager->getOnlineMembers($player->getFaction());
                        foreach($mem as $member){
                           $distance = $member->distanceSquared($player);
                           if($distance <= 144){
                              $member->addEffect(new EffectInstance(Effect::getEffect(Effect::SPEED), 20 * 6, 1));
                           }
                        }
                     }
                     $player->setBardDelay(6);
                     $item->pop();
                     $inv->setItemInHand($item);
                     $player->setBardEnergy($energy - 20);
                     $player->addEffect(new EffectInstance(Effect::getEffect(Effect::SPEED), 20 * 6, 1));
                  }
               break;

               case ItemIds::FEATHER:
                  if($energy >= 20 && $delay == 0){
                     if($player->isInFaction()){
                        $mem = $manager->getOnlineMembers($player->getFaction());
                        foreach($mem as $member){
                           $distance = $member->distanceSquared($player);
                           if($distance <= 144){
                              $member->addEffect(new EffectInstance(Effect::getEffect(Effect::JUMP_BOOST), 20 * 6, 3));
                           }
                        }
                     }
                     $item->pop();
                     $player->setBardDelay(4);
                     $inv->setItemInHand($item);
                     $player->setBardEnergy($energy - 20);
                     $player->addEffect(new EffectInstance(Effect::getEffect(Effect::JUMP_BOOST), 20 * 6, 3));
                  }
               break;

               case ItemIds::IRON_INGOT:
                  if($energy >= 20 && $delay == 0){
                     if($player->isInFaction()){
                        $mem = $manager->getOnlineMembers($player->getFaction());
                        foreach($mem as $member){
                           $distance = $member->distanceSquared($player);
                           if($distance <= 144){
                              $member->addEffect(new EffectInstance(Effect::getEffect(Effect::RESISTANCE), 20 * 6, 2));
                           }
                        }
                     }
                     $item->pop();
                     $player->setBardDelay(6);
                     $inv->setItemInHand($item);
                     $player->setBardEnergy($energy - 20);
                     $player->addEffect(new EffectInstance(Effect::getEffect(Effect::RESISTANCE), 20 * 6, 2));
                  }
               break;

               case ItemIds::GHAST_TEAR:
                  if($energy >= 30 && $delay == 0){
                     if($player->isInFaction()){
                        $mem = $manager->getOnlineMembers($player->getFaction());
                        foreach($mem as $member){
                           $distance = $member->distanceSquared($player);
                           if($distance <= 144){
                              $member->addEffect(new EffectInstance(Effect::getEffect(Effect::REGENERATION), 20 * 6, 1));
                           }
                        }
                     }
                     $item->pop();
                     $inv->setItemInHand($item);
                     $player->setBardDelay(7);
                     $player->setBardEnergy($energy - 30);
                     $player->addEffect(new EffectInstance(Effect::getEffect(Effect::REGENERATION), 20 * 6, 1));
                  }
               break;

               case ItemIds::BLAZE_POWDER:
                  if($energy >= 40 && $delay == 0){
                     if($player->isInFaction()){
                        $mem = $manager->getOnlineMembers($player->getFaction());
                        foreach($mem as $member){
                           $distance = $member->distanceSquared($player);
                           if($distance <= 144){
                              $member->addEffect(new EffectInstance(Effect::getEffect(Effect::STRENGTH), 20 * 4, 1));
                           }
                        }
                     }
                     $item->pop();
                     $inv->setItemInHand($item);
                     $player->setBardDelay(8);
                     $player->setBardEnergy($energy - 40);
                     $player->addEffect(new EffectInstance(Effect::getEffect(Effect::STRENGTH), 20 * 4, 1));
                  }
               break;

               case ItemIds::SPIDER_EYE:
                  if($energy >= 30 && $delay == 0){
                     if(!AlpineCore::getFactionsManager()->isSpawnClaim($player->asVector3(), $player->getLevel())){
                        if($player->isInFaction()){
                           $ally = $manager->getOnlineMembers($player->getFaction());
                           $players = $player->getLevel()->getPlayers();
                           foreach($players as $enemy){
                              if(!in_array($enemy, $ally)){
                                 $distance = $enemy->distanceSquared($player);
                                 if($distance <= 144){
                                 $enemy->addEffect(new EffectInstance(Effect::getEffect(Effect::WITHER), 20 * 10, 0));
                                 }
                              }
                           }
                        } else {
                           $players = $player->getLevel()->getPlayers();
                           foreach($players as $enemy){
                              $distance = $enemy->distanceSquared($player);
                              if($enemy !== $player){
                                 if($distance <= 144){
                                    $enemy->addEffect(new EffectInstance(Effect::getEffect(Effect::WITHER), 20 * 10, 0));
                                 }
                              }
                           }
                        }
                        $item->pop();
                        $inv->setItemInHand($item);
                        $player->setBardDelay(5);
                        $player->setBardEnergy($energy - 30);
                        $player->addEffect(new EffectInstance(Effect::getEffect(Effect::WITHER), 20 * 4, 0));
                     }
                  }
               break;
            }
         }
      }
   }
}