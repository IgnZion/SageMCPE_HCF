<?php
declare(strict_types=1);
namespace hcf\events\partneritems;

use hcf\{AlpineCore, AlpinePlayer, utils\Utils, tasks\NinjaTeleport};
use pocketmine\item\Item;
use pocketmine\event\Listener;
use pocketmine\utils\TextFormat as TF;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\entity\{EntityDamageEvent, EntityDamageByEntityEvent};
use pocketmine\nbt\tag\{StringTag, IntTag, CompoundTag, ListTag};

class NinjaAbility implements Listener {

    /** @var AlpineCore */
    private $plugin;

    /**
     * @param AlpineCore $plugin
     */
    public function __construct(AlpineCore $plugin){
        $this->plugin = $plugin;
    }
    
    /**
     * @param PlayerInteractEvent $event
     */
    public function onTap(PlayerInteractEvent $event) {
        if($event->getPlayer() instanceof AlpinePlayer){
            $item = $event->getItem();
            $nametag = $item->getNamedTag();
            if($nametag->hasTag("partneritem", StringTag::class)){
                $tag = $nametag->getString("partneritem");
                if($tag == "ninjaability"){
                    $cooldown = $event->getPlayer()->getPartnerItemCooldown("ninjaability");
                    $uses = $nametag->getInt("uses");
                    $teleport = AlpineCore::getInstance()->getServer()->getPlayer($event->getPlayer()->getLastHit());
                    if($uses >= 1){
                        if($teleport != null){
                            if(($cooldown - time()) <= 0) {
                                $event->getPlayer()->setPartnerItemCooldown("ninjaability", 60 * 4);
                                $event->getPlayer()->sendMessage(TF::RESET . TF::BOLD . TF::DARK_PURPLE . "Partner > " . TF::RESET . TF::GRAY . "You used a ninjastar and you are now on cooldown for " . TF::DARK_PURPLE . Utils::intToTime($cooldown - time()));
                                $event->getPlayer()->sendMessage(TF::RESET . TF::BOLD . TF::DARK_PURPLE . "Partner > " . TF::RESET . TF::GRAY . "This ninjastar has a total of " . ($uses - 1) . " uses left!");
                                $nametag->setInt("uses", $uses - 1);
                                $item->setNamedTag($nametag);
                                $event->getPlayer()->getInventory()->setItemInHand($item);
                                AlpineCore::getInstance()->getScheduler()->scheduleDelayedTask(new NinjaTeleport(AlpineCore::getInstance(), $event->getPlayer(), $teleport->getX(), $teleport->getY(), $teleport->getZ()), 30);
                                $teleport->sendMessage(TF::RESET . TF::BOLD . TF::DARK_PURPLE . "Partner > " . TF::RESET . TF::GRAY . " A player used a ninjastar on you and will teleport to this spot in 3 seconds!");
                            } else $event->getPlayer()->sendMessage(TF::RESET . TF::BOLD . TF::DARK_PURPLE . "Partner > " . TF::RESET . TF::GRAY . "You are on cooldown for this item for " . TF::DARK_PURPLE . Utils::intToTime($cooldown - time()));
                        } else $event->getPlayer()->sendMessage(TF::RESET . TF::BOLD . TF::DARK_PURPLE . "Partner > " . TF::RESET . TF::GRAY . "You could not use this item because no one hit you!");
                    } else {
                        $item->pop();
                        $event->getPlayer()->getInventory()->setItemInHand($item);
                        $event->getPlayer()->sendMessage(TF::RESET . TF::BOLD . TF::DARK_PURPLE . "Partner > " . TF::RESET . TF::GRAY . "You used up all the uses for this partner item!");
                    }
                }
            }
        }
    }

    /**
     * @param EntityDamageEvent $event
     */
    public function onDamage(EntityDamageEvent $event) {
        $entity = $event->getEntity();
        if($event instanceof EntityDamageByEntityEvent){
            $damager = $event->getDamager();
            if($entity instanceof AlpinePlayer && $damager instanceof AlpinePlayer){
                if($damager->isInFaction() && $entity->isInFaction()){
                    if($damager->getFaction() == $entity->getFaction()){
                        return;
                    }
                }
                $entity->setLastHit($damager->getName());
            }
        }
    }
}