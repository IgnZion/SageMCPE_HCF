<?php
declare(strict_types=1);
namespace hcf\events\partneritems;

use hcf\{AlpineCore, AlpinePlayer, utils\Utils};
use pocketmine\item\Item;
use pocketmine\event\Listener;
use pocketmine\utils\TextFormat as TF;
use pocketmine\event\entity\{EntityDamageEvent, EntityDamageByEntityEvent};
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\block\{BlockPlaceEvent, BlockBreakEvent};
use pocketmine\nbt\tag\{StringTag, IntTag, CompoundTag, ListTag};

class TaxMagicalBone implements Listener {
    /** @var AlpineCore */
    private $plugin;

    /**
     * @param AlpineCore $plugin
     */
    public function __construct(AlpineCore $plugin){
        $this->plugin = $plugin;
    }
    
    /**
     * @param EntityDamageEvent $event
     */
    public function onDamage(EntityDamageEvent $event) {
        $entity = $event->getEntity();
        if($event instanceof EntityDamageByEntityEvent){
            $damager = $event->getDamager();
            if($entity instanceof AlpinePlayer && $damager instanceof AlpinePlayer){
                $item = $damager->getInventory()->getItemInHand();
                $nametag = $item->getNamedTag();
                if($nametag->hasTag("partneritem", StringTag::class)){
                    $tag = $nametag->getString("partneritem");
                    if(!$event->isCancelled() && $tag == "taxmagicalbone"){
                        $item->pop();
                        $damager->getInventory()->setItemInHand($item);
                        $damager->setPartnerItemCooldown("bone", 60 * 2);
                        $damager->sendMessage(TF::RESET . TF::BOLD . TF::DARK_PURPLE . "Partner > " . TF::RESET . TF::GRAY . "You have been put on cooldown for 2 minutes!");
                        $entity->setPartnerItemCooldown("bonedtime", 15);
                        $entity->sendMessage(TF::RESET . TF::BOLD . TF::DARK_PURPLE . "Partner > " . TF::RESET . TF::GRAY . "You have been hit by Tax's Magical Bone and can't place or build blocks for 15 seconds!");
                    }
                }
            }
        }
    }

    /**
     * @param PlayerInteractEvent $event
     */
    public function onTap(PlayerInteractEvent $event) {
        if($event->getPlayer() instanceof AlpinePlayer){
            $item = $event->getItem()->getNamedTag();
            if($item->hasTag("partneritem", StringTag::class)){
                $tag = $item->getString("partneritem");
                if($tag == "taxmagicalbone"){
                    $cooldown = $event->getPlayer()->getPartnerItemCooldown("bone");
                    if(($cooldown - time()) >= 1){
                        $event->getPlayer()->sendMessage(TF::RESET . TF::BOLD . TF::DARK_PURPLE . "Partner > " . TF::RESET . TF::GRAY . "You are on cooldown for Tax's Magical Bone for " . TF::DARK_PURPLE . Utils::intToTime($cooldown - time()));
                    }    
                }
            }
        }
    }

    /**
     * @param BlockPlaceEvent $event
     */
    public function onPlace(BlockPlaceEvent $event) {
        if($event->getPlayer() instanceof AlpinePlayer){
            $cooldown = $event->getPlayer()->getPartnerItemCooldown("bonedtime");
            if(($cooldown - time()) >= 1){
                $event->setCancelled(true);
                $event->getPlayer()->sendMessage(TF::RESET . TF::BOLD . TF::DARK_PURPLE . "Partner > " . TF::RESET . TF::GRAY . "You cannot place blocks for " . TF::DARK_PURPLE . Utils::intToTime($cooldown - time()));
            }
        }
    }

    /**
     * @param BlockBreakEvent $event
     */
    public function onBreak(BlockBreakEvent $event) {
        if($event->getPlayer() instanceof AlpinePlayer){
            $cooldown = $event->getPlayer()->getPartnerItemCooldown("bonedtime");
            if(($cooldown - time()) >= 1){
                $event->setCancelled(true);
                $event->getPlayer()->sendMessage(TF::RESET . TF::BOLD . TF::DARK_PURPLE . "Partner > " . TF::RESET . TF::GRAY . "You cannot break blocks for " . TF::DARK_PURPLE . Utils::intToTime($cooldown - time()));
            }
        }
    }
}