<?php
declare(strict_types=1);
namespace hcf\events\partneritems;

use hcf\{
    AlpineCore, AlpinePlayer, utils\Utils
};
use pocketmine\item\Item;
use pocketmine\entity\{
    Effect, EffectInstance
};
use pocketmine\event\Listener;
use pocketmine\utils\TextFormat as TF;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\nbt\tag\{StringTag, IntTag, CompoundTag, ListTag};

class PortableBard implements Listener {

    /** @var AlpineCore */
    private $plugin;

    /**
     * @param AlpineCore $plugin
     */
    public function __construct(AlpineCore $plugin){
        $this->plugin = $plugin;
    }
    
    /**
     * @param PlayerInteractEvent $event
     */
    public function onTap(PlayerInteractEvent $event) {
        if($event->getPlayer() instanceof AlpinePlayer){
            $item = $event->getItem();
            $nametag = $item->getNamedTag();
            if($nametag->hasTag("partneritem", StringTag::class)){
                $tag = $nametag->getString("partneritem");
                if($tag == "portablebard"){
                    $cooldown = $event->getPlayer()->getPartnerItemCooldown("portablebard");
                    if(($cooldown - time()) <= 0){
                        $item->pop();
                        $event->getPlayer()->getInventory()->setItemInHand($item);
                        $event->getPlayer()->setPartnerItemCooldown("portablebard", 60 * 3);
                        $event->getPlayer()->sendMessage(TF::RESET . TF::BOLD . TF::DARK_PURPLE . "Partner > " . TF::RESET . TF::GRAY . "You have been put on cooldown for portable bard for " . TF::DARK_PURPLE . Utils::intToTime($cooldown - time()));
                        $event->getPlayer()->addEffect(new EffectInstance(Effect::getEffect(Effect::STRENGTH), 15*20, 0));
                        $event->getPlayer()->addEffect(new EffectInstance(Effect::getEffect(Effect::SPEED), 15*20, 2));
                        $event->getPlayer()->addEffect(new EffectInstance(Effect::getEffect(Effect::RESISTANCE), 15*20, 1));
                        $event->getPlayer()->addEffect(new EffectInstance(Effect::getEffect(Effect::REGENERATION), 15*20, 1));
                    } else {
                        $event->getPlayer()->sendMessage(TF::RESET . TF::BOLD . TF::DARK_PURPLE . "Partner > " . TF::RESET . TF::GRAY . "You are on cooldown for portable bard for " . TF::DARK_PURPLE . Utils::intToTime($cooldown - time()));
                    }
                }
            }
        }
    }
}