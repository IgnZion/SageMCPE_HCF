<?php
declare(strict_types=1);
namespace hcf\events\partneritems;

use hcf\{
    AlpineCore, AlpinePlayer, utils\Utils
};
use pocketmine\item\Item;
use pocketmine\entity\{
    Effect, EffectInstance
};
use pocketmine\event\Listener;
use pocketmine\utils\TextFormat as TF;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\nbt\tag\{StringTag, IntTag, CompoundTag, ListTag};

class PearlCooldownRemover implements Listener {

    /** @var AlpineCore */
    private $plugin;

    /**
     * @param AlpineCore $plugin
     */
    public function __construct(AlpineCore $plugin){
        $this->plugin = $plugin;
    }
    
    /**
     * @param PlayerInteractEvent $event
     */
    public function onTap(PlayerInteractEvent $event) {
        if($event->getPlayer() instanceof AlpinePlayer){
            $item = $event->getItem();
            $nametag = $item->getNamedTag();
            if($nametag->hasTag("partneritem", StringTag::class)){
                $tag = $nametag->getString("partneritem");
                if($tag == "pearlcooldownremover"){
                    $cooldown = $event->getPlayer()->getPartnerItemCooldown("remover");
                    $epcooldown = $event->getPlayer()->getPartnerItemCooldown("pearlcooldown");
                    $uses = $nametag->getInt("uses");
                    if($uses >= 1){
                        if(($epcooldown - time()) >= 1){
                            if(($cooldown - time()) <= 0) {
                                $event->getPlayer()->setPartnerItemCooldown("remover", 30);
                                $event->getPlayer()->setPartnerItemCooldown("pearlcooldown", 0);
                                $event->getPlayer()->sendMessage(TF::RESET . TF::BOLD . TF::DARK_PURPLE . "Partner > " . TF::RESET . TF::GRAY . "You used a pearl cooldown remover and you are now on cooldown for " . TF::DARK_PURPLE . Utils::intToTime($cooldown - time()));
                                $event->getPlayer()->sendMessage(TF::RESET . TF::BOLD . TF::DARK_PURPLE . "Partner > " . TF::RESET . TF::GRAY . "This pearl cooldown remover has a total of " . ($uses - 1) . " uses left!");
                                $nametag->setInt("uses", $uses - 1);
                                $item->setNamedTag($nametag);
                                $event->getPlayer()->getInventory()->setItemInHand($item);
                            } else $event->getPlayer()->sendMessage(TF::RESET . TF::BOLD . TF::DARK_PURPLE . "Partner > " . TF::RESET . TF::GRAY . "You are on cooldown for this item for " . TF::DARK_PURPLE . Utils::intToTime($cooldown - time()));
                        } else $event->getPlayer()->sendMessage(TF::RESET . TF::BOLD . TF::DARK_PURPLE . "Partner > " . TF::RESET . TF::GRAY . "You could not use this item because you are not on enderpearl cooldown!");
                    } else {
                        $item->pop();
                        $event->getPlayer()->getInventory()->setItemInHand($item);
                        $event->getPlayer()->sendMessage(TF::RESET . TF::BOLD . TF::DARK_PURPLE . "Partner > " . TF::RESET . TF::GRAY . "You used up all the uses for this partner item!");
                    }
                }
            }
        }
    }
}