<?php
declare(strict_types=1);
namespace hcf\events;

use hcf\{
   AlpineCore, AlpinePlayer, tasks\TransferTask
};
use pocketmine\{
   Player, event\Listener
};
use Heisenburger69\BurgerSpawners\Entities\Zombie;
use pocketmine\utils\{
   TextFormat, Config
};
use pocketmine\event\player\{
   PlayerJoinEvent, PlayerCreationEvent,
   PlayerPreLoginEvent, PlayerQuitEvent
};
use pocketmine\network\mcpe\protocol\{
   GameRulesChangedPacket
};
use pocketmine\level\particle\FloatingTextParticle;
// use cosmoverse\antivpn\{thread\AntiVPNException, api\ip\AntiVPNIPResult};
class PlayerJoin implements Listener{

   private $plugin;
   public function __construct(AlpineCore $plugin){
        $this->plugin = $plugin;
   }

   /** 
     * @param PlayerCreationEvent $event
     */
   public function onCreation(PlayerCreationEvent $event){
      $class = AlpinePlayer::class;
      $event->setPlayerClass($class);
   }

   /**
     * @param PlayerJoinEvent $event
     */
   public function onJoin(PlayerJoinEvent  $event){
      $event->setJoinMessage(null);
      $player = $event->getPlayer();
      $name = $player->getName();
      if(!$player->hasPlayedBefore()){
         $player->createCustomData();
         $player->loadIt();
      } else {
         $player->loadIt();
      }
      $player->showScoreboard();
      $player->updateScoreboard();
      $c = new GameRulesChangedPacket();
      $c->gameRules = ["showcoordinates" => [1, true]];
      $player->dataPacket($c);
      /*AlpineCore::getInstance()->getAntiVPN()->checkIp($player->getAddress(),
          function(AntiVPNIPResult $result) use ($player): void {
              if($player->isOnline()){
                  $this->onAntiVPNDetectPlayer($player, $result);
              }
          },
          function(AntiVPNException $exception): void {
              AlpineCore::getInstance()->getLogger()->logException($exception);
          }
      );*/
      if($player->isPvP()){
          $player->setNameTag(TextFormat::RESET . TextFormat::GREEN . "[PvPTimer] " . TextFormat::GRAY . $player->getName());
      } else {
          $player->setNameTag(TextFormat::RESET . TextFormat::GRAY . $player->getName());
      }
      if(($player->getDeathBanTime() - time()) >= 1){
          if(!$player->hasPermission("core.cmd.staffmode")){
              $player->transfer("104.128.49.197", 19132);
          } else {
              //$player->enterStaffMode();
          }
      }
      if(($player->getPlayerBanTime() - time()) >= 1){
          if(!$player->hasPermission("core.cmd.staffmode")){
              $player->transfer("104.128.49.197", 19132);
          }
      }
      foreach($player->getLevel()->getEntities() as $entity){
         if($entity instanceof Zombie){
            if($entity->getNameTag() == $player->getName()){
                AlpineCore::getLoggerManager()->removeZombie($entity->getNameTag());
                $entity->close();
            }
         }
      }
      AlpineCore::getInstance()->getCratesManager()->spawnFloatingText($player);
      foreach(AlpineCore::getInstance()->getServer()->getOnlinePlayers() as $hidden){
          if($hidden->isVanished()){
              if(!$player->hasPermission("core.staff.seevanished")){
                  $player->hidePlayer($hidden);
              } else {
                  $player->showPlayer($hidden);
              }
          }
      }
   }

   /**
     * @param PlayerQuitEvent
     */
   public function onLeave(PlayerQuitEvent $event){
      $event->setQuitMessage(null);
      if($event->getPlayer() instanceof AlpinePlayer){
            if($event->getPlayer()->isSpawntagged() && $event->getPlayer()->getSpawntagTime() >= 0){
                AlpineCore::getLoggerManager()->spawnZombie($event->getPlayer());
            }
         $event->getPlayer()->saveIt();
      }
   }

 /*private function onAntiVPNDetectPlayer(Player $player, AntiVPNIPResult $result): void {
      if($result->isVpn()){
         $reason = TF::GRAY . "You have been kicked from AlpineHCF" . TF::RESET . "\n" . TF::GRAY . "Kicked By: " . TF::RED . "System" . TF::RESET . "\n" . TF::GRAY . "Reason: " . TF::RED . "VPN-Detection - Please turn off VPN to play";
         $player->kick($reason, false);
         foreach(AlpineCore::getInstance()->getServer()->getOnlinePlayers() as $staff){
            if($staff->isStaffMode()) $staff->sendMessage(TF::BOLD . TF::DARK_RED . "ALERT: " . TF::RESET . TF::GRAY . $player->getName() . " has tried joining with VPN, They were kicked!");  
         }
      }
   }*/
}