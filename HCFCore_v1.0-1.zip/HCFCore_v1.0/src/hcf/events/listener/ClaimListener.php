<?php
declare(strict_types=1);
namespace hcf\events\listener;

use hcf\{
    FactionsManager,
    AlpineCore, AlpinePlayer,
    utils\Utils
};
use pocketmine\item\Item;
use pocketmine\math\Vector3;
use pocketmine\event\Listener;
use pocketmine\event\player\{
    PlayerChatEvent, PlayerInteractEvent
};

use hcf\tile\BrewingStand;
use pocketmine\utils\TextFormat as TF;

class ClaimListener implements Listener {
    /**
     * ClaimListener constructor.
     * @param AlpineCore $plugin
     */
    public function __construct(AlpineCore $plugin){
    }

    /**
     * @param PlayerInteractEvent $event
     */
    public function onInteract(PlayerInteractEvent $event) {
        $player = $event->getPlayer();
        $block = $event->getBlock();
        $x = $block->getX();
        $y = $block->getY();
        $z = $block->getZ();
        $vec = $block->asVector3();
        $mgr = AlpineCore::getFactionsManager();
        $spawn = $block->getLevel()->getSpawnLocation()->asVector3();
        $blockvector = new Vector3(abs($x), abs($y), abs($z));
        if($player instanceof AlpinePlayer){
            if($player->isClaiming() and $player->isInFaction()){
                if($vec->distance($spawn) >= 500){
                    switch($player->getStep()){
                        case AlpinePlayer::FIRST:
                            if($mgr->isRoad($vec, $player->getLevel())){
                                $event->setCancelled(true);
                                $player->sendMessage("§l§c»» §r§7You can't claim on the roads!");
                            } else {
                                if($event->getItem()->getCustomName() == TF::BOLD . TF::GREEN . "Claiming" . TF::GRAY . " Wand"){
                                    $player->setPos1($vec);
                                    $player->buildWall($x, $y, $z);
                                    $player->setStep(AlpinePlayer::SECOND);
                                    $player->sendMessage("§l§c»» §r§7Your first position has been chosen! Choose the second position please!");
                                }
                            }
                            break;

                        case AlpinePlayer::SECOND:
                            if($mgr->isRoad($vec, $player->getLevel())){
                                $event->setCancelled(true);
                                $player->sendMessage("§l§c»» §r§7You can't claim on the roads!");
                            } else {
                                if($event->getItem()->getCustomName() == TF::BOLD . TF::GREEN . "Claiming" . TF::GRAY . " Wand"){
                                    $one = $player->getPos1();
                                    if($one->distance($block) > 4) {
                                        $player->setPos2($vec);
                                        $player->buildWall($x, $y, $z);
                                        $player->checkClaim($vec);
                                    } else {
                                        $player->sendMessage("§l§c»» §r§7You must choose at least a 4x4!");
                                    }
                                }
                            }
                            break;

                        case AlpinePlayer::CONFIRM:
                            if($player->isSneaking()){
                                $fac = $player->getFaction();
                                if($mgr->getBalance($fac) >= $player->getClaimCost()){
                                    $mgr->reduceBalance($fac, $player->getClaimCost());
                                    $x1 = $player->getPos1()->getFloorX();
                                    $z1 = $player->getPos1()->getFloorZ();
                                    $x2 = $player->getPos2()->getFloorX();
                                    $z2 = $player->getPos2()->getFloorZ();
                                    $player->setStep(AlpinePlayer::FIRST);
                                    $player->setClaiming(false);
                                    $player->setClaim(false);
                                    $player->removeWall((int) $player->getPos1()->getFloorX(), (int) $player->getPos1()->getFloorY(), (int) $player->getPos1()->getFloorZ());
                                    $player->removeWall((int) $player->getPos2()->getFloorX(), (int) $player->getPos2()->getFloorY(), (int) $player->getPos2()->getFloorZ());
                                    $mgr->claim($fac, $player->getPos1(), $player->getPos2(), FactionsManager::CLAIM);
                                    $player->sendMessage("" . "§l§a»» §r§7You have successfully claimed the land");
                                    $wand = Item::get(Item::DIAMOND_HOE);
                                    if($player->getInventory()->contains($wand)){
                                        $player->getInventory()->remove($wand);
                                    }
                                } else {
                                    $player->setStep(AlpinePlayer::FIRST);
                                    $player->setClaiming(false);
                                    $player->setClaim(false);
                                    $player->sendMessage("" . "§l§c»» §r§7You do not have enough money in the faction's balance!");
                                }
                            } else {
                                if($event->getItem()->getCustomName() == TF::BOLD . TF::GREEN . "Claiming" . TF::GRAY . " Wand"){
                                    $one = $player->getPos1();
                                    if($one->distance($block) > 4) {
                                        $player->removeWall((int) $player->getPos2()->getFloorX(), (int) $player->getPos2()->getFloorY(), (int) $player->getPos2()->getFloorZ());
                                        $player->setPos2($vec);
                                        $player->buildWall($x, $y, $z);
                                        $player->checkClaim($vec);
                                    } else {
                                        $player->sendMessage("§l§c»» §r§7You must choose at least a 4x4!");
                                    }
                                }
                            }
                            break;
                    }
                } else $player->sendMessage("§l§c»» §r§7You are too close to spawn area!");
            }
        }
    }

    /**
     * @param PlayerChatEvent $event
     */
    public function onChat(PlayerChatEvent $event) {
        $player = $event->getPlayer();
        $message = strtolower($event->getMessage());
        if($message == "cancel"){
            if($player instanceof AlpinePlayer) {
                $event->setCancelled(true);
                $step = AlpinePlayer::FIRST;
                $player->setStep($step);
                $player->setClaiming(false);
                $player->setClaim(false);
                $player->sendMessage("" . "§l§c»» §r§7You have cancelled claiming!");
            }
        }
    }

    public function onInteractBrew(PlayerInteractEvent $event){
        $player = $event->getPlayer();
        $block = $event->getBlock();
      if($player instanceof AlpinePlayer) {
        if($block->getId() === Item::get(Item::BREWING_STAND)){
            BrewingStand::sendMenu($player);
        }


    }
}
}
