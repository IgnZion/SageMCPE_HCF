<?php
declare(strict_types=1);
namespace hcf\events\listener;

use hcf\{
   AlpineCore, AlpinePlayer, utils\Utils
};
use Heisenburger69\BurgerSpawners\Entities\Zombie;
use pocketmine\{
   block\Block, item\Item, block\BlockIds,
   event\block\BlockBreakEvent,
   event\block\BlockPlaceEvent
};
use pocketmine\math\Vector3;
use pocketmine\event\Listener;
use pocketmine\utils\TextFormat as C;
use pocketmine\event\player\{
   PlayerDeathEvent, PlayerMoveEvent,
   PlayerChatEvent, PlayerInteractEvent
};
use pocketmine\event\entity\{
   EntityDamageByEntityEvent,
   EntityDamageEvent
};
use pocketmine\network\mcpe\protocol\{
   UpdateBlockPacket
};

class FactionListener implements Listener {
   private $claimBlocks = [];
   /**
     * FactionListener constructor.
     * @param AlpineCore $plugin
     */
   public function __construct(AlpineCore $plugin){
       $this->plugin = $plugin;
   }

   /**
     * @param PlayerDeathEvent $event
     */
   public function onDeath(PlayerDeathEvent $event){
      $mgr = AlpineCore::getFactionsManager();
      $player = $event->getPlayer();
      if($player instanceof AlpinePlayer){
         if($player->isInFaction()){
             $fac = $player->getFaction();
             $mgr->reduceDTR($fac);
             $mgr->movePoints($fac, 1);
         }
         $c = $player->getLastDamageCause();
         if($c instanceof EntityDamageByEntityEvent){
            $killer = $c->getDamager();
            if($killer instanceof AlpinePlayer){
               if($killer->isInFaction()){
                  $killerfac = $killer->getFaction();
                  $mgr->addPoints($killerfac,1);
               }
            }
         }
      }
   }

   /**
     * @param EntityDamageEvent $event
     */
   public function onHit(EntityDamageEvent $event){
      if(AlpineCore::getFactionsManager()->isSpawnClaim($event->getEntity()->asVector3(), $event->getEntity()->getLevel())){
         $event->setCancelled(true);
      }
      if($event instanceof EntityDamageByEntityEvent){
         $damager = $event->getDamager();
         $entity = $event->getEntity();
         $m = AlpineCore::getFactionsManager();
         $damagervec = $damager->asVector3();
         $entityvec = $entity->asVector3();
         if($entity instanceof Zombie && AlpineCore::getLoggerManager()->isZombie($entity->getNameTag())){
             if($damager instanceof AlpinePlayer && $damager->isInFaction()){
                 if($m->isInFaction($entity->getNameTag())){
                     if($damager->getFaction() == $m->getFaction($entity->getNameTag())){
                         $event->setCancelled(true);
                         $damager->sendMessage("" . C::YELLOW . "You cannot hurt " . C::RED . $entity->getNameTag());
                     }
                 }
             }
         }
         if($damager instanceof AlpinePlayer && $entity instanceof AlpinePlayer){
            if($m->isSpawnClaim($entityvec, $entity->getLevel())){
               $event->setCancelled(true);
            }
            if($m->isSpawnClaim($damagervec, $damager->getLevel())){
               $event->setCancelled(true);
            }
            if($m->isNetherSpawnClaim($entityvec, $entity->getLevel())){
               $event->setCancelled(true);
            }
            if($m->isNetherSpawnClaim($damagervec, $damager->getLevel())){
               $event->setCancelled(true);
            }
            if($damager->isPvP()){
               $event->setCancelled(true);
               $damager->sendMessage("" . C::GREEN . "You are on PvPTimer!");
            }
            if($entity->isPvP()){
               $event->setCancelled(true);
               $damager->sendMessage("❌" . C::BOLD . C::GREEN . "»» §7That player is currently on PvPTimer for §a" . Utils::intToFullString($entity->getPvPTimer()));
            }
            if($damager->isInFaction() && $entity->isInFaction()){
               if($damager->getFaction() == $entity->getFaction()){
                  $event->setCancelled(true);
                  $damager->sendMessage("" . C::YELLOW . "You cannot hurt " . C::RED . $entity->getName());
               }
            }
         }
      }
   }

   /**
     * @param BlockBreakEvent $event
     */
   public function onBreak(BlockBreakEvent $event){
      $block = $event->getBlock();
      $player = $event->getPlayer();
      $m = AlpineCore::getFactionsManager();
      $vec = $block->asVector3();
      $spawn = $block->getLevel()->getSpawnLocation()->asVector3();
      if($player instanceof AlpinePlayer){
         if(!$player->isOp()){
            if($block->getLevel() == AlpineCore::$endLevel){
               $event->setCancelled(true);
            }
            if($vec->distance($spawn) <= 350){
               $event->setCancelled(true);
            }
            if($m->isSpawnClaim($vec, $player->getLevel()) || $m->isNetherSpawnClaim($vec, $player->getLevel())){
               $event->setCancelled(true);
            }
            if($m->isRoad($vec, $player->getLevel()) || $m->isNetherRoad($vec, $player->getLevel())){
               $event->setCancelled(true);
            }
         }
         $vector = $player->asVector3()->add(0, 0.2, 0);
         if($m->isFactionClaim($block, $player->getLevel())){
            $claim = $m->getClaimer((int) $block->getX(), (int) $block->getZ());
            if(!$player->isInFaction()){
               $player->sendMessage("❌" . C::BOLD . C::GREEN . "»»" . C::GRAY . " You cannot break blocks in " . C::GREEN . $claim . "'s §7Territory!");
               $event->setCancelled();
               $player->teleport($vector);
            } else {
               if($player->getFaction() !== $claim){
                  $event->setCancelled(true);
                  $player->sendMessage("❌" . C::BOLD . C::GREEN . "»»" . C::GRAY . " You cannot break blocks in " . C::GREEN . $claim . "'s §7Territory!");
                  $player->teleport($vector);
               }
            }
         }
      }
   }

   /**
     * @param BlockPlaceEvent $event
     */
   public function onPlace(BlockPlaceEvent $event){
      $block = $event->getBlock();
      $player = $event->getPlayer();
      $m = AlpineCore::getFactionsManager();
      $vec = $block->asVector3();
      $spawn = $block->getLevel()->getSpawnLocation()->asVector3();
      if($player instanceof AlpinePlayer){
         if(!$player->isOp()){
            if($block->getLevel() == AlpineCore::$endLevel){
               $event->setCancelled(true);
            }
            if($vec->distance($spawn) <= 350){
               $event->setCancelled(true);
            }
            if($m->isSpawnClaim($vec, $player->getLevel()) || $m->isNetherSpawnClaim($vec, $player->getLevel())){
               $event->setCancelled(true);
            }
            if($m->isRoad($vec, $player->getLevel()) || $m->isNetherRoad($vec, $player->getLevel())){
               $event->setCancelled(true);
            }
         }
         if($m->isFactionClaim($block, $player->getLevel())){
            $claim = $m->getClaimer((int) $block->getX(), (int) $block->getZ());
            if(!$player->isInFaction()){
               $player->sendMessage("❌" . C::BOLD . C::GREEN . "»»" . C::GRAY . " You cannot place blocks in " . C::GREEN . $claim . "'s §7Territory!");
               $event->setCancelled();
            } else {
               if($player->getFaction() !== $claim){
                  $event->setCancelled(true);
                  $player->sendMessage("❌" . C::BOLD . C::GREEN . "»»" . C::GRAY . " You cannot place blocks in " . C::GREEN . $claim . "'s §7Territory!");
               }
            }
         }
      }
   }

   /**
     * @param PlayerChatEvent $event
     */
   public function onChat(PlayerChatEvent $event){
      $m = AlpineCore::getFactionsManager();
      $player = $event->getPlayer();
      if($player instanceof AlpinePlayer){
         if($player->getChat() == AlpinePlayer::FACTION){
            if($player->isInFaction()){
               $event->setCancelled(true);
               foreach ($m->getOnlineMembers($player->getFaction()) as $member){
                  $member->sendMessage("❌" . C::BOLD . C::GRAY . "(" . C::GREEN . $player->getFaction() . C::GRAY . ") " . C::DARK_GREEN . $player->getName() . ": " . C::WHITE . $event->getMessage());
               }
            } else $player->setChat(AlpinePlayer::PUBLIC);
         }
      }
   }

   /**
      * @param PlayerInteractEvent $event
      */
   public function onTap(PlayerInteractEvent $event){
      $block = $event->getBlock();
      $player = $event->getPlayer();
      $m = AlpineCore::getFactionsManager();
      $vector = $player->asVector3()->add(0, 0.1, 0);
      switch($block->getId()){
         case BlockIds::TRAPDOOR:
         case BlockIds::FENCE_GATE:
         case BlockIds::IRON_TRAPDOOR:
         case BlockIds::OAK_FENCE_GATE:
         case BlockIds::BIRCH_FENCE_GATE:
         case BlockIds::WOODEN_TRAPDOOR:
         case BlockIds::ACACIA_FENCE_GATE:
         case BlockIds::SPRUCE_FENCE_GATE:
         case BlockIds::JUNGLE_FENCE_GATE:
         case BlockIds::DARK_OAK_FENCE_GATE:
            if($player instanceof AlpinePlayer){
               if($m->isFactionClaim($block, $player->getLevel())){
                  $claim = $m->getClaimer((int) $block->getX(), (int) $block->getZ());
                  if(!$player->isInFaction()){
                     $player->sendMessage("❌" . C::BOLD . C::GREEN . "»»" . C::GRAY . " You cannot interact with gates|trapdoors in " . C::GREEN . $claim . "'s §7Territory!");
                     $event->setCancelled();
                  } else {
                     if($player->getFaction() !== $claim){
                        $event->setCancelled(true);
                        $player->sendMessage("❌" . C::BOLD . C::GREEN . "»»" . C::GRAY . " You cannot interact with gates|trapdoors in " . C::GREEN . $claim . "'s §7Territory!");
                     }
                  }
               }
            }
         break;

         case BlockIds::CHEST:
         case BlockIds::TRAPPED_CHEST:
            if($player instanceof AlpinePlayer){
               if($m->isFactionClaim($block, $player->getLevel())){
                  $claim = $m->getClaimer((int) $block->getX(), (int) $block->getZ());
                  if(!$player->isInFaction()){
                     $player->sendMessage("❌" . C::BOLD . C::GREEN . "»»" . C::GRAY . " You cannot open chests in " . C::GREEN . $claim . "'s §7Territory!");
                     $event->setCancelled();
                  } else {
                     if($player->getFaction() !== $claim){
                        $event->setCancelled(true);
                        $player->sendMessage("❌" . C::BOLD . C::GREEN . "»»" . C::GRAY . " You cannot open chests in " . C::GREEN . $claim . "'s §7Territory!");
                     }
                  }
               }
            }
         break;
      }
      if($m->isFactionClaim($block, $player->getLevel())){
        if(!$player->isInFaction()){
           $event->setCancelled(true);
        } else {
           if($player->getFaction() != $m->getClaimer((int) $block->getX(), (int) $block->getZ())){
               $event->setCancelled(true);
            }
         }
      }
   }
}