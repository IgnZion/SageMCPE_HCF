<?php
declare(strict_types=1);
namespace hcf\events\listener;

use hcf\{AlpineCore, AlpinePlayer, manager\CratesManager};
use pocketmine\{item\Item, item\ItemIds, block\Block};
use pocketmine\math\Vector3;
use pocketmine\event\Listener;
use pocketmine\utils\TextFormat as C;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\nbt\tag\{StringTag, IntTag ,CompoundTag, ListTag, ByteTag};

class CratesListener implements Listener {
    private $plugin;
    public function __construct(AlpineCore $plugin){
        $this->plugin = $plugin;
    }
    
    /** 
     * @param PlayerInteractEvent $event 
     */
    public function onTap(PlayerInteractEvent $event){
        $item = $event->getItem();
        $player = $event->getPlayer();
        $nametag = $item->getNamedTag();
        if($nametag->hasTag("lives", IntTag::class)){
            $lives = $nametag->getInt("lives");
            $player->setLives($player->getLives() + $lives);
            $item->pop();
            $player->getInventory()->setItemInHand($item);
        }
        $x = (int) $event->getBlock()->getX();
        $y = (int) $event->getBlock()->getY();
        $z = (int) $event->getBlock()->getZ();
        $mgr = AlpineCore::getCratesManager();
        if($mgr->isCrate(0, $x, $y, $z)){
            $event->setCancelled(true);
            if($mgr->isKey(0, $item)){
                $mgr->openCrate($player, 0);
                $item->pop();
                $player->getInventory()->setItemInHand($item);
            } else {
                $mgr->showRewards($player, 0);
            }
        }
        if($mgr->isCrate(1, $x, $y, $z)){
            $event->setCancelled(true);
            $item = $event->getItem();
            if($mgr->isKey(1, $item)){
                $mgr->openCrate($player, 1);
                $item->pop();
                $player->getInventory()->setItemInHand($item);
            } else {
                $mgr->showRewards($player, 1);
            }
        }
        if($mgr->isCrate(2, $x, $y, $z)){
            $event->setCancelled(true);
            $item = $event->getItem();
            if($mgr->isKey(2, $item)){
                $mgr->openCrate($player, 2);
                $item->pop();
                $player->getInventory()->setItemInHand($item);
            } else {
                $mgr->showRewards($player, 2);
            }
        }
        if($mgr->isCrate(3, $x, $y, $z)){
            $event->setCancelled(true);
            $item = $event->getItem();
            if($mgr->isKey(3, $item)){
                $mgr->openCrate($player, 3);
                $item->pop();
                $player->getInventory()->setItemInHand($item);
            } else {
                $mgr->showRewards($player, 3);
            }
        }
        if($mgr->isCrate(4, $x, $y, $z)){
            $event->setCancelled(true);
            $item = $event->getItem();
            if($mgr->isKey(4, $item)){
                $mgr->openCrate($player, 4);
                $item->pop();
                $player->getInventory()->setItemInHand($item);
            } else {
                $mgr->showRewards($player, 4);
            }
        }
        if($mgr->isCrate(5, $x, $y, $z)){
            $event->setCancelled(true);
            $item = $event->getItem();
            if($mgr->isKey(5, $item)){
                $mgr->openCrate($player, 5);
                $item->pop();
                $player->getInventory()->setItemInHand($item);
            } else {
                $mgr->showRewards($player, 5);
            }
        }
    }
}