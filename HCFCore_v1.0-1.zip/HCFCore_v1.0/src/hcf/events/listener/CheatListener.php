<?php
declare(strict_types=1);
namespace hcf\events\listener;

use hcf\{AlpineCore, AlpinePlayer, utils\Utils};
use pocketmine\{Player, event\server\DataPacketReceiveEvent, network\mcpe\protocol\InventoryTransactionPacket};
use pocketmine\entity\{Entity, Effect, Arrow};
use pocketmine\event\Listener;
use pocketmine\math\Vector3;
use pocketmine\utils\TextFormat as TF;
use pocketmine\block\{Block, BlockIds};
use pocketmine\event\player\{PlayerMoveEvent, PlayerInteractEvent};
use pocketmine\event\entity\{EntityDamageByEntityEvent, EntityDamageEvent};

class CheatListener implements Listener {
   /** @var AlpineCore $plugin */
   private $plugin;
   /** @var array $hits */
   private $hits = [];
   /** @var array $timer */
   private $timer = [];

   /**
     * @param AlpineCore $plugin
     */
   public function __construct(AlpineCore $plugin){
      $this->plugin = $plugin;
   }

   /**
    * @param PlayerMoveEvent $event
    */
    public function onMoveCheck(PlayerMoveEvent $event){
        $player = $event->getPlayer();
        $level = $player->getLevel();
        $block1 = $level->getBlock(new Vector3($event->getTo()->getX(), $event->getTo()->getY(), $event->getTo()->getZ()));
        $block2 = $level->getBlock(new Vector3($event->getTo()->getX(), $event->getTo()->getY()+1, $event->getTo()->getZ()));
        if(!$player->isCreative() && !$player->isSpectator() && !$player->getAllowFlight()){
            if($block1->getId() == BlockIds::TRAPDOOR) return;
            if($block2->getId() == BlockIds::TRAPDOOR) return;
            if($block1->getId() == BlockIds::OAK_FENCE_GATE) return;
            if($block1->getId() == BlockIds::WOODEN_TRAPDOOR) return;
            if($block2->getId() == BlockIds::WOODEN_TRAPDOOR) return;
            if($block1->getId() == BlockIds::BIRCH_FENCE_GATE) return;
            if($block1->getId() == BlockIds::ACACIA_FENCE_GATE) return;
            if($block1->getId() == BlockIds::JUNGLE_FENCE_GATE) return;
            if($block1->getId() == BlockIds::SPRUCE_FENCE_GATE) return;
            if($block1->getId() == BlockIds::DARK_OAK_FENCE_GATE) return;
            if($block1->getId() == BlockIds::PORTAL || $block2->getId() == BlockIds::PORTAL) return;
            if($block2->isSolid() || $block1->getId() == BlockIds::SAND || $block1->getId() == BlockIds::GRAVEL || $block2->getId() == BlockIds::SAND || $block2->getId() == BlockIds::GRAVEL){
                $player->teleport($event->getFrom());
                foreach(AlpineCore::getInstance()->getServer()->getOnlinePlayers() as $staff){
                    if($staff->isStaffMode() || $staff->hasAlerts()){
                        $staff->sendMessage(TF::BOLD . TF::DARK_RED . "ALERT: " . TF::RESET . TF::GRAY . $player->getName() . " has triggered no-clip system, check it out!");
                    }
                }
            }
        }
    }

    /**
     * @param EntityDamageEvent $event
     */
    public function onDamage(EntityDamageEvent $event) {
        $entity = $event->getEntity();
        if($event->getCause() != EntityDamageEvent::CAUSE_PROJECTILE){
            if($event instanceof EntityDamageByEntityEvent and $entity instanceof AlpinePlayer){
                $damager = $event->getDamager();
                if($damager instanceof AlpinePlayer){
                    $distance = $damager->distance($entity);
                    $max = 4;
                    if($distance > $max){
                        $event->setCancelled(true);
                        foreach(AlpineCore::getInstance()->getServer()->getOnlinePlayers() as $staff){
                            if($staff->isStaffMode()){
                                $staff->sendMessage(TF::BOLD . TF::DARK_RED . "ALERT: " . TF::RESET . TF::GRAY . $damager->getName() . " got " . $distance . " of reach!");
                            }
                        }
                    }
                }
            }
        }
    }
}