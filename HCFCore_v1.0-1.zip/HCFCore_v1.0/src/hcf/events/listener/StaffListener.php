<?php
declare(strict_types=1);
namespace hcf\events\listener;

use hcf\{
   AlpineCore, AlpinePlayer
};
use muqsit\invmenu\{
   InvMenu, InvMenuHandler};
use pocketmine\{Player, inventory\PlayerInventory};
use pocketmine\event\Listener;
use pocketmine\math\Vector3;
use pocketmine\utils\TextFormat as C;
use pocketmine\event\inventory\InventoryPickupItemEvent;
use pocketmine\event\entity\{
    EntityDamageEvent, EntityDamageByEntityEvent
};
use pocketmine\event\player\{
   PlayerMoveEvent, PlayerChatEvent, PlayerDropItemEvent, PlayerInteractEvent, PlayerExhaustEvent, PlayerCommandPreprocessEvent, PlayerItemHeldEvent
};
use pocketmine\event\block\{
   BlockPlaceEvent, BlockBreakEvent
};
use pocketmine\nbt\tag\{
   StringTag, IntTag, CompoundTag, ListTag};

class StaffListener implements Listener {

   private $plugin;
   const ARMOR_INVENTORY_MENU_SLOTS = [
       0 => 47,
       1 => 48,
       2 => 49,
       3 => 50
   ];

   /**
     * @param AlpineCore $plugin
     */
   public function __construct(AlpineCore $plugin){
      $this->plugin = $plugin;
   }

   /**
     * @param PlayerChatEvent $event
     */
   public function onChat(PlayerChatEvent $event){
      $server = $this->plugin->getServer();
      $player = $event->getPlayer();
      $online = $server->getOnlinePlayers();
      if($player instanceof AlpinePlayer){
         if($player->getChat() == AlpinePlayer::STAFF){
            $event->setCancelled(true);
            foreach($online as $staff){
               if($staff->hasPermission("core.staffchat")){
                  $staff->sendMessage("❌" . C::BOLD . C::GRAY . "(" . C::DARK_RED . "STAFF" . C::GRAY . ") " . C::RED . $player->getName() . ": " . C::WHITE . $event->getMessage());
               }
            }
         }
      }
   }
   
   /**
   * @param PlayerDropItemEvent $event
   */
   public function onDrop(PlayerDropItemEvent $event) {
       if($event->getPlayer() instanceof AlpinePlayer){
           if($event->getPlayer()->isStaffMode()){
               $event->setCancelled(true);
           }
       }
   }

   /**
   * @param InventoryPickupItemEvent $event
   */
   public function onPickup(InventoryPickupItemEvent $event) {
       if($event->getInventory() instanceof PlayerInventory){
           if($event->getInventory()->getHolder() instanceof AlpinePlayer){
               if($event->getInventory()->getHolder()->isStaffMode()){
                   $event->setCancelled(true);
               }
           }
       }
   }

   /**
   * @param BlockBreakEvent $event
   */
   public function onBreak(BlockBreakEvent $event) {
       if($event->getPlayer() instanceof AlpinePlayer){
           if($event->getPlayer()->isStaffMode()){
               $event->setCancelled(true);
           }
       }
   }
   
   /**
   * @param BlockPlaceEvent $event
   */
   public function onPlace(BlockPlaceEvent $event) {
       if($event->getPlayer() instanceof AlpinePlayer){
           if($event->getPlayer()->isStaffMode()){
               $event->setCancelled(true);
           }
       }
   }

   /**
   * @param PlayerExhaustEvent $event
   */
   public function onHunger(PlayerExhaustEvent $event) {
       if($event->getPlayer() instanceof AlpinePlayer){
           if($event->getPlayer()->isStaffMode()){
               $event->setCancelled(true);
           }
       }
   }

   /**
   * @param PlayerItemHeldEvent $event
   */
   public function onHeld(PlayerItemHeldEvent $event) {
       if($event->getPlayer() instanceof AlpinePlayer){
           if($event->getPlayer()->isStaffMode()){
               $item = $event->getItem()->getNamedTag();
               if($item->hasTag("staffitem", StringTag::class)){
                   $tag = $item->getString("staffitem");
                   if($tag == "phase"){
                       $event->getPlayer()->setGamemode(Player::SURVIVAL);
                       $event->getPlayer()->setFlying(true);
                       $event->getPlayer()->setAllowFlight(true);
                   }
               }
           }
       }
   }

   /**
   * @param PlayerInteractEvent $event
   */
   public function onTap(PlayerInteractEvent $event) {
       if($event->getPlayer() instanceof AlpinePlayer){
           if($event->getPlayer()->isStaffMode()){
               $item = $event->getItem()->getNamedTag();
               if($item->hasTag("staffitem", StringTag::class)){
                   $tag = $item->getString("staffitem");

                   if($tag == "vanish"){
                       if(!$event->getPlayer()->isVanished()){
                           $event->getPlayer()->setNameTag(C::RESET. C::RED . "[VANISHED] " . C::RESET . $event->getPlayer()->getNameTag());
                           $event->getPlayer()->setVanished(true);
                           foreach(AlpineCore::getInstance()->getServer()->getOnlinePlayers() as $players){
                               if(!$players->hasPermission("core.staff.seevanished")){
                                   $players->hidePlayer($event->getPlayer());
                               }
                           }
                       } else {
                           $event->getPlayer()->setVanished(false);
                           if($event->getPlayer()->isPvP()){
                               $event->getPlayer()->setNameTag(C::RESET . C::GREEN . "[PvPTimer] " . C::GRAY . $event->getPlayer()->getName());
                           } else {
                               $event->getPlayer()->setNameTag(C::RESET. C::GRAY . $event->getPlayer()->getName());
                           }
                           foreach(AlpineCore::getInstance()->getServer()->getOnlinePlayers() as $players){
                               $players->showPlayer($event->getPlayer());
                           }
                       }
                   }

                   if($tag == "randomteleport"){
                       $players = AlpineCore::getInstance()->getServer()->getOnlinePlayers();
                       $random = array_rand($players);
                       $randomplayer = $players[$random];
                       $event->getPlayer()->teleport($randomplayer);
                       $event->getPlayer()->sendMessage(C::RESET . C::GRAY . "Teleported to " . C::GREEN . $randomplayer->getName());
                   }

                   if($tag == "lockteleport"){
                       $locked = AlpineCore::getInstance()->getServer()->getPlayer($event->getPlayer()->getLockedPlayer());
                       if($locked != null){
                           $event->getPlayer()->teleport($locked);
                           $event->getPlayer()->sendMessage(C::RESET . C::GRAY . "Teleported to " . C::GREEN . $locked->getName());
                       }
                   }

                   if($tag == "phase"){
                       if($event->getPlayer()->getGamemode() != Player::SPECTATOR){
                           $event->getPlayer()->setGamemode(Player::SPECTATOR);
                       }
                   }
               }
           }
       }
   }

   /**
   * @param EntityDamageEvent $event
   */
   public function onDamage(EntityDamageEvent $event) {
       $entity = $event->getEntity();
       if($entity instanceof AlpinePlayer){
           if($entity->isStaffMode()){
               $event->setCancelled(true);
           }
           if($event instanceof EntityDamageByEntityEvent){
               $damager = $event->getDamager();
               if($damager instanceof AlpinePlayer){
                   if($damager->isStaffMode() && $entity instanceof AlpinePlayer){
                       $event->setCancelled(true);
                       $item = $damager->getInventory()->getItemInHand()->getNamedTag();
                       if($item->hasTag("staffitem", StringTag::class)){
                           $tag = $item->getString("staffitem");
                           
                           if($tag == "lockteleport"){
                               $damager->setLockedPlayer($entity->getName());
                               $damager->sendMessage(C::RESET . C::GRAY . "Locked to " . C::GREEN . $entity->getName());
                           }

                           if($tag == "freeze"){
                               if($entity->isFrozen()){
                                   $entity->setFrozen(false);
                                   $entity->setImmobile(false);
                                   $entity->sendMessage(C::RESET . C::GREEN . "You have been unfrozen by a staff member!" . C::RESET . "\n\n\n" . C::DARK_GREEN . "> Thanks for complying with our staff team");
                                   $damager->sendMessage(C::RESET . C::GRAY . "You unfroze " . C::GREEN . $entity->getName());
                               } else {
                                   $entity->setFrozen(true);
                                   $entity->setImmobile(true);
                                   $entity->sendMessage(C::RESET . C::RED . "You have been frozen by a staff member!" . C::RESET . "\n\n\n" . C::DARK_RED . "> DO NOT LEAVE! IF YOU DO YOU WILL BE BANNED!!");
                                   $damager->sendMessage(C::RESET . C::GRAY . "You froze " . C::GREEN . $entity->getName());
                               }
                           }

                           if($tag == "seeinventory"){
                               $armors = $entity->getArmorInventory()->getContents();
                               $items = $entity->getInventory()->getContents();
                               $damager->setViewing($entity->getName());
                               $menu = InvMenu::create(InvMenu::TYPE_DOUBLE_CHEST);
                               $menu->readonly();
                               $menu->setName(C::RESET . $entity->getName() . "  Inventory");
                               foreach($items as $item){
                                   $menu->getInventory()->addItem($item);
                               }
                               $i = 47;
                               foreach($armors as $armor){
                                   while($i < 51){
                                       $menu->getInventory()->setItem($i, $armor);
                                   }
                                   $i++;
                               }
                               $menu->setListener(function (AlpinePlayer $damager, Item $itemTakenOut, Item $itemPutIn,  SlotChangeAction $change): bool {
                                   if($itemTakenOut instanceof Item){
                                       $locked = AlpineCore::getInstance()->getServer()->getPlayer($damager->getViewing());
                                       if($locked == null){
                                           $damager->removeWindow($change->getInventory());
                                       } else {
                                           if($damager->hasPermission("core.seeinventory.takeitems")){
                                               $damager->sendMessage("COMING SOON");
                                           }
                                       }
                                   }
                                   return true;
                               });
                               $menu->send($damager);
                           }
                       }                       
                   }
               }
           }
       }
   }

   /**
   * @param PlayerCommandPreprocessEvent $event
   */
   public function onPreChat(PlayerCommandPreprocessEvent $event) {
       $command = str_split($event->getMessage());
       $player = $event->getPlayer();
       if($player->isFrozen()){
           if($command[0] == "/"){
               $event->setCancelled(true);
               $player->sendMessage(C::RESET . c::BOLD . C::RED . "»» " . C::RESET . C::GRAY . "You cannot run commands whilst frozen!");
           }
           if($command[0] == "." && $command[1] == "/"){
               $event->setCancelled(true);
               $player->sendMessage(C::RESET . c::BOLD . C::RED . "»» " . C::RESET . C::GRAY . "Nice try but that won't work either, you are frozen!");
           }
           if($command[0] == "/" && $command[1] == "m" && $command[2] == "e"){
               $event->setCancelled(true);
               $player->sendMessage(C::RESET . c::BOLD . C::RED . "»» " . C::RESET . C::GRAY . "Nice try but that won't work!");
           }
           if($command[0] == "." && $command[1] == "/" && $command[2] == "m" && $command[3] == "e"){
               $event->setCancelled(true);
               $player->sendMessage(C::RESET . c::BOLD . C::RED . "»» " . C::RESET . C::GRAY . "Nice try but that won't work either!");
           }
       }
   }
}