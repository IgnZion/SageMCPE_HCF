<?php
declare(strict_types=1);
namespace hcf\events\listener;

use hcf\{
   AlpineCore, AlpinePlayer, utils\Utils, tasks\TransferTask, entity\BetterEnderPearl, tasks\async\ZombieLoggerAsyncTask
};
use pocketmine\{item\Item, block\Block, block\BlockIds, event\inventory\CraftItemEvent};
use pocketmine\entity\Entity;
use pocketmine\event\Listener;
use Heisnenbuger69\BurgerSpawners\Entities\Zombie;
use pocketmine\math\Vector3;
use pocketmine\utils\TextFormat as TF;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\event\player\{
   PlayerInteractEvent, PlayerMoveEvent, PlayerChatEvent, PlayerDeathEvent, PlayerQuitEvent, PlayerJoinEvent, PlayerPreLoginEvent, PlayerExhaustEvent, PlayerItemConsumeEvent
};
use pocketmine\event\entity\{
   EntityDamageByEntityEvent, EntityDamageEvent, EntityDeathEvent
};
use pocketmine\event\block\{
   BlockPlaceEvent, BlockBreakEvent
};
use pocketmine\nbt\tag\{StringTag, IntTag, CompoundTag, ListTag, DoubleTag, FloatTag};
use pocketmine\network\mcpe\protocol\{AddActorPacket, PlaySoundPacket};
class PlayerListener implements Listener {
   private $plugin;
   private $chatcooldown = [];
   /**
     * @param AlpineCore $plugin
     */
   public function __construct(AlpineCore $plugin){
      $this->plugin = $plugin;
   }

    /**
     * @param PlayerExhaustEvent $event
     */
    public function onHunger(PlayerExhaustEvent $event) {
        $event->setCancelled(true);
    }

    /**
     * @param CraftItemEvent $event
     */
    public function onCraft(CraftItemEvent $event) {
        $outputs = $event->getOutputs();
        foreach($outputs as $item){
            if($item->getId() == Item::TNT){
                $event->setCancelled(true);
            }
        }
    }

    /**
     * @param PlayerItemConsumeEvent $event
     */
    public function onConsume(PlayerItemConsumeEvent $event) {
        if($event->getItem()->getId() == Item::ENCHANTED_GOLDEN_APPLE){
            $player = $event->getPlayer();
            $cooldown = $player->getGappleCooldown();
            if(($cooldown - time()) >= 1){
                $event->setCancelled(true);
            } else {
                $time = time() + (60 * 60 * 3);
                $player->setGappleCooldown($time);
            }
        }
        if($event->getItem()->getId() == Item::GOLDEN_APPLE){
            $player = $event->getPlayer();
            $cooldown = $player->getNormalGappleCooldown();
            if(($cooldown - time()) >= 1){
                $event->setCancelled(true);
            } else {
                $player->setNormalGappleCooldown(45);
            }
        }
    }

   /**
     * @param EntityDeathEvent $event
     */
   public function onEntityDeath(EntityDeathEvent $event){
       $entity = $event->getEntity();
       $m = AlpineCore::getFactionsManager();
       $name = $entity->getNameTag();
       if(AlpineCore::getLoggerManager()->isZombie($entity->getNameTag())){
           $items = array();
           foreach(AlpineCore::getLoggerManager()->getInventoryDrops($name) as $inv){
               $items[] = $inv;
           }
           foreach(AlpineCore::getLoggerManager()->getArmorDrops($name) as $armor){
               $items[] = $armor;
           }
           $event->setDrops($items);
           if($m->isInFaction($entity->getNameTag())){
               $fac = $m->getFaction($entity->getNameTag());
               $m->reduceDTR($fac);
               $m->movePoints($fac, 1);
           }
           AlpineCore::getInstance()->getServer()->getAsyncPool()->submitTask(new ZombieLoggerAsyncTask($name));
           AlpineCore::getLoggerManager()->removeZombie($name);

       }
   }

   /**
     * @param DataPacketReceiveEvent $event
     */
   public function onDataReceive(DataPacketReceiveEvent $event){
      $packet = $event->getPacket();
      if($packet instanceof \pocketmine\network\mcpe\protocol\ItemFrameDropItemPacket){
         $player = $event->getPlayer();
         $mgr = AlpineCore::getFactionsManager();
         if($mgr->isSpawnClaim($player->asVector3(), $player->getLevel())){
            if(!$player->isOp()){
                 $event->setCancelled();
                 $player->getLevel()->getTile(new Vector3($pk->x, $pk->y, $pk->z))->spawnTo($player);
            }
         }
      }
   }

   /**
     * @param PlayerInteractEvent $event
     */
   public function onInteract(PlayerInteractEvent $event){
      $player = $event->getPlayer();
      $item = $event->getItem();
      $block = $event->getBlock();
      $mgr = AlpineCore::getFactionsManager();
      if(!$player->isOp()){
         if($mgr->isSpawnClaim($block->asVector3(), $player->getLevel())){
            if($block->getId() == BlockIds::WOODEN_TRAPDOOR){
               $event->setCancelled(true);
            }
         }
      }
      if($item->getId() == Item::SPLASH_POTION && $item->getDamage() == 22){
         $rand = mt_rand(6, 9);
         if(($player->getHealth() + $rand) <= 20){
            $player->getInventory()->setItemInHand(Item::get(Item::AIR));
            $player->setHealth($player->getHealth() + $rand);
         } else {
            $player->getInventory()->setItemInHand(Item::get(Item::AIR));
            $player->setHealth(20);
         }
      }
      if($item->getId() == Item::ENDER_PEARL){
         $event->setCancelled(true);
         if($player instanceof AlpinePlayer){
            $epcooldown = $player->getPartnerItemCooldown("pearlcooldown");
            if(($epcooldown - time()) >= 1){
               return;
            } else {
               $player->setPartnerItemCooldown("pearlcooldown", 10);
            }
            $nbt = new CompoundTag("", [
               "Pos" => new ListTag("Pos", [
                  new DoubleTag("", $player->x),
                  new DoubleTag("", $player->y + $player->getEyeHeight()),
                  new DoubleTag("", $player->z),
               ]),
               "Motion" => new ListTag("Motion", [
                  new DoubleTag("", -sin($player->yaw / 180 * M_PI) * cos($player->pitch / 180 * M_PI)), 
                  new DoubleTag("", -sin($player->pitch / 180 * M_PI)),
                  new DoubleTag("", cos($player->yaw / 180 * M_PI) * cos($player->pitch / 180 * M_PI)),
               ]),
               "Rotation" => new ListTag("Rotation", [
                  new FloatTag("", $player->yaw),
                  new FloatTag("", $player->pitch),
               ]),
            ]);
            $entity = Entity::createEntity("BetterEnderPearl", $player->getLevel(), $nbt, $player);
            if($entity instanceof BetterEnderPearl){
               if($entity->isGoingToCollide()){
                  $entity->kill();
                  return;
               }
            }
            if($entity != null) $entity->setMotion($entity->getMotion()->multiply(1.45));
            if($entity instanceof BetterEnderPearl){
               $entity->spawnToAll();
            }
         }
      }
   }

   /**
     * @param PlayerMoveEvent $event
     */
   public function onMove(PlayerMoveEvent $event){
      $mgr = AlpineCore::getFactionsManager();
      $player = $event->getPlayer();
      $x = (int) $player->getX();
      $z = (int) $player->getZ();
      if($player instanceof AlpinePlayer){
         if($player->isMovementDisabled()) $event->setCancelled(true);
         if($player->getArchertagTime() > 0 || $player->getSpawntagTime() > 0){
            if($mgr->isSpawnClaim($event->getTo(), $player->getLevel())){
               $event->setCancelled(true);
               $player->teleport($event->getFrom());
            }
            if($mgr->isNetherSpawnClaim($event->getTo(), $player->getLevel())){
               $event->setCancelled(true);
               $player->teleport($event->getFrom());
            }
         }
         if($player->getRegion() == "null"){
            if($mgr->isSpawnClaim($player, $player->getLevel())){
               $player->setRegion("Spawn");
            } elseif($mgr->isNetherSpawnClaim($player, $player->getLevel())){
               $player->setRegion("Spawn");
            } elseif($mgr->isClaim($player, $player->getLevel())){
            $region = $mgr->getClaimer($x, $z);
            $player->setRegion($region);
            } elseif($mgr->isRoad($player, $player->getLevel())){
            $region = $mgr->getRoad($player, $player->getLevel());
            $player->setRegion($region);
            } elseif($mgr->isNetherRoad($player, $player->getLevel())){
            $region = $mgr->getNetherRoad($player, $player->getLevel());
            $player->setRegion($region);
            } else {
            $player->setRegion("Wilderness");
            }
         }
         if($player->getRegion() != $player->getCurrentRegion()){
            if($player->getCurrentRegion() == "Spawn"){
               $player->sendMessage("§cNow Leaving §7" . $player->getRegion() . " §7(§cDeathban§7) §aNow Entering §7Spawn (§aNon-Deathban§7)");
            } else {
               if($player->getRegion() == "Spawn"){
                  $player->sendMessage("§cNow Leaving §7Spawn (§aNon-Deathban§7) §cNow Entering §7" . $player->getCurrentRegion() . " §7(§cDeathban§7)");
            } else {
               $player->sendMessage("§cNow Leaving §7" . $player->getRegion() . " §7(§cDeathban§7) §cNow Entering §7" . $player->getCurrentRegion() . " §7(§cDeathban§7)");
            }
         }
         $region = $player->getCurrentRegion();
         $player->setRegion($region);
         }
      }
   }
   
   /**
     * @param PlayerChatEvent $event
     */
   public function onChat(PlayerChatEvent $event){
      if($event->getPlayer() instanceof AlpinePlayer){
         $player = $event->getPlayer();
         $rank = $player->getRank();
         $mutedtime = $player->getMutedTime();
         if(($mutedtime - time()) >= 1){
             $event->setCancelled();
             $time = (int) $mutedtime - time();
             $player->sendMessage(TF::RED . TF::BOLD . "»» " . TF::RESET . TF::GRAY .  "You are muted for a remaining time of " . Utils::intToTime($time));
         } else $player->setMutedTime(0);
         if(!isset($this->chatcooldown[$player->getName()])){
            $this->chatcooldown[$player->getName()] = time();
         } else {
            if((time() - $this->chatcooldown[$player->getName()]) < 3 && $rank == "Player"){
               $event->setCancelled();
               $player->sendMessage(TF::RED . TF::BOLD . "»» " . TF::RESET . TF::GRAY . "Please do not spam the chat! Purchase a Rank to remove this restriction.");
               return;
            } else {
               $this->chatcooldown[$player->getName()] = time();
            }
         }
         $chatrank = TF::GRAY . $player->getName() . TF::WHITE . ": " . TF::GRAY;
         if($rank == "Voyager"){
            $chatrank = TF::DARK_GRAY . "[" . TF::BLUE . "Voyager" . TF::DARK_GRAY . "] " . TF::RESET . TF::GRAY . $player->getName() . TF::WHITE . ": " . TF::GRAY;
         } elseif($rank == "Pioneer"){
            $chatrank = TF::DARK_GRAY . "[" . TF::RED . "Pioneer" . TF::DARK_GRAY . "] " . TF::RESET . TF::GRAY . $player->getName() . TF::WHITE . ": " . TF::GRAY;
         } elseif($rank == "Alpinist"){
            $chatrank = TF::DARK_GRAY . "[" . TF::GOLD . "Alpinist" . TF::DARK_GRAY . "] " . TF::RESET . TF::GRAY . $player->getName() . TF::WHITE . ": " . TF::GRAY;
         } elseif($rank == "NitroBooster"){
            $chatrank = TF::DARK_GRAY . "[" . TF::LIGHT_PURPLE . "Booster" . TF::DARK_GRAY . "] " . TF::RESET . TF::GRAY . $player->getName() . TF::WHITE . ": " . TF::GRAY;
         } elseif($rank == "Trainee"){
            $chatrank = TF::DARK_GRAY . "[" . TF::YELLOW . "T-Mod" . TF::DARK_GRAY . "] " . TF::RESET . TF::GRAY . $player->getName() . TF::WHITE . ": " . TF::GRAY;
         } elseif($rank == "Mod"){  
            $chatrank = TF::DARK_GRAY . "[" . TF::GREEN . "Mod" . TF::DARK_GRAY . "] " . TF::RESET . TF::GRAY . $player->getName() . TF::WHITE . ": " . TF::GRAY;
         } elseif($rank == "SrMod"){
            $chatrank = TF::DARK_GRAY . "[" . TF::DARK_GREEN . "SrMod" . TF::DARK_GRAY . "] " . TF::RESET . TF::GRAY . $player->getName() . TF::WHITE . ": " . TF::GRAY;
         } elseif($rank == "Admin"){  
            $chatrank = TF::DARK_GRAY . "[" . TF::RED . "Admin" . TF::DARK_GRAY . "] " . TF::RESET . TF::GRAY . $player->getName() . TF::WHITE . ": " . TF::GRAY;
         } elseif($rank == "SrAdmin"){
            $chatrank = TF::DARK_GRAY . "[" . TF::DARK_RED . "SrAdmin" . TF::DARK_GRAY . "] " . TF::RESET . TF::GRAY . $player->getName() . TF::WHITE . ": " . TF::GRAY;
         } elseif($rank == "Manager"){  
            $chatrank = TF::DARK_GRAY . "[" . TF::AQUA . "Manager" . TF::DARK_GRAY . "] " . TF::RESET . TF::GRAY . $player->getName() . TF::WHITE . ": " . TF::GRAY;
         } elseif($rank == "Owner"){  
            $chatrank = TF::DARK_GRAY . "[" . TF::DARK_AQUA . "Owner" . TF::DARK_GRAY . "] " . TF::RESET . TF::GRAY . $player->getName() . TF::WHITE . ": " . TF::GRAY;
         } elseif($rank == "Partner"){
            $chatrank = TF::DARK_GRAY . "[" . TF::DARK_PURPLE . "Partner" . TF::DARK_GRAY . "] " . TF::RESET . TF::GRAY . $player->getName() . TF::WHITE . ": " . TF::GRAY;
         } elseif($rank == "YouTuber"){  
            $chatrank = TF::DARK_GRAY . "[" . TF::WHITE . "You" . TF::RED . "Tuber" . TF::DARK_GRAY . "] " . TF::RESET . TF::GRAY . $player->getName() . TF::WHITE . ": " . TF::GRAY;
         } else {
            $chatrank = TF::GRAY . $player->getName() . TF::WHITE . ": " . TF::GRAY;
         }
         if($player->isInFaction()){
            $fac = $player->getFaction();
            $event->setFormat(TF::DARK_GRAY . "[" . TF::GRAY . $fac . TF::DARK_GRAY. "] " . $chatrank . ucfirst(strtolower($event->getMessage())));
         } else {
            $event->setFormat($chatrank . ucfirst(strtolower($event->getMessage())));
         }
      }
   }

   /**
     * @param PlayerDeathEvent $event
     */
   public function onDeath(PlayerDeathEvent $event){
      if($event->getPlayer() instanceof AlpinePlayer){
         $player = $event->getPlayer();
         $rank = $player->getRank();
         $player->addDeath(1);
         $cause = $player->getLastDamageCause();
         if($cause instanceof EntityDamageByEntityEvent){
            if($cause->getCause() == EntityDamageEvent::CAUSE_ENTITY_ATTACK){
               if($cause->getDamager() instanceof AlpinePlayer){
                  $cause->getDamager()->addKill(1);
                  $item = $cause->getDamager()->getInventory()->getItemInHand();
                  $name = $item->getName();
                  $pkills = TF::GRAY . "[" . TF::GOLD . $player->getKills() . TF::GRAY . "]";
                  $kkills = TF::GRAY . "[" . TF::GOLD . $cause->getDamager()->getKills() . TF::GRAY . "]";
                  if($item->hasCustomName()) $name = $item->getCustomName();
                  $event->setDeathMessage(TF::RED . $player->getName() . $pkills . TF::GRAY . " was killed by " . TF::GREEN . $cause->getDamager()->getName() . $kkills . TF::GRAY . " using " . $name);
               }
            }
         }
         if($cause instanceof EntityDamageEvent){
            $pkills = TF::GRAY . "[" . TF::GOLD . $player->getKills() . TF::GRAY . "]";
            if($cause->getCause() == EntityDamageEvent::CAUSE_PROJECTILE){
               $event->setDeathMessage(TF::RED . $player->getName() . $pkills . TF::GRAY . " was shot to death");
            }
            if($cause->getCause() == EntityDamageEvent::CAUSE_SUFFOCATION){
               $event->setDeathMessage(TF::RED . $player->getName() . $pkills . TF::GRAY . " suffocated to death");
            }
            if($cause->getCause() == EntityDamageEvent::CAUSE_FALL){
               $event->setDeathMessage(TF::RED . $player->getName() . $pkills . TF::GRAY . " broke their legs");
            }
            if($cause->getCause() == EntityDamageEvent::CAUSE_FIRE){
               $event->setDeathMessage(TF::RED . $player->getName() . $pkills . TF::GRAY . " tried to taste fire");
            }
            if($cause->getCause() == EntityDamageEvent::CAUSE_FIRE_TICK){
               $event->setDeathMessage(TF::RED . $player->getName() . $pkills . TF::GRAY . " was too hot");
            }
            if($cause->getCause() == EntityDamageEvent::CAUSE_LAVA){
               $event->setDeathMessage(TF::RED . $player->getName() . $pkills . TF::GRAY . " was burnt by lava");
            }
            if($cause->getCause() == EntityDamageEvent::CAUSE_DROWNING){
               $event->setDeathMessage(TF::RED . $player->getName() . $pkills . TF::GRAY . " drowned to death");
            }
            if($cause->getCause() == EntityDamageEvent::CAUSE_BLOCK_EXPLOSION){
               $event->setDeathMessage(TF::RED . $player->getName() . $pkills . TF::GRAY . " exploded to death");
            }
            if($cause->getCause() == EntityDamageEvent::CAUSE_ENTITY_EXPLOSION){
               $event->setDeathMessage(TF::RED . $player->getName() . $pkills . TF::GRAY . " was creeper aww man to death");
            }
            if($cause->getCause() == EntityDamageEvent::CAUSE_VOID){
               $event->setDeathMessage(TF::RED . $player->getName() . $pkills . TF::GRAY . " fell to death");
            }
            if($cause->getCause() == EntityDamageEvent::CAUSE_MAGIC){
               $event->setDeathMessage(TF::RED . $player->getName() . $pkills . TF::GRAY . " was splashed to death");
            }
            if($cause->getCause() == EntityDamageEvent::CAUSE_SUICIDE){
               $event->setDeathMessage(TF::RED . $player->getName() . $pkills . TF::GRAY . " OOFed themselves");
            }
         }
         if($rank == "Pioneer"){
            $time = time() + (60 * 25);
         } elseif($rank == "Voyager"){
            $time = time() + (60 * 15);
         } elseif($rank == "NitroBooster"){
            $time = time() + (60 * 20);
         } elseif($rank == "Alpinist"){
            $time = time() + (60 * 10);
         } elseif($rank == "Partner"){
            $time = time() + (60 * 10);
         } elseif($rank == "YouTuber"){
            $time = time() + (60 * 15);
         } else {
            $time = time() + (60 * 30);
         }
         $player->setDeathBanned("true");
         $player->setDeathBanTime($time);
         $player->setSpawntagTime(0);
         $player->setSpawnTagged(false);
         $light = $player->getLevel();
         $light = new AddActorPacket();
         $light->type = 93;
         $light->entityRuntimeId = Entity::$entityCount++;
         $light->metadata = array();
         $light->motion = null;
         $light->yaw = $player->getYaw();
         $light->pitch = $player->getPitch();
         $light->position = new Vector3($player->getX(), $player->getY(), $player->getZ());
         $sound = new PlaySoundPacket();
         $sound->x = $player->getX();
         $sound->y = $player->getY();
         $sound->z = $player->getZ();
         $sound->volume = 3;
         $sound->pitch = 2;
         $sound->soundName = "AMBIENT.WEATHER.LIGHTNING.IMPACT";
         AlpineCore::getInstance()->getServer()->broadcastPacket($player->getLevel()->getPlayers(), $sound);
         AlpineCore::getInstance()->getScheduler()->scheduleDelayedTask(new TransferTask(AlpineCore::getInstance(), $player), 40);
      }
   }

   /** 
     * @param EntityDamageEvent $event
     */
   public function onDamage(EntityDamageEvent $event){
      $entity = $event->getEntity();
      $mgr = AlpineCore::getFactionsManager();
      if($mgr->isSpawnClaim($entity, $entity->getLevel())){
          $event->setCancelled(true);
      }
      if($entity instanceof AlpinePlayer && $entity->isStaffMode()){
          $event->setCancelled(true);
      }
      if($mgr->isNetherSpawnClaim($entity, $entity->getLevel())){
         $event->setCancelled(true);
      }
      if($event instanceof EntityDamageByEntityEvent){
            $entity = $event->getEntity();
            $damager = $event->getDamager();
            if($mgr->isSpawnClaim($entity, $entity->getLevel())){
               $event->setCancelled(true);
            }
            if($mgr->isNetherSpawnClaim($entity, $entity->getLevel())){
               $event->setCancelled(true);
            }
            if($mgr->isSpawnClaim($damager, $damager->getLevel())){
               $event->setCancelled(true);
            }
            if($mgr->isNetherSpawnClaim($damager, $damager->getLevel())){
               $event->setCancelled(true);
            }
            if($entity instanceof AlpinePlayer && $damager instanceof AlpinePlayer){
               if(!$event->isCancelled()){
                  $entity->setSpawntagTime(45);
                  $entity->setSpawnTagged(true);
                  $damager->setSpawnTagged(true);
                  $damager->setSpawntagTime(45);
                  if($entity->isTeleporting()){
                     $id = $entity->getTeleportTask()->getTaskId();
                     AlpineCore::getInstance()->getScheduler()->cancelTask($id);
                     $entity->setTeleporting(false);
                  }
               }
            }
        }
   }
}