<?php
declare(strict_types=1);
namespace hcf\events\listener;

use hcf\{
   AlpineCore, AlpinePlayer, manager\ShopManager
};
use pocketmine\tile\Sign;
use pocketmine\{
   item\Item, item\ItemFactory,
   block\BlockIds};
use pocketmine\math\Vector3;
use pocketmine\event\Listener;
use pocketmine\utils\TextFormat as C;
use pocketmine\event\block\SignChangeEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\block\BlockBreakEvent;

class ShopListener implements Listener {

   private $plugin;
   public function __construct(AlpineCore $plugin){
      $this->plugin = $plugin;
    }

   /** 
     * @param SignChangeEvent $event
     */
   public function onCreate(SignChangeEvent $event){
      $mgr = AlpineCore::getShopManager();
      $player = $event->getPlayer();
      $sign = $event->getBlock();
      if($event->getLine(0) == "buy"){
         if(!$player->hasPermission("shop.create")) return;
         if($event->getLine(1) == "" || $event->getLine(2) == "" || $event->getLine(3) == "") return;
         $line = $event->getLine(1);
         $item = ItemFactory::fromString($line);
         $mgr->createShop(ShopManager::BUY, $item->getId(), $item->getDamage(), intval($event->getLine(2)), intval($event->getLine(3)), $sign->asVector3());
         $event->setLine(0, "§r" . C::BOLD . C::GRAY . "[" . C::RED . "BUY" . C::GRAY . "]");
         $event->setLine(1, C::WHITE . $item->getName());
         $event->setLine(2, C::WHITE . "x" . intval($event->getLine(2)));
         $event->setLine(3, "§r§a$" . C::GRAY . intval($event->getLine(3)));
      }
      if($event->getLine(0) == "sell"){
         if(!$player->hasPermission("shop.create")) return;
         if($event->getLine(1) === "" || $event->getLine(2) === "" || $event->getLine(3) === "") return;
         $line = $event->getLine(1);
         $item = ItemFactory::fromString($line);
         $mgr->createShop(ShopManager::SELL, $item->getId(), $item->getDamage(), intval($event->getLine(2)), intval($event->getLine(3)), $sign->asVector3());
         $event->setLine(0, "§r" . C::BOLD . C::GRAY . "[" . C::GREEN . "SELL" . C::GRAY . "]");
         $event->setLine(1, C::WHITE . $item->getName());
         $event->setLine(2, C::WHITE . "x" . intval($event->getLine(2)));
         $event->setLine(3, "§r§a$" . C::GRAY . intval($event->getLine(3)));
      }
   }

   /**
     * @param BlockBreakEvent $event
     */
   public function onBreak(BlockBreakEvent $event){
      $mgr = AlpineCore::getShopManager();
      $vec = $event->getBlock()->asVector3();
      $player = $event->getPlayer();
      if($mgr->isShop($vec)){
         if(!$player->hasPermission("shop.destroy")) return;
         $mgr->moveShop($vec);
         $player->sendMessage("§r§aShop has been removed!");
      }
   }

   /**
     * @param PlayerInteractEvent $event
     */
   public function onTap(PlayerInteractEvent $event){
      $player = $event->getPlayer();
      $block = $event->getBlock();
      $vec = $block->asVector3();
      $mgr = AlpineCore::getShopManager();
      if($player instanceof AlpinePlayer){
         if($block->getId() == BlockIds::SIGN_POST || $block->getId() == BlockIds::WALL_SIGN){
            if($mgr->isShop($vec)){
               $id = $mgr->getId($vec);
               $dmg = $mgr->getDamage($vec);
               $a = $mgr->getAmount($vec);
               $price = (int) $mgr->getPrice($vec);
               $inv = $player->getInventory();
               $item = Item::get($id, $dmg, $a);

               switch($mgr->getType($vec)){
                  case ShopManager::SELL:
                     if($inv->contains($item)){
                        $player->addMoney($price);
                        $inv->removeItem($item);
                        $player->sendMessage("❌" . C::BOLD . C::GREEN . "»» " . C::GRAY . "You sold §ax" . $a . " " . $item->getName() . "§7 for §a$" . $price);
                     } else $player->sendMessage("" . "❌" . C::BOLD . C::RED . "»» " . C::GRAY . "You do not have this item to sell!");
                  break;

                  case ShopManager::BUY:
                     if($player->getBalance() >= $price){
                        $player->reduceMoney($price);
                        $inv->addItem($item);
                        $player->sendMessage("❌" . C::BOLD . C::GREEN . "»» " . C::GRAY . "You bought §ax" . $a . " " . $item->getName() . "§7 for §a$" . $price);
                     } else $player->sendMessage("" . "❌" . C::BOLD . C::RED . "»» " . C::GRAY . "You do not have enough money to buy this!");
                  break;
               }
            }
         }
      }
   }
}