<?php
declare(strict_types=1);
namespace hcf\events;

use hcf\{
   AlpineCore, AlpinePlayer
};
use pocketmine\event\Listener;
use pocketmine\math\Vector3;
use pocketmine\utils\TextFormat as TF;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\block\{
   BlockPlaceEvent, BlockBreakEvent
};
class Border implements Listener{

   private $plugin;
   /**
     * @param AlpineCore $plugin
     */
   public function __construct(AlpineCore $plugin){
      $this->plugin = $plugin;
   }

   /**
     * @param PlayerMoveEvent $event
     */
   public function onMove(PlayerMoveEvent $event){
      $server = $this->plugin->getServer();
      $level = $server->getDefaultLevel();
      $safe = $level->getSafeSpawn();
      $player = $event->getPlayer();
      $x = 4000;
      $z = 4000;
      $xp = $event->getPlayer()->getFloorX();
      $zp = $event->getPlayer()->getFloorZ();
      $xs = $safe->getFloorX() + $x;
      $zs = $safe->getFloorZ() + $z;
      $x1 = abs($xp);
      $z1 = abs($zp);
      $x2 = abs($xs);
      $z2 = abs($zs);
      if($x1 >= $x2){
         $player->sendPopup(TF::BOLD . TF::RED . "»»" . TF::RESET . TF::GRAY . " You have reached the world border!");
          $event->setCancelled();
      }
      if($z1 >= $z2){
         $player->sendPopup(TF::BOLD . TF::RED . "»»" . TF::RESET . TF::GRAY . " You have reached the world border!");
         $event->setCancelled();
      }
   }
   /**
     * @param BlockPlaceEvent $event
     */
   public function onPlace(BlockPlaceEvent $event){
      $server = $this->plugin->getServer();
      $level = $server->getDefaultLevel();
      $safe = $level->getSafeSpawn();
      $player = $event->getPlayer();
      $x = 4000;
      $z = 4000;
      $xp = $event->getBlock()->getFloorX();
      $zp = $event->getBlock()->getFloorZ();
      $xs = $safe->getFloorX() + $x;
      $zs = $safe->getFloorZ() + $z;
      $x1 = abs($xp);
      $z1 = abs($zp);
      $x2 = abs($xs);
      $z2 = abs($zs);
      if($x1 >= $x2){
         $player->sendPopup(TF::BOLD . TF::RED . "»»" . TF::RESET . TF::GRAY . " You cannot place blocks out of world border!");
          $event->setCancelled();
      }
      if($z1 >= $z2){
         $player->sendPopup(TF::BOLD . TF::RED . "»»" . TF::RESET . TF::GRAY . " You cannot place blocks out of world border!");
         $event->setCancelled();
      }
   }
   /**
     * @param BlockBreakEvent $event
     */
   public function onBreak(BlockBreakEvent $event){
      $server = $this->plugin->getServer();
      $level = $server->getDefaultLevel();
      $safe = $level->getSafeSpawn();
      $player = $event->getPlayer();
      $x = 4000;
      $z = 4000;
      $xp = $event->getBlock()->getFloorX();
      $zp = $event->getBlock()->getFloorZ();
      $xs = $safe->getFloorX() + $x;
      $zs = $safe->getFloorZ() + $z;
      $x1 = abs($xp);
      $z1 = abs($zp);
      $x2 = abs($xs);
      $z2 = abs($zs);
      if($x1 >= $x2){
         $player->sendPopup(TF::BOLD . TF::RED . "»»" . TF::RESET . TF::GRAY . " You cannot break blocks out of world border!");
          $event->setCancelled();
      }
      if($z1 >= $z2){
         $player->sendPopup(TF::BOLD . TF::RED . "»»" . TF::RESET . TF::GRAY . " You cannot break blocks out of world border!");
         $event->setCancelled();
      }
   }
}