<?php
declare(strict_types=1);
namespace hcf\events;

use hcf\{
   AlpineCore, AlpinePlayer, entity\KenzoBall
};
use pocketmine\{
   event\Listener, utils\TextFormat, item\Item
};
use pocketmine\entity\Entity;
use pocketmine\nbt\tag\{CompoundTag, ByteTag, ListTag};
use pocketmine\event\entity\ProjectileLaunchEvent;

class PartnerItems implements Listener{

   private $plugin;
   public function __construct(AlpineCore $plugin){
        $this->plugin = $plugin;
   }

   /** 
     * @param ProjectileLaunchEvent $event
     */
   public function onLaunch(ProjectileLaunchEvent $event){
       $entity = $event->getEntity();

       if($entity instanceof KenzoBall){
           $owner = $entity->getOwningEntity();
           if($owner instanceof AlpinePlayer){
               $cooldown = $owner->getPartnerItemCooldown("switchball");
               if(($cooldown - time()) <= 0){
                   $owner->setPartnerItemCooldown("switchball", 10);
               } else {
                   $item = Item::get(Item::SNOWBALL, 0, 2);
                   $item->setNamedTagEntry(new ListTag("ench"));
                   $item->setCustomName(TextFormat::BOLD . TextFormat::AQUA . "Swapper" . TextFormat::RESET. TextFormat::GRAY . " Ball");
                   $item->setLore([
                       TextFormat::GRAY . " Switch Positions with anyone that is",
                       TextFormat::GRAY . " hit by this ball. Great for trapping!",
                       "",
                       TextFormat::BOLD . TextFormat::RED . "WARNING:" . TextFormat::RESET . TextFormat::RED . " 10 Seconds Cooldown!"
                   ]);
                   $item->setCustomBlockData(new CompoundTag("", [new ByteTag("kenzoball", 1)]));
                   $owner->getInventory()->addItem($item);
                   $event->setCancelled(true);
                   $owner->sendMessage(TextFormat::BOLD . TextFormat::GREEN . "»» " . TextFormat::RESET . TextFormat::GRAY . "You are on cooldown for using this item! Time left: " . TextFormat::RED . ($cooldown - time()) . " seconds!");
               }
           }
       }
   }
}