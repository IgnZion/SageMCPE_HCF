<?php
declare(strict_types=1);

namespace hcf\items;

use hcf\{AlpineCore, AlpinePlayer};
use pocketmine\nbt\tag\ByteTag;

class Snowball extends \pocketmine\item\Snowball{

    public function getProjectileEntityType() : string {
        if(($nbt = $this->getCustomBlockData()) === null || !$nbt->hasTag("kenzoball", ByteTag::class)){
            return "Snowball";
        }
        return "KenzoBall";
    }
}
