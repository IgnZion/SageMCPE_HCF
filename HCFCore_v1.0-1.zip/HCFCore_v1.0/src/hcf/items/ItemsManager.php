<?php
declare(strict_types=1);
namespace hcf\items;

use pocketmine\item\{
   Item, ItemFactory,
   enchantment\Enchantment
};

class ItemsManager {
   public static function init() {
      //ItemFactory::registerItem(new FlintSteel(), true);
      ItemFactory::registerItem(new EnderPearl(), true);
      ItemFactory::registerItem(new Snowball(), true);
      Enchantment::registerEnchantment(new Enchantment(Enchantment::SMITE, "%enchantment.weapon.smite", Enchantment::RARITY_UNCOMMON, Enchantment::SLOT_SWORD, Enchantment::SLOT_NONE, 5));
      Enchantment::registerEnchantment(new Enchantment(Enchantment::LOOTING, "%enchantment.weapon.looting", Enchantment::RARITY_UNCOMMON, Enchantment::SLOT_SWORD, Enchantment::SLOT_NONE, 3));
      Enchantment::registerEnchantment(new Enchantment(Enchantment::FORTUNE, "%enchantment.mining.fortune", Enchantment::RARITY_UNCOMMON, Enchantment::SLOT_TOOL, Enchantment::SLOT_NONE, 3));
   }
}
