<?php
declare(strict_types=1);

namespace hcf\items;

use hcf\{AlpineCore, AlpinePlayer};
use pocketmine\Player;
use pocketmine\math\Vector3;
use pocketmine\item\{Item, ProjectileItem};

class EnderPearl extends ProjectileItem {

    /**
     * @param int $meta
     * @param int $count
     */
    public function __construct($meta = 0, $count = 1){
        parent::__construct(Item::ENDER_PEARL, $meta, "Ender Pearl");
    }

    /**
     * @param Player $player
     * @param Vector3 $directionVector
     * @return bool
     */
    public function onClickAir(Player $player, Vector3 $directionVector): bool {
        return true;
    }

    /**
     * @return string
     */
    public function getProjectileEntityType(): string {
        return "EnderPearl";
    }

    /**
     * @return float
     */
    public function getThrowForce(): float {
        return 1.25;
    }

    /**
     * @return int
     */
    public function getMaxStackSize(): int {
        return 16;
    }
}