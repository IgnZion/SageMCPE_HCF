<?php
declare(strict_types=1);

namespace hcf;

use mysqli;
use hcf\{
    events\timers\SOTW,
    utils\Utils,
    tasks\async\CheckClaimTask,
    tasks\async\LoadItTask, tasks\async\SaveItTask
};
use pocketmine\{
    Player, item\Item,
    Server,
    block\BlockIds,
    block\Block,
    math\Vector3
};
use pocketmine\event\Listener;
use pocketmine\utils\{
    TextFormat, Config
};
use pocketmine\entity\{
    Entity, Effect, EffectInstance
};
use pocketmine\network\{
    SourceInterface,
    mcpe\PlayerNetworkSessionAdapter};
use pocketmine\network\mcpe\protocol\{
    UpdateBlockPacket,
    RemoveObjectivePacket,
    SetDisplayObjectivePacket,
    SetScorePacket,
    types\ScorePacketEntry,
    ChangeDimensionPacket, PlayStatusPacket,
    types\DimensionIds
};
use pocketmine\nbt\tag\{
   StringTag, IntTag, CompoundTag, ListTag};

class AlpinePlayer extends Player
{
    const PUBLIC = 1;
    const FACTION = 2;
    const STAFF = 3;

    const FIRST = 1;
    const SECOND = 2;
    const CONFIRM = 3;

    const HOME = 1;
    const STUCK = 2;

    const N = "N";
    const NE = "NE";
    const SE = "SE";
    const S = "S";
    const E = "E";
    const W = "W";
    const NW = "NW";
    const SW = "SW";

    private $class = "";
    private $oldclass = "";
    private $region = "null";
    private $bardenergy = 0;
    private $barddelay = 0;
    private $archertagged = false;
    private $archertagtime = 0;
    private $spawntagged = false;
    private $spawntagtime = 0;
    private $line = [];
    private $chat = self::PUBLIC;
    private $claiming = false;
    private $pos1;
    private $pos2;
    private $step = self::FIRST;
    private $last;
    private $dimension;
    private $claim = [
        "cost" => 0,
        "claim" => false
    ];
    private $time = 60 * 30;
    private $pvp = [
        "enabled" => false,
        "timeleft" => 0
    ];
    private $invited = false;
    private $lastinvite;
    private $invitedtime = 0;
    private $teleporttask;
    private $teleporttype;
    private $isteleporting = false;
    private $disablemove;
    private $lasthit = "";
    private $clicks = [
        "time" => 0, "clicks" => 0
    ];
    private $staff = [
        "vanished" => false, "frozen" => false, "lockedplayer" => "", "viewing" => "", "punish" => 0, "alerts" => ""
    ];
    private $partneritems = [
        "switchball" => 0, "pearlcooldown" => 0, "remover" => 0, "portablebard" => 0, "ninjaability" => 0, "armorswapper" => 0,
        "invisibility" => 0, "switchstick" => 0, "bone" => 0, "bonedtime" => 0, "shortpearl" => 0, "fakepearl" => 0
    ];
    private $data = [
        "rank" => "Player", "money" => 0, "kills" => 0, "deaths" => 0, "pvpenabled" => 0, "deathbantime" => 0, "deathbanned" => "false", "zombielogger" => "false", "pvptime" => 0, "warnings" => 0, "cid" => "", "ips" => [], "skin" => "", "gapcooldown" => 0, "normalgapcooldown" => 0,
        "permissions" => [], "lives" => 0, "tags" => [], "reclaim" => 0, "elo" => 0, "staffmode" => 0, "inventory" => [], "helmet" => "", "chestplate" => "", "leggings" => "", "boots" => "", "banned" => 0, "bannedtimes" => 0, "banduration" => 0, "muted" => 0
    ];
    private $kits = ["starter" => 0, "bard" => 0, "miner" => 0, "rogue" => 0, "diamond" => 0, "archer" => 0, "master" => 0, "builder" => 0, "brewer" => 0];

    /**
     * @param SourceInterface $interface
     * @param string $ip
     * @param int $port
     */
    public function __construct(SourceInterface $interface, string $ip, int $port)
    {
        parent::__construct($interface, $ip, $port);
        $this->sessionAdapter = new PlayerNetworkSessionAdapter($this->server, $this);
    }

    /**
     * @return int {
     */
    public function getClicks(): int {
        $time = $this->clicks["time"];
        $clicks = $this->clicks["clicks"];
        if($time != time()){
            return 0;
        }
        return $clicks;
    }

    /**
     * @return void {
     */
    public function addClick(): void {
        $time = $this->clicks["time"];
        $clicks = $this->clicks["clicks"];
        if($time != time()){
            $time = time();
            $clicks = 0;
        }
        $clicks++;
        $this->clicks["time"] = $time;
        $this->clicks["clicks"] = $clicks;
    }

    public function setNameTagFaction($nametag, $players){
        $this->sendData($players, [Entity::DATA_NAMETAG => [Entity::DATA_TYPE_STRING, $nametag]]);
    }

    /**
    * @return string
    */
    public function getLastHit(): string {
        return $this->lasthit;
    }

    /**
    * @param string $name
    */
    public function setLastHit(string $name) {
        $this->lasthit = $name;
    }

    /**
    * @return string
    */
    public function getPunishee(): string {
        return (string) $this->staff["punish"];
    }

    /**
    * @param string $name
    */
    public function setPunishee(string $name) {
        $this->staff["punish"] = $name;
    }

    /**
    * @return bool
    */
    public function isFrozen(): bool {
        return (bool) $this->staff["frozen"];
    }

    /**
    * @param bool $bool
    */
    public function setFrozen(bool $bool) {
        $this->staff["frozen"] = $bool;
    }

    /**
    * @return bool
    */
    public function hasAlerts(): bool {
        return (bool) $this->staff["alerts"];
    }

    /**
    * @param bool $bool
    */
    public function setAlerts(bool $bool) {
        $this->staff["alerts"] = $bool;
    }

    /**
    * @return bool
    */
    public function isVanished(): bool {
        return (bool) $this->staff["vanished"];
    }

    /**
    * @param bool $bool
    */
    public function setVanished(bool $bool) {
        $this->staff["vanished"] = $bool;
    }

    /**
    * @return string
    */
    public function getLockedPlayer(): string {
        return (string) $this->staff["lockedplayer"];
    }

    /**
    * @param string $name
    */
    public function setLockedPlayer(string $name) {
        $this->staff["lockedplayer"] = $name;
    }

    /**
    * @return string
    */
    public function getViewing(): string {
        return (string) $this->staff["viewing"];
    }
    
    /**
    * @param string $name
    */
    public function setViewing(string $name){
        $this->staff["viewing"] = $name;
    }
    
    /**
    * @return bool
    */
    public function isStaffMode(): bool {
        return (bool) $this->data["staffmode"];
    }

    /**
     * @param int $dimension
     */
    public function sendDimensionPacket(int $dimension){
        if(!isset($this->dimension) && $dimension === DimensionIds::OVERWORLD || $this->dimension === $dimension){
            return;
        }
        $this->dimension = $dimension;
        if($this->dimension === DimensionIds::OVERWORLD) AlpineCore::getInstance()->getCratesManager()->spawnFloatingText($this);
        $pk = new ChangeDimensionPacket();
        $pk->dimension = $dimension;
        $pk->position = $this;
        $this->dataPacket($pk);
    }

    /**
    * @param bool $bool
    */
    public function setStaffMode(bool $bool) {
        $this->data["staffmode"] = $bool;
    }

    /**
    *
    */
    public function exitStaffMode() {
        $this->setFlying(false);
        $this->setAllowFlight(false);
        $this->getInventory()->clearAll();
        $this->getArmorInventory()->clearAll();
        $this->setGamemode(self::SURVIVAL);
        foreach($this->getInventoryItems() as $item){
            if($item instanceof Item){
                $this->getInventory()->addItem($item);
            }
        }
        $this->unsetInventoryItems();
        if($this->getArmorInventoryHelmet() instanceof Item) $this->getArmorInventory()->setHelmet($this->getArmorInventoryHelmet());
        if($this->getArmorInventoryChestplate() instanceof Item) $this->getArmorInventory()->setChestplate($this->getArmorInventoryChestplate());
        if($this->getArmorInventoryLeggings() instanceof Item) $this->getArmorInventory()->setLeggings($this->getArmorInventoryLeggings());
        if($this->getArmorInventoryBoots() instanceof Item) $this->getArmorInventory()->setBoots($this->getArmorInventoryBoots());
        if($this->isVanished()){
            $this->setVanished(false);
            if($this->isPvP()){
                $this->setNameTag(TextFormat::RESET . TextFormat::GREEN . "[PvPTimer] " . TextFormat::GRAY . $this->getName());
            } else {
                $this->setNameTag(TextFormat::RESET . TextFormat::GRAY . $this->getName());
            }
            foreach(AlpineCore::getInstance()->getServer()->getOnlinePlayers() as $players){
                $players->showPlayer($this);
            }
        }
        $this->setStaffMode(false);
    }

    /**
    *
    */
    public function enterStaffMode() {
        foreach($this->getInventory()->getContents() as $item){
            $this->setInventoryItems($item);
        }
        $this->setArmorInventoryHelmet($this->getArmorInventory()->getHelmet());
        $this->setArmorInventoryChestplate($this->getArmorInventory()->getChestplate());
        $this->setArmorInventoryLeggings($this->getArmorInventory()->getLeggings());
        $this->setArmorInventoryBoots($this->getArmorInventory()->getBoots());
        $this->getInventory()->clearAll();
        $this->getArmorInventory()->clearAll();
        $this->setGamemode(self::SURVIVAL);
        $freeze = Item::get(Item::FROSTED_ICE, 0, 1);
        $freeze->setCustomName(TextFormat::RESET . TextFormat::DARK_AQUA . "Freeze Player");
        $freezetag = $freeze->getNamedTag();
        $freezetag->setString("staffitem", "freeze");
        $freeze->setNamedTag($freezetag);
        $freeze->setNamedTagEntry(new ListTag("ench"));

        $randomtp = Item::get(Item::COMPASS, 0, 1);
        $randomtp->setCustomName(TextFormat::RESET . TextFormat::AQUA . "Random Teleport");
        $randomtptag = $randomtp->getNamedTag();
        $randomtptag->setString("staffitem", "randomteleport");
        $randomtp->setNamedTag($randomtptag);
        $randomtp->setNamedTagEntry(new ListTag("ench"));

        $vanish = Item::get(Item::DYE, 10, 1);
        $vanish->setCustomName(TextFormat::RESET . TextFormat::DARK_GREEN . "Vanish");
        $vanishtag = $vanish->getNamedTag();
        $vanishtag->setString("staffitem", "vanish");
        $vanish->setNamedTag($vanishtag);
        $vanish->setNamedTagEntry(new ListTag("ench"));

        $phase = Item::get(Item::STICK, 0, 1);
        $phase->setCustomName(TextFormat::RESET . TextFormat::DARK_PURPLE . "Wall Phase");
        $phasetag = $phase->getNamedTag();
        $phasetag->setString("staffitem", "phase");
        $phase->setNamedTag($phasetag);
        $phase->setNamedTagEntry(new ListTag("ench"));

        $invbook = Item::get(Item::BOOK, 0, 1);
        $invbook->setCustomName(TextFormat::RESET . TextFormat::DARK_RED . "See Player Inventory");
        $invtag = $invbook->getNamedTag();
        $invtag->setString("staffitem", "seeinventory");
        $invbook->setNamedTag($invtag);
        $invbook->setNamedTagEntry(new ListTag("ench"));

        $lock = Item::get(Item::CLOCK, 0, 1);
        $lock->setCustomName(TextFormat::RESET . TextFormat::LIGHT_PURPLE . "Lock Teleport");
        $locktag = $lock->getNamedTag();
        $locktag->setString("staffitem", "lockteleport");
        $lock->setNamedTag($locktag);
        $lock->setNamedTagEntry(new ListTag("ench"));

        $this->getInventory()->setItem(0, $freeze);
        $this->getInventory()->setItem(2, $randomtp);
        $this->getInventory()->setItem(4, $vanish);
        $this->getInventory()->setItem(6, $phase);
        //$this->getInventory()->setItem(7, $invbook);
        $this->getInventory()->setItem(8, $lock);
        $this->setFlying(true);
        $this->setAllowFlight(true);
        $this->setStaffMode(true);
    }

    /**
    *
    */
     public function setInventoryItems($item){
         $this->data["inventory"][] = $item;
    }

    /**
    *
    */
    public function unsetInventoryItems(){
        $this->data["inventory"] = [];
    }

    /**
    * @return array
    */
    public function getInventoryItems(): array {
        return (array) $this->data["inventory"];
    }

    /**
    *
    */
     public function setArmorInventoryHelmet($item){
         $this->data["helmet"] = $item;
    }

    /**
    *
    */
    public function getArmorInventoryHelmet(){
        return $this->data["helmet"];
    }

    /**
    *
    */
     public function setArmorInventoryChestplate($item){
         $this->data["chestplate"] = $item;
    }

    /**
    *
    */
    public function getArmorInventoryChestplate(){
        return $this->data["chestplate"];
    }

    /**
    *
    */
     public function setArmorInventoryLeggings($item){
         $this->data["leggings"] = $item;
    }

    /**
    *
    */
    public function getArmorInventoryLeggings(){
        return $this->data["leggings"];
    }

    /**
    *
    */
     public function setArmorInventoryBoots($item){
         $this->data["boots"] = $item;
    }

    /**
    *
    */
    public function getArmorInventoryBoots(){
        return $this->data["boots"];
    }

    /**
     * @param bool $bool
     */
    public function setPlayerBanned(bool $bool){
        $this->data["banned"] = $bool;
    }

    /**
     * @return bool
     */
    public function isPlayerBanned(): bool {
        return (bool) $this->data["banned"];
    }

    /**
     * @param int $time
     */
    public function setMutedTime(int $time){
        $this->data["muted"] = $time;
    }

    /**
     * @return int
     */
    public function getMutedTime(): int {
        return (int) $this->data["muted"];
    }

    /**
     * @param int $time
     */
    public function setPlayerBanTime(int $time){
        $this->data["banduration"] = $time;
    }

    /**
     * @return int
     */
    public function getPlayerBanTime(): int {
        return (int) $this->data["banduration"];
    }

    /**
     * @param int $times
     */
    public function setTotalBannedTimes(int $times){
        $this->data["bannedtimes"] = $times;
    }

    /**
     * @return int
     */
    public function getTotalBannedTimes(): int {
        return (int) $this->data["bannedtimes"];
    }

    /**
     * @param int $warnings
     */
    public function setWarnings(int $warnings){
        $this->data["warnings"] = $warnings;
    }

    /**
     * @return int
     */
    public function getWarnings(): int {
        return (int) $this->data["warnings"];
    }

    /**
     * @param string $cid
     */
    public function setFirstCID(string $cid){
        $this->data["cid"] = $cid;
    }

    /**
     * @return string
     */
    public function getFirstCID(): string {
        return (string) $this->data["cid"];
    }

    /**
     * @param string $data
     */
    public function setPlayerSkinData(string $data){
        $this->data["skin"] = $data;
    }

    /**
     * @return string
     */
    public function getPlayerSkinData(): string {
        return (string) $this->data["skin"];
    }

    /**
     * @param string $ip
     */
    public function setAlpinePlayerIP($ip){
        $this->data["ips"][] = $ip;
    }

    /**
     * @param string $ip
     */
    public function removeAlpinePlayerIP($ip) {
        if($this->data["ips"][$ip] !== null){
            unset($this->data["ips"][$ip]);
        }
    }

    /**
     * @return array
     */
    public function getPlayerIPs(): array {
        return (array) $this->data["ips"];
    }

    /**
      * @param string $partneritem
      * @param int $cooldown
      */
    public function setPartnerItemCooldown(string $partneritem, int $cooldown)
    {
       $time = time() + $cooldown;
       $this->partneritems[$partneritem] = $time;
    }

    /**
      * @param string $partneritem
      * @return int
      */
    public function getPartnerItemCooldown(string $partneritem): int
    {
       return $this->partneritems[$partneritem];
    }

    /**
     * @param int $cooldown
     */
    public function setGappleCooldown(int $cooldown)
    {
        $this->data["gapcooldown"] = $cooldown;
    }

    /**
     * @return int
     */
    public function getGappleCooldown(): int
    {
        return (int) $this->data["gapcooldown"];
    }

    /**
     * @param int $cooldown
     */
    public function setNormalGappleCooldown(int $cooldown)
    {
        $time = time() + $cooldown;
        $this->data["normalgapcooldown"] = $time;
    }

    /**
     * @return int
     */
    public function getNormalGappleCooldown(): int
    {
        return (int) $this->data["normalgapcooldown"];
    }

    /**
     * @param int $total
     */
    public function setElo(int $total)
    {
        $this->data["elo"] = $total;
    }

    /**
     * @return int
     */
    public function getElo(): int
    {
        return (int) $this->data["elo"];
    }

    /**
     * @param int $time
     */
    public function disableMovement(int $time)
    {
        $this->disablemove = $time;
    }

    /**
     * @return bool
     */
    public function isMovementDisabled(): bool
    {
        return (time() - $this->disablemove) < 0;
    }

    /**
     * @return bool
     */
    public function isTeleporting(): bool
    {
        return $this->isteleporting;
    }

    /**
     * @param bool $tp
     */
    public function setTeleporting(bool $tp)
    {
        $this->isteleporting = $tp;
    }

    /**
     * @return int
     */
    public function getTeleport(): int
    {
        return $this->teleporttype;
    }

    /**
     * @param int $tp
     */
    public function setTeleport(int $tp)
    {
        $this->teleporttype = $tp;
    }

    /**
     *
     */
    public function getTeleportTask()
    {
        return $this->teleporttask;
    }

    /**
     * @param $task
     */
    public function setTeleportTask($task)
    {
        $this->teleporttask = $task;
    }

    /**
     * @return int
     */
    public function getTeleportTime(): int
    {
        return $this->teleporttask->getTime();
    }

    /**
     * @return string
     */
    public function getLastInvite(): string
    {
        return $this->lastinvite;
    }

    /**
     * @bool string $fac
     */
    public function setLastInvite(string $fac)
    {
        $this->lastinvite = $fac;
    }

    /**
     * @return bool
     */
    public function isInvited(): bool
    {
        return $this->invited;
    }

    /**
     * @param bool $bool
     */
    public function setInvited(bool $bool)
    {
        $this->invited = $bool;
    }

    /**
     * @param int $time
     */
    public function setInvitedTime(int $time)
    {
        $this->invitedtime = time() + $time;
    }

    /**
     * @return int
     */
    public function getInvitedTimeLeft(): int
    {
        $time = (int)$this->invitedtime;
        return $time - time();
    }

    public function resetPvPTimer()
    {
        $this->pvp["enabled"] = (bool) 1; //true
        $this->pvp["timeleft"] = $this->time;
        $this->setNameTag(TextFormat::RESET . TextFormat::GREEN . "[PvPTimer] " . TextFormat::GRAY . $this->getName());
    }

    public function unsetPvPTimer()
    {
        $this->pvp["enabled"] = (bool) 0; //false
        $this->pvp["timeleft"] = 0;
        $this->setNameTag(TextFormat::RESET . TextFormat::GRAY . $this->getName());
    }

    /**
     * @return int
     */
    public function getPvPTimer(): int
    {
        return $this->pvp["timeleft"];
    }

    /**
     * @param int $time
     */
    public function setPvPTimer(int $time)
    {
        $this->pvp["timeleft"] = $time;
    }

    /**
     * @param bool $bool
     */
    public function setPvP(bool $bool)
    {
        $this->pvp["enabled"] = (bool) $bool;
    }

    /**
     * @return bool
     */
    public function isPvP(): bool
    {
        return (bool)$this->pvp["enabled"];
    }

    /**
     * @param bool $bool
     */
    public function setReclaim(bool $bool)
    {
        $this->data["reclaim"] = (bool) $bool;
    }

    /**
     * @return bool
     */
    public function usedReclaim(): bool
    {
        return (bool) $this->data["reclaim"];
    }

    /**
     * @param string $kit
     * @param int $time
     */
    public function setKitCooldown(string $kit, int $time)
    {
        $kit = strtolower($kit);
        $this->kits[$kit] = $time;
    }

    /**
     * @param string $kit
     */
    public function unsetKitCooldown(string $kit)
    {
        $kit = strtolower($kit);
        $this->kits[$kit] = 0;
    }

    /**
     * @param string $kit
     * @return int
     */
    public function getKitCooldown(string $kit): int
    {
        $kitname = strtolower($kit);
        return (int) $this->kits[$kitname];
    }

    /**
     * @param string $kit
     * @return int
     */
    public function getKitCooldownLeft(string $kit): int
    {
        if (($this->getKitCooldown($kit) - time()) <= 0) return 0;
        return (int) $this->getKitCooldown($kit) - time();
    }

    /**
     *
     */
    public function loadIt()
    {
        $database = AlpineCore::getInstance()->getPlayerDatabase();
        $async = AlpineCore::getInstance()->getServer()->getAsyncPool();
        $async->submitTask(new LoadItTask($database, $this->getName()));
    }

    /**
     *
     */
    public function saveIt()
    {
        // $database = AlpineCore::getInstance()->getPlayerDatabase();
        $async = AlpineCore::getInstance()->getServer()->getAsyncPool();
        $async->submitTask(new SaveItTask($this->data, $this->kits, $this->pvp, $this->getName()));
    }

    /**
     * @return int
     */
    public function getKills(): int
    {
        return $this->data["kills"];
    }

    /**
     * @return int
     */
    public function getDeaths(): int
    {
        return (int) $this->data["deaths"];
    }
    
    /**
     * @return string
     */
    public function getRank(): string
    {
        return (string) $this->data["rank"];
    }
    
    /**
     * @param string $rank
     */
     public function setRank(string $rank)
     {
         $name = $this->getName();
         $perms =  AlpineCore::getInstance()->getRankPermissions();
         $old = strtolower($this->getRank());
         $oldperms = $perms->get($old);
         $new = strtolower($rank);
         $newperms = $perms->get($new);
         foreach($newperms as $newperm){
             $this->addPermission($newperm);
         }
         foreach($oldperms as $oldperm){
             $this->removePermission($oldperm);
         }
         $this->data["rank"] = $rank;
     }

     /**
       * @param string $permission
       */
     public function addPermission($permission){
        if($this->hasPermission($permission)){
           return;
        } else {
           $this->addAttachment(AlpineCore::getInstance(), $permission, true);
           $this->data["permissions"][] = $permission;
        }
     }

     /**
       * @param string $permission
       */
     public function removePermission($permission){
        if($this->hasPermission($permission)){
           $this->addAttachment(AlpineCore::getInstance(), $permission, false);
           unset($this->data["permissions"][$permission]);
        } else {
           return;
        }
     }
        
    /**
     * @return int
     */
    public function getBalance(): int
    {
        return (int) $this->data["money"];
    }

    /**
     * @param int $amount
     */
    public function addKill(int $amount)
    {
        $kills = $this->getKills() + $amount;
        $this->data["kills"] = $kills;
    }

    /**
     * @param int $amount
     */
    public function addDeath(int $amount)
    {
        $deaths = $this->getDeaths() + $amount;
        $this->data["deaths"] = $deaths;
    }

    /**
     * @param int $amount
     */
    public function addMoney(int $amount)
    {
        $bal = $this->getBalance() + $amount;
        $this->setMoney($bal);
    }

    /**
     * @param int $amount
     */
    public function setMoney(int $amount)
    {
        $this->data["money"] = $amount;
    }

    /**
     * @param int $amount
     */
    public function reduceMoney(int $amount)
    {
        $bal = $this->getBalance() - $amount;
        $this->setMoney($bal);
    }

    /**
     *
     */
    public function checkClaim()
    {
        $dir = AlpineCore::getInstance()->getDataFolder() . "FactionsData.db";
        $pos1 = $this->getPos1();
        $pos2 = $this->getPos2();
        $x1 = min($pos1->getX(), $pos2->getX());
        $z1 = min($pos1->getZ(), $pos2->getZ());
        $x2 = max($pos1->getX(), $pos2->getX());
        $z2 = max($pos1->getZ(), $pos2->getZ());
        $async = AlpineCore::getInstance()->getServer()->getAsyncPool();
        $async->submitTask(new CheckClaimTask($x1, $z1, $x2, $z2, $dir, $this->getName()));
    }

    /**
     *
     */
    public function checkSets()
    {
        $this->updateScoreboard();
        if ($this->getClass() !== $this->getOldClass()) {
            $this->removeAllEffects();
            $this->setBardEnergy(0);
        }
        if ($this->isBard()) {
            $this->setClass("Bard");
            if (!$this->hasEffect(Effect::SPEED)) $this->addEffect(new EffectInstance(Effect::getEffect(Effect::SPEED), 9999 * 20, 1));
            if (!$this->hasEffect(Effect::REGENERATION)) $this->addEffect(new EffectInstance(Effect::getEffect(Effect::REGENERATION), 99999 * 20, 0));
            if (!$this->hasEffect(Effect::RESISTANCE)) $this->addEffect(new EffectInstance(Effect::getEffect(Effect::RESISTANCE), 99999 * 20, 0));
            if (!$this->hasEffect(Effect::FIRE_RESISTANCE)) $this->addEffect(new EffectInstance(Effect::getEffect(Effect::FIRE_RESISTANCE), 99999 * 20, 1));
        } elseif ($this->isMiner()) {
            $this->setClass("Miner");
            if (!$this->hasEffect(Effect::HASTE)) $this->addEffect(new EffectInstance(Effect::getEffect(Effect::HASTE), 99999 * 20, 1));
            if (!$this->hasEffect(Effect::NIGHT_VISION)) $this->addEffect(new EffectInstance(Effect::getEffect(Effect::NIGHT_VISION), 99999 * 20, 3));
            if (!$this->hasEffect(Effect::FIRE_RESISTANCE)) $this->addEffect(new EffectInstance(Effect::getEffect(Effect::FIRE_RESISTANCE), 99999 * 20, 1));
            if ($this->getY() < 30) {
                if (!$this->hasEffect(Effect::INVISIBILITY)) $this->addEffect(new EffectInstance(Effect::getEffect(Effect::INVISIBILITY), 5 * 20, 1));
            }
        } elseif ($this->isArcher()) {
            $this->setClass("Archer");
            if (!$this->hasEffect(Effect::SPEED)) $this->addEffect(new EffectInstance(Effect::getEffect(Effect::SPEED), 99999 * 20, 2));
            if (!$this->hasEffect(Effect::REGENERATION)) $this->addEffect(new EffectInstance(Effect::getEffect(Effect::REGENERATION), 99999 * 20, 0));
            if (!$this->hasEffect(Effect::RESISTANCE)) $this->addEffect(new EffectInstance(Effect::getEffect(Effect::RESISTANCE), 99999 * 20, 1));
        } elseif ($this->isRogue()) {
            $this->setClass("Rogue");
            if (!$this->hasEffect(Effect::SPEED)) $this->addEffect(new EffectInstance(Effect::getEffect(Effect::SPEED), 99999 * 20, 2));
            if (!$this->hasEffect(Effect::NIGHT_VISION)) $this->addEffect(new EffectInstance(Effect::getEffect(Effect::NIGHT_VISION), 99999 * 20, 0));
            if (!$this->hasEffect(Effect::RESISTANCE)) $this->addEffect(new EffectInstance(Effect::getEffect(Effect::RESISTANCE), 99999 * 20, 0));
            if (!$this->hasEffect(Effect::WATER_BREATHING)) $this->addEffect(new EffectInstance(Effect::getEffect(Effect::WATER_BREATHING), 99999 * 20, 2));
            if (!$this->hasEffect(Effect::FIRE_RESISTANCE)) $this->addEffect(new EffectInstance(Effect::getEffect(Effect::FIRE_RESISTANCE), 99999 * 20, 0));
        } elseif ($this->isMaster()) {
            $this->setClass("Master");
            if (!$this->hasEffect(Effect::SPEED)) $this->addEffect(new EffectInstance(Effect::getEffect(Effect::SPEED), 99999 * 20, 1));
            if (!$this->hasEffect(Effect::FIRE_RESISTANCE)) $this->addEffect(new EffectInstance(Effect::getEffect(Effect::FIRE_RESISTANCE), 99999 * 20, 0));
        } else {
            $this->setClass("Normal");
        }
    }

    /**
     * @return bool
     */
    public function isBard(): bool
    {
        $inv = $this->getArmorInventory();
        $helmet = $inv->getHelmet()->getId();
        $chest = $inv->getChestplate()->getId();
        $legg = $inv->getLeggings()->getId();
        $boots = $inv->getBoots()->getId();
        return ($helmet == 314 && $chest == 315 && $legg == 316 && $boots == 317);
    }

    /**
     * @return bool
     */
    public function isMaster(): bool
    {
        $inv = $this->getArmorInventory();
        $helmet = $inv->getHelmet()->getNamedTag();
        $chest = $inv->getChestplate()->getNamedTag();
        $legg = $inv->getLeggings()->getNamedTag();
        $boots = $inv->getBoots()->getNamedTag();
        return ($helmet->hasTag("master", IntTag::class) && $chest->hasTag("master", IntTag::class) && $legg->hasTag("master", IntTag::class) && $boots->hasTag("master", IntTag::class));
    }

    /**
     * @return bool
     */
    public function isRogue(): bool
    {
        $inv = $this->getArmorInventory();
        $helmet = $inv->getHelmet()->getId();
        $chest = $inv->getChestplate()->getId();
        $legg = $inv->getLeggings()->getId();
        $boots = $inv->getBoots()->getId();
        return ($helmet == 302 && $chest == 303 && $legg == 304 && $boots == 305);
    }

    /**
     * @return bool
     */
    public function isMiner(): bool
    {
        $inv = $this->getArmorInventory();
        $helmet = $inv->getHelmet()->getId();
        $chest = $inv->getChestplate()->getId();
        $legg = $inv->getLeggings()->getId();
        $boots = $inv->getBoots()->getId();
        return ($helmet == 306 && $chest == 307 && $legg == 308 && $boots == 309);
    }

    /**
     * @return bool
     */
    public function isArcher(): bool
    {
        $inv = $this->getArmorInventory();
        $helmet = $inv->getHelmet()->getId();
        $chest = $inv->getChestplate()->getId();
        $legg = $inv->getLeggings()->getId();
        $boots = $inv->getBoots()->getId();
        return ($helmet == 298 && $chest == 299 && $legg == 300 && $boots == 301);
    }

    /**
     * @return string
     */
    public function getClass(): string
    {
        return $this->class;
    }

    /**
     * @param string $class
     */
    public function setClass(string $class)
    {
        $this->setOldClass($this->getClass());
        $this->class = $class;
    }

    /**
     * @return string
     */
    public function getOldClass(): string
    {
        return $this->oldclass;
    }

    /**
     * @param string $old
     */
    public function setOldClass(string $old)
    {
        $this->oldclass = $old;
    }

    /**
     * @return int
     */
    public function getBardEnergy(): int
    {
        return $this->bardenergy;
    }

    /**
     * @param int @energy;
     */
    public function setBardEnergy(int $energy)
    {
        $this->bardenergy = $energy;
    }

    /**
     * @return int
     */
    public function getBardDelay(): int
    {
        return $this->barddelay;
    }

    /**
     * @param int $delay
     */
    public function setBardDelay(int $delay)
    {
        $this->barddelay = $delay;
    }

    /**
     * @return bool
     */
    public function isArcherTagged(): bool
    {
        return $this->archertagged;
    }

    /**
     * @param bool $tagged
     */
    public function setArcherTagged(bool $tagged)
    {
        $this->archertagged = $tagged;
    }

    /**
     * @param int $time
     */
    public function setArchertagTime(int $time)
    {
        $this->archertagtime = $time;
    }

    /**
     * @return int
     */
    public function getArchertagTime(): int
    {
        return $this->archertagtime;
    }

    /**
     * @return bool
     */
    public function isSpawnTagged(): bool
    {
        return $this->spawntagged;
    }

    /**
     * @param bool $tagged
     */
    public function setSpawnTagged(bool $tagged)
    {
        $this->spawntagged = $tagged;
    }

    /**
     * @param int $time
     */
    public function setSpawntagTime(int $time)
    {
        $this->spawntagtime = $time;
    }

    /**
     * @return int
     */
    public function getSpawntagTime(): int
    {
        return $this->spawntagtime;
    }

    /**
     * @return string
     */
    public function getFaction(): string
    {
        $name = $this->getName();
        $result = AlpineCore::getFactionsManager()->getDb()->query("SELECT * FROM players WHERE name = '$name';");
        $array = $result->fetchArray(SQLITE3_ASSOC);
        return $array["faction"];
    }

    /**
     * @param string $faction
     * @param int $rank
     */
    public function addToFaction(string $faction, int $rank = FactionsManager::MEMBER)
    {
        $name = $this->getName();
        $man = AlpineCore::getFactionsManager();
        $man->getDb()->exec("INSERT OR REPLACE INTO players(name, rank, faction) VALUES ('$name', " . $rank . ", '$faction');");
    }

    /**
     *
     */
    public function removeFromFaction()
    {
        $name = $this->getName();
        $man = AlpineCore::getFactionsManager();
        $man->getDb()->exec("DELETE FROM players WHERE name = '$name';");
    }

    /**
     * @return $bool
     */
    public function isInFaction(): bool
    {
        $name = $this->getName();
        $result = AlpineCore::getFactionsManager()->getDb()->query("SELECT * FROM players WHERE name = '$name';");
        $array = $result->fetchArray(SQLITE3_ASSOC);
        return empty($array) == false;
    }

    /**
     * @param Vector3 $pos
     * @param int $id
     * @param int $data
     */
    public function setFakeBlock(Vector3 $pos, int $id, int $data = 0)
    {
        $block = Block::get($id);
        $block->x = (int)$pos->getX();
        $block->y = (int)$pos->getY();
        $block->z = (int)$pos->getZ();
        $block->level = $this->getLevel();
        $this->getLevel()->sendBlocks([$this], [$block]);
    }

    /**
     * @return int
     */
    public function getRandWallBlock(): int
    {
        switch (mt_rand(1, 3)) {
            case 1:
            case 2:
                return BlockIds::GLASS;
                break;
            case 3:
                return BlockIds::EMERALD_BLOCK;
                break;
        }
        return BlockIds::GLASS;
    }

    /**
     * @param int $x
     * @param int $y
     * @param int $z
     */
    public function buildWall(int $x, int $y, int $z)
    {
        for ($i = $y; $i < $y + 20; $i++) {
            $this->setFakeBlock(new Vector3($x, $i, $z), $this->getRandWallBlock());
        }
    }
    
    /**
     * @param int $x
     * @param int $y
     * @param int $z
     */
    public function removeWall(int $x, int $y, int $z)
    {
        for ($i = $y; $i < $y + 20; $i++) {
            $this->setFakeBlock(new Vector3($x, $i, $z), BlockIds::AIR);
        }
    }
    
    /**
     * @param bool $claim
     */
    public function setClaim(bool $claim)
    {
        $this->claim["claim"] = $claim;
    }

    /**
     * @return bool
     */
    public function getClaim(): bool
    {
        return $this->claim["claim"];

    }

    /**
     * @return int
     */
    public function getClaimCost(): int
    {
        return $this->claim["cost"];
    }

    /**
     * @param int $cost
     */
    public function setClaimCost(int $cost)
    {
        $this->claim["cost"] = $cost;
    }

    /**
     * @return string
     */
    public function getRegion(): string
    {
        return $this->region;
    }

    /**
     * @param string $region
     */
    public function setRegion(string $region)
    {
        $this->region = $region;
    }

    /**
     * @return int
     */
    public function getChat(): int
    {
        return $this->chat;
    }

    /**
     * @param int $chat
     */
    public function setChat(int $chat)
    {
        $this->chat = $chat;
    }

    /**
     * @return bool
     */
    public function isInClaim(): bool
    {
        $x = $this->getX();
        $z = $this->getZ();
        $db = AlpineCore::getFactionsManager()->getDb();
        $result = $db->query("SELECT * FROM claims WHERE $x <= x1 AND $x >= x2 AND $z <= z1 AND $z >= z2;");
        $array = $result->fetchArray(SQLITE3_ASSOC);
        if($this->getLevel() != AlpineCore::$overworldLevel) return false;
        return empty($array) == false;
    }

    /**
     * @return Vector3
     */
    public function getPos2(): Vector3
    {

        return $this->pos2;
    }

    /**
     * @param Vector3 $pos2
     */
    public function setPos2(Vector3 $pos2)
    {
        $this->pos2 = $pos2;
    }

    /**
     * @return Vector3
     */
    public function getPos1(): Vector3
    {
        return $this->pos1;
    }

    /**
     * @param Vector3 $pos1
     */
    public function setPos1(Vector3 $pos1)
    {
        $this->pos1 = $pos1;
    }

    /**
     * @return bool
     */
    public function isClaiming(): bool
    {
        return $this->claiming;
    }

    /**
     * @param bool $claiming
     */
    public function setClaiming(bool $claiming)
    {
        $this->claiming = $claiming;
    }

    /**
     * @return int
     */
    public function getStep(): int
    {
        return $this->step;
    }

    /**
     * @param int $step
     */
    public function setStep(int $step)
    {
        $this->step = $step;
    }
    
    /**
    * @param int $time
    */
    public function setDeathBanTime(int $time){
        $this->data["deathbantime"] = $time;
    }
    
    /**
    * @return int
    */
    public function getDeathBanTime(): int{
        return (int) $this->data["deathbantime"];
    }
    
    /**
    * @return string
    */
    public function isDeathBanned(): string {
        return $this->data["deathbanned"];
        
    }

    /**
    * @param string $bool
    */
    public function setDeathBanned(string $bool) {
        $this->data["deathbanned"] = $bool;
    }

    /**
    * @return string
    */
    public function isZombieLogger(): string {
        return $this->data["zombielogger"];
        
    }

    /**
    * @param string $bool
    */
    public function setZombieLogger(string $bool) {
        $this->data["zombielogger"] = $bool;
    }

    /**
    * @param int $lives
    */
    public function setLives(int $lives){
        $this->data["lives"] = $lives;
    }
    
    /**
    * @return int
    */
    public function getLives(): int{
        return (int) $this->data["lives"];
    }

    /**
     * @return string
     */
    public function getCurrentRegion(): string
    {
        $mgr = AlpineCore::getFactionsManager();
        if ($mgr->isSpawnClaim($this, $this->getLevel())) {
            return "Spawn";
        } elseif ($mgr->isRoad($this, $this->getLevel())) {
            return $mgr->getRoad($this, $this->getLevel());
        } elseif ($mgr->isClaim($this, $this->getLevel())) {
            return $mgr->getClaimer((int)$this->getX(), (int)$this->getZ());
        } else {
            return "Wilderness";
        }
    }

    /**
     * @return void
     */
    public function showScoreboard(): void
    {
        $pk = new SetDisplayObjectivePacket();
        $pk->displaySlot = "sidebar";
        $pk->objectiveName = $this->getName();
        $pk->displayName = "§d§lHCF |" . "§r§7  §f Realm #1";
        $pk->criteriaName = "dummy";
        $pk->sortOrder = 0;
        $this->sendDataPacket($pk);
    }

    /**
     * @param string $line
     */
    public function addLine(string $line)
    {
        $score = count($this->line) + 1;
        $this->setLine($score, $line);
    }

    /**
     *
     */
    public function clearLines()
    {
        for ($line = 0; $line <= 15; $line++) {
            $this->removeLine($line);
        }
    }

    /**
     * @return void
     */
    public function updateScoreboard(): void
    {
        if($this->isStaffMode()){
            $this->clearLines();
            $this->addLine("§r§7--------------------§r");
            if($this->getChat() == self::STAFF) $this->addLine(TextFormat::RESET . TextFormat::GRAY . "StaffChat: " . TextFormat::GREEN . "ON");
            if($this->getChat() != self::STAFF) $this->addLine(TextFormat::RESET . TextFormat::GRAY . "StaffChat: " . TextFormat::DARK_RED . "OFF");
            if($this->isVanished()) $this->addLine(TextFormat::RESET . TextFormat::GRAY . "Vanished: " . TextFormat::GREEN . "ON");
            if(!$this->isVanished()) $this->addLine(TextFormat::RESET . TextFormat::GRAY . "Vanished: " . TextFormat::DARK_RED . "OFF");
        } else {
            $this->clearLines();
            $this->addLine("§r§7--------------------§r");
            if ($this->isPvP()){
                if ($this->getPvPTimer() > 0) {
                    $this->addLine(TextFormat::GREEN . "§lInvincibility: §r§7" . Utils::intToString($this->getPvPTimer()));
                } else {
                    $this->unsetPvPTimer();
                }
            }
            if(($this->getNormalGappleCooldown() - time()) >= 1) $this->addLine("§l§aGap Cooldown: §r§7" . Utils::intToFullString($this->getNormalGappleCooldown() - time()));
            if(($this->getGappleCooldown() - time()) >= 1) $this->addLine("§l§aEGap Cooldown: §r§7" . Utils::intToFullString($this->getGappleCooldown() - time()));
            if(($this->getPartnerItemCooldown("pearlcooldown") - time()) >= 1) $this->addLine("§l§aEnderpearl: §r§7" . Utils::intToFullString($this->getPartnerItemCooldown("pearlcooldown") - time()));
            if (SOTW::getEnabled() == true) {
                if (SOTW::getTimeLeft() > 0) {
                    $this->addLine("§l§aSOTW: §r§7" . Utils::intToFullString(SOTW::getTimeLeft()));
                } else {
                    SOTW::stopTimer();
                }
            }
            if ($this->isBard()) $this->addLine("§c§lBardEnergy: §r§7" . $this->getBardEnergy());
            if ($this->getBardDelay() != 0) $this->addLine("§c§lBardDelay: §r§7" . $this->getBardDelay());
            if ($this->getArchertagTime() != 0) $this->addLine(TextFormat::YELLOW . "§lArcherTag: §r§7" . Utils::IntToString($this->getArchertagTime()));
            if ($this->getSpawntagTime() != 0) $this->addLine(TextFormat::RED . "§lSpawnTag§r§7: " . TextFormat::RED . Utils::IntToString($this->getSpawntagTime()));
            if ($this->isTeleporting()) {
                if ($this->getTeleport() == self::HOME) {
                    $this->addLine(TextFormat::BOLD . TextFormat::YELLOW . "Home: §r§7" . Utils::intToString($this->getTeleportTime()));
                } elseif ($this->getTeleport() == self::STUCK) {
                    $this->addLine(TextFormat::BOLD . TextFormat::YELLOW . "Stuck: §r§7" . Utils::intToString($this->getTeleportTime()));
                }
            }
        }
    }

    /**
     * @param int $loc
     * @param string $msg
     * @return void
     */
    public function setLine(int $loc, string $msg): void
    {
        $pk = new ScorePacketEntry();
        $pk->objectiveName = $this->getName();
        $pk->type = $pk::TYPE_FAKE_PLAYER;
        $pk->customName = $msg;
        $pk->score = $loc;
        $pk->scoreboardId = $loc;
        if (isset($this->line[$loc])) {
            unset($this->line[$loc]);
            $pkt = new SetScorePacket();
            $pkt->type = $pkt::TYPE_REMOVE;
            $pkt->entries[] = $pk;
            $this->sendDataPacket($pkt);
        }
        $pkt = new SetScorePacket();
        $pkt->type = $pkt::TYPE_CHANGE;
        $pkt->entries[] = $pk;
        $this->sendDataPacket($pkt);
        $this->line[$loc] = $msg;
    }

    /**
     * @param int $line
     * @return void
     */
    public function removeLine(int $line): void
    {
        $pk = new SetScorePacket();
        $pk->type = $pk::TYPE_REMOVE;
        $entry = new ScorePacketEntry();
        $entry->objectiveName = $this->getName();
        $entry->score = $line;
        $entry->scoreboardId = $line;
        $pk->entries[] = $entry;
        $this->sendDataPacket($pk);
        if (isset($this->line[$line])) {
            unset($this->line[$line]);
        }
    }

    /**
     *
     */
    public function getFacingDirection()
    {
        $yaw = $this->getYaw();
        $direction = ($yaw - 180) % 360;
        if ($direction < 0) $direction += 360;
        if (0 <= $direction && $direction < 22.5) return self::N;
        elseif (22.5 <= $direction && $direction < 67.5) return self::NE;
        elseif (67.5 <= $direction && $direction < 112.5) return self::E;
        elseif (112.5 <= $direction && $direction < 157.5) return self::SE;
        elseif (157.5 <= $direction && $direction < 202.5) return self::S;
        elseif (202.5 <= $direction && $direction < 247.5) return self::SW;
        elseif (247.5 <= $direction && $direction < 292.5) return self::W;
        elseif (292.5 <= $direction && $direction < 337.5) return self::NW;
        elseif (337.5 <= $direction && $direction < 360.0) return self::N;
        else return null;
    }

    /**
     * @param string $type
     * @return bool
    */
    public function isRegistered(string $type): bool {
        $db = AlpineCore::getInstance()->getPlayerDatabase();
        $name = $this->getName();
        if($type == "faction"){
            $result = $db->query("SELECT * FROM hcfdata WHERE username='" . $db->real_escape_string($name) . "'");
            return $result->num_rows > 0 ? true : false;
        }
        if($type == "player"){
            $result = $db->query("SELECT * FROM playerdata WHERE username='" . $db->real_escape_string($name) . "'");
            return $result->num_rows > 0 ? true : false;
        }
        if($type == "deathban"){
            $result = $db->query("SELECT * FROM deathbandata WHERE username='" . $db->real_escape_string($name) . "'");
            return $result->num_rows > 0 ? true : false;
        }
        if($type == "kits"){
            $result = $db->query("SELECT * FROM kitsdata WHERE username='" . $db->real_escape_string($name) . "'");
            return $result->num_rows > 0 ? true : false;
        }
    }

    public function createCustomData()
    {
        $db = AlpineCore::getInstance()->getPlayerDatabase();
        $name = $this->getName();
        $rank = "Player";
        $start = 500;
        $i = 0;
        $false = "false";
        $time = 60 * 30;
        $true = 1;
        $elo = 1000;
        $permission = "";
        $ip = [$this->getAddress(), $this->getAddress()];
        $playerip = json_encode($ip);
        $cid = $this->getClientId();
        $skin = "";
        if(!$this->isRegistered("faction")){
            $hdata = $db->prepare("INSERT INTO hcfdata(username, money, kills, deaths, pvpenabled, pvptime, gapcooldown, reclaim, staffmode, inventory, helmet, leggings, chestplate, boots) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $hdata->bind_param("siiiiiiiisssss", $name, $start, $i, $i, $true, $time, $i, $i, $i, $permission, $permission, $permission, $permission, $permission);
            $hdata->execute();
            $hdata->close();
        }
        if(!$this->isRegistered("player")){
            $pdata = $db->prepare("INSERT INTO playerdata(username, rank, permissions, elo, tags, banned, bannedtimes, banduration, warnings, muted, ip, cid, skin) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $pdata->bind_param("sssisiiiiisss", $name, $rank, $permission, $elo, $permission, $i, $i, $i, $i, $i, $playerip, $cid, $skin);
            $pdata->execute();
            $pdata->close();
        }
        if(!$this->isRegistered("kits")){
            $kdata = $db->prepare("INSERT INTO kitsdata(username, starter, bard, miner, rogue, diamond, archer, master, builder, brewer) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $kdata->bind_param("siiiiiiiii", $name, $i, $i, $i, $i, $i, $i, $i, $i, $i);
            $kdata->execute();
            $kdata->close();
        }
        if(!$this->isRegistered("deathban")){
            $ddata = $db->prepare("INSERT INTO deathbandata (username, lives, time, deathbanned, zombielogger) VALUES (?, ?, ?, ?, ?)");
            $ddata->bind_param("siiss", $name, $i, $i, $false, $false);
            $ddata->execute();
            $ddata->close();
        }
    }
}
