<?php
declare(strict_types=1);
namespace hcf\level;

use hcf\AlpineCore;
use hcf\level\generator\{ender\Ender, VoidGenerator};
use pocketmine\level\generator\GeneratorManager;
use pocketmine\Server as PMServer;

class LevelManager {
    public static $loaded = false;

    public static function init(){
        if(!self::$loaded){
            self::$loaded = true;
            self::registerGenerators();
            self::loadAndGenerateLevels();
        }
    }

    private static function registerGenerators(){
        GeneratorManager::addGenerator(Ender::class, "ender");
    }

    private static function loadAndGenerateLevels(){
        if(!PMServer::getInstance()->loadLevel(AlpineCore::$netherName)){
            PMServer::getInstance()->generateLevel(AlpineCore::$netherName, time(), GeneratorManager::getGenerator("nether"));
        }
        AlpineCore::$netherLevel = PMServer::getInstance()->getLevelByName(AlpineCore::$netherName);
        if(!PMServer::getInstance()->loadLevel(AlpineCore::$endName)){
            PMServer::getInstance()->generateLevel(AlpineCore::$endName, time(), GeneratorManager::getGenerator("ender"));
        }
        AlpineCore::$endLevel = PMServer::getInstance()->getLevelByName(AlpineCore::$endName);
    }
}