<?php
declare(strict_types=1);
namespace hcf\utils;

use pocketmine\Player;
use hcf\blocks\{Portal, EndPortal};
use pocketmine\block\Block;
use pocketmine\entity\Entity;

class EntityUtils extends Utils {

    public static function isInsideOfEndPortal(Entity $entity): bool {
        if($entity->level === null) return false;
        $block = $entity->getLevel()->getBlock($entity);
        if($block instanceof EndPortal) return true;
        return false;
    }

    public static function isInsideOfPortal(Entity $entity): bool {
        if($entity->level === null) return false;
        $block = $entity->getLevel()->getBlock($entity);
        if($block instanceof Portal) return true;
        return false;
    }
}