<?php
declare(strict_types=1);
namespace hcf\utils;

use hcf\AlpineCore;
use pocketmine\Player;
use pocketmine\level\Level;
use pocketmine\utils\TextFormat;
use pocketmine\math\Vector3;
use pocketmine\network\mcpe\protocol\types\DimensionIds;

class Utils {

   /**
     * @param int $int
     * @return string
     */
   public static function intToTime(int $int): string {
      $days = 0;
      $hours = 0;
      $minutes = 0;
      $seconds = floor($int % 60);
      if($int >= 60){
         $minutes = floor(($int % 3600) / 60);
         if($int >= 3600){
            $hours = floor(($int % (3600 * 24)) / 3600);
            if($int >= 3600 * 24){
               $days = floor($int / (3600 * 24));
            }
         }
      }
      return $days . "d, " . $hours . "h, " . $minutes . "m, " . $seconds . "s";
   }
   /**
     * @param int $int
     * @return string
     */
   public static function intToString(int $int): string {
      $minutes = floor($int / 60);
      $seconds = floor($int % 60);
      return (($minutes < 10 ? "0" : "") . $minutes . ":" . ($seconds < 10 ? "0" : "").  $seconds);
   }
   /**
     * @param int $time
     * @return string
     */
   public static function intToFullString(int $time): string {
      $hours = null;
      $minutes = null;
      $seconds = floor($time % 60);
      if($time >= 60){
         $minutes = floor(($time % 3600) / 60);
         if($time >= 3600){
            $hours = floor(($time % (3600 * 24)) / 3600);
         }
      }
      return ($minutes !== null ? ($hours !== null ? ($hours < 10 ? "0" : "") . "$hours" . ":" : "") . ($minutes < 10 ? "0" : "") . "$minutes" . ":" : "") . ($seconds < 10 ? "0" : "") . "$seconds";
   }

   /**
     * @param Vector3 $pos1
     * @param Vector3 $pos2
     */
    public static function vector3XZDistance(Vector3 $pos1, Vector3 $pos2){
        return (($pos1->x - $pos2->x) + ($pos1->z - $pos2->z));
    }

   /**
     * @param Player $player
     * @param int $id
     * @return bool
     */
    public static function isDelayedTeleportCancelleable(Player $player, int $id): bool {
        switch($id){
            case DimensionIds::NETHER:
                return (!EntityUtils::isInsideOfPortal($player));
            case DimensionIds::THE_END:
                return (!EntityUtils::isInsideOfEndPortal($player));
            case DimensionIds::OVERWORLD:
                return (!EntityUtils::isInsideOfEndPortal($player) && !EntityUtils::isInsideOfPortal($player));
        }
        return false;
    }

   /**
     * @param Player $player
     * @param int $id
     * @return bool
     */
    public static function getDimension(Level $level): int {
        if($level->getName() == AlpineCore::$netherLevel->getName()){
                return DimensionIds::NETHER;
        } elseif($level->getName() == AlpineCore::$endLevel->getName()){
                return DimensionIds::THE_END;
        }
        return DimensionIds::OVERWORLD;
    }
}