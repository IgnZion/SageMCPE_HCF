<?php
declare(strict_types=1);
namespace hcf\commands\staff;

use hcf\{
   AlpineCore, AlpinePlayer,
   events\timers\SOTW
};
use pocketmine\command\{
   CommandSender, PluginCommand
};
use pocketmine\Server;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat as TF;

class SotwCmd extends PluginCommand {
   /** @var AlpineCore */
   private $plugin;

   /**
     * StatsCmd constructor.
     *
     * @param AlpineCore $plugin
     */
   public function __construct(AlpineCore $plugin){
      parent::__construct("sotw", $plugin);
      $this->plugin = $plugin;
      $this->setPermission("core.sotw");
      $this->setUsage("/sotw <start | stop>");
      $this->setDescription("Start or Stop SOTW!");
   }

   /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     */
   public function execute(CommandSender $sender, string $commandLabel, array $args){
      if($sender->hasPermission("core.sotw")){
         if(isset($args[0])){
            switch($args[0]){
               case "start":
                  SOTW::startTimer();
               break;

               case "stop":
                  SOTW::stopTimer();
               break;
            }
         } else {
         $sender->sendMessage(TF::BOLD . TF::RED . "»» " . TF::RESET . TF::GRAY . "Please use: /sotw <start | stop>");
         }
      } else {
      $sender->sendMessage("§l§c»» §r§7Only staff members can use that command");
      }
   }
}