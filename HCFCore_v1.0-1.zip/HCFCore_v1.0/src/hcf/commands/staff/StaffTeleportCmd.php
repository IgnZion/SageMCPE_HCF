<?php
declare(strict_types=1);
namespace hcf\commands\staff;

use hcf\{
   AlpineCore, AlpinePlayer
};
use pocketmine\command\{
   CommandSender, PluginCommand
};
use pocketmine\Server;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat as TF;

class StaffTeleportCmd extends PluginCommand {
   /** @var AlpineCore */
   private $plugin;

   /**
     * StaffTeleportCmd constructor.
     *
     * @param AlpineCore $plugin
     */
   public function __construct(AlpineCore $plugin){
      parent::__construct("staffteleport", $plugin);
      $this->plugin = $plugin;
      $this->setPermission("core.cmd.staffteleport");
      $this->setUsage("/staffteleport <player>");
      $this->setAliases(["stp", "stafftp", "steleport"]);
      $this->setDescription("Teleport to players when in staffmode!");
   }

   /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     */
   public function execute(CommandSender $sender, string $commandLabel, array $args){
       if($sender instanceof AlpinePlayer){
           if(isset($args[0])){
               if($sender->isStaffMode()){
                   $player = AlpineCore::getInstance()->getServer()->getPlayer($args[0]);
                   if($player != null){
                       $sender->teleport($player);
                       foreach(AlpineCore::getInstance()->getServer()->getOnlinePlayers() as $staff){
                           if($staff->hasPermission("core.cmd.staffmode")){
                               $staff->sendMessage("§l§a»» §r§7" . $sender->getName() . " has teleported to " . $player->getName());
                           }
                       }
                       $sender->sendMessage("§l§a»» §r§7You have teleported to " . $player->getName());
                   } else $sender->sendMessage("§l§c»» §r§7That player isn't online at the moment.");
               } else $sender->sendMessage("§l§c»» §r§7You must be in staffmode to run this command!");
           } else $sender->sendMessage("§l§a»» §r§7Please choose a name by using /stp <player>!");
       }
    }
}