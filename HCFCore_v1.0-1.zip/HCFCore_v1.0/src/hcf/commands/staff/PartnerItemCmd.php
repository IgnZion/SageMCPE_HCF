<?php
declare(strict_types=1);

namespace hcf\commands\staff;

use hcf\{
   AlpineCore, AlpinePlayer
};
use pocketmine\command\{
   CommandSender, PluginCommand
};
use pocketmine\item\Item;
use pocketmine\nbt\tag\{CompoundTag, ByteTag, ListTag, StringTag, IntTag};
use pocketmine\Server;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat as TF;

class PartnerItemCmd extends PluginCommand {
    /** @var AlpineCore */
    private $plugin;
    /**
      * PartnerItemCmd constructor.
      *
      * @param AlpineCore $plugin
      */
    public function __construct(AlpineCore $plugin){
        parent::__construct("partneritem", $plugin);
        $this->plugin = $plugin;
        $this->setPermission("core.partneritem");
        $this->setUsage("/pi [item: bone, bard, epremover, ninja] [player] [amount]");
        $this->setAliases(["pi", "pitem", "partneri"]);
        $this->setDescription("Gives a player a partner item. /pi [item: bone, bard, epremover, ninja] [player] [amount]");
    }
   
    /**
      * @param CommandSender $sender
      * @param string $commandLabel
      * @param array $args
      */
    public function execute(CommandSender $sender, string $commandLabel, array $args){
        if(!$sender->hasPermission("core.partneritem")){
            $sender->sendMessage("". "§l§c»» §r§7You do not have permission to run this command!");
            return;
        }
        if(empty($args)){
            $sender->sendMessage("§l§c»» §r§7Use '/pi [item: bone, bard, epremover, ninja] [player] [amount=1]'");
            return;
        }
        if(($target = $this->plugin->getServer()->getPlayer($args[1])) === null){
            $sender->sendMessage("§l§c»» §r§7That player was not found!");
            return;
        }
        $amount = 1;
        if(isset($args[2])){
            if((int) $args[2] < 1){
                $sender->sendMessage("§l§c»» §r§7Please choose a number greater than 0!");
                return;
            }
            $amount = (int) $args[2];
        }
        if($args[0] == "bone"){
            $item = Item::get(Item::BONE, 0, $amount);
            $item->setNamedTagEntry(new ListTag("ench"));
            $item->setCustomName(TF::RESET . TF::RED . "Tax's" . TF::RESET. TF::GRAY . " Magical Bone");
            $item->setLore(["",
            TF::GRAY . " Hit a player with this bone and they won't be",
            TF::GRAY . " able to place or break blocks for 15 seconds!",
            "",
            TF::BOLD . TF::RED . "WARNING:" . TF::RESET . TF::RED . " 2 Minute Cooldown!"]);
            $nametag = $item->getNamedTag();
            $nametag->setString("partneritem", "taxmagicalbone");
            $item->setNamedTag($nametag);
            $target->getInventory()->addItem($item);
        } elseif($args[0] == "bard"){
            $item = Item::get(Item::DYE, 14, $amount);
            $item->setNamedTagEntry(new ListTag("ench"));
            $item->setCustomName(TF::RESET . TF::GOLD . "Deadly's" . TF::RESET. TF::GRAY . " Portable Bard");
            $item->setLore(["",
            TF::GRAY . " Losing a fight to someone with a Bard?",
            TF::GRAY . " use this item to get a few Bard Effects!",
            "",
            TF::BOLD . TF::RED . "WARNING:" . TF::RESET . TF::RED . " 3 Minute Cooldown!"]);
            $nametag = $item->getNamedTag();
            $nametag->setString("partneritem", "portablebard");
            $item->setNamedTag($nametag);
            $target->getInventory()->addItem($item);
        } elseif($args[0] == "epremover"){
            $item = Item::get(Item::STICK, 0, $amount);
            $item->setNamedTagEntry(new ListTag("ench"));
            $item->setCustomName(TF::RESET . TF::GOLD . "Lord's" . TF::RESET. TF::GRAY . " EP Cooldown Remover");
            $item->setLore(["",
            TF::GRAY . " Are you in a jam and need to make a quick",
            TF::GRAY . " getaway? Use this to remove you on ep cooldown!",
            "",
            TF::BOLD . TF::RED . "WARNING:" . TF::RESET . TF::RED . " Total of 10 uses!"]);
            $nametag = $item->getNamedTag();
            $nametag->setInt("uses", 10);
            $nametag->setString("partneritem", "pearlcooldownremover");
            $item->setNamedTag($nametag);
            $target->getInventory()->addItem($item);
        } elseif($args[0] == "ninja"){
            $item = Item::get(Item::NETHER_STAR, 0, $amount);
            $item->setNamedTagEntry(new ListTag("ench"));
            $item->setCustomName(TF::RESET . TF::GOLD . "Anonymous'" . TF::RESET. TF::GRAY . " Ninja Star");
            $item->setLore(["",
            TF::GRAY . " Are you trapped and getting killed? Use this",
            TF::GRAY . " to teleport to the last person that hit you!",
            "",
            TF::BOLD . TF::RED . "WARNING:" . TF::RESET . TF::RED . " Total of 5 uses! Player also gets a warning!"]);
            $nametag = $item->getNamedTag();
            $nametag->setInt("uses", 5);
            $nametag->setString("partneritem", "ninjaability");
            $item->setNamedTag($nametag);
            $target->getInventory()->addItem($item);
        }
    }
}