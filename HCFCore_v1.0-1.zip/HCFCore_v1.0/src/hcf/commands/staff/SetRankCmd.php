<?php
declare(strict_types=1);
namespace hcf\commands\staff;

use hcf\{
   AlpineCore, AlpinePlayer
};
use pocketmine\command\{
   CommandSender, PluginCommand
};
use pocketmine\Server;
use pocketmine\utils\TextFormat as TF;

class SetRankCmd extends PluginCommand {
   /** @var AlpineCore */
   private $plugin;

   /**
     * BalanceCmd constructor.
     *
     * @param AlpineCore $plugin
     */
   public function __construct(AlpineCore $plugin){
      parent::__construct("setrank", $plugin);
      $this->plugin = $plugin;
      $this->setPermission("core.cmd.setrank");
      $this->setUsage("/setrank <user> <rank>");
      $this->setDescription("Sets the rank of a player on the server!");
   }

   /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     */
   public function execute(CommandSender $sender, string $commandLabel, array $args){
      if(!isset($args[1]) && $sender->hasPermission("core.cmd.setrank")){
         $sender->sendMessage(TF::RED . TF::BOLD . "»» " . TF::RESET . TF::GRAY . "Please use the command like /setrank <username> <rank>");
         $sender->sendMessage(TF::RED . TF::BOLD . " * " . tF::RESET . TF::GRAY . "Ranks: Player, Voyager, NitroBooster, Pioneer, Alpinist, YouTuber, Partner, Trainee, Mod, SrMod, Admin, SrAdmin, Manager, Owner"); 
      }

      if(isset($args[0]) && isset($args[1]) && $sender->hasPermission("core.cmd.setrank")){
         $player = $this->plugin->getServer()->getPlayer($args[0]);
         if($player != null){
            if($args[1] == "Player" || $args[1] == "NitroBooster" || $args[1] == "Voyager" || $args[1] == "Pioneer" || $args[1] == "Alpinist" || $args[1] == "YouTuber" || $args[1] == "Partner" || $args[1] == "Trainee" || $args[1] == "Mod" ||$args[1] == "SrMod" ||$args[1] == "Admin" ||$args[1] == "SrAdmin" || $args[1] == "Manager" || $args[1] == "Owner"){  
               $player->setRank($args[1]);
               $player->sendMessage(TF::GREEN . TF::BOLD . "»» " . TF::RESET . TF::GRAY . "Your rank has been set to " . TF::GREEN . $args[1]);
               $sender->sendMessage(TF::GREEN . TF::BOLD . "»» " . TF::RESET . TF::GRAY . $player->getName() . " rank has been set to " . TF::GREEN . $args[1]);
            }
         }
      }
   }
}
