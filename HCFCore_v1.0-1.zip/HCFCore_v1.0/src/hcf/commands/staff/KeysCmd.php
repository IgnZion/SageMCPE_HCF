<?php
declare(strict_types=1);
namespace hcf\commands\staff;

use hcf\{
   AlpineCore, AlpinePlayer
};
use pocketmine\command\{
   CommandSender, PluginCommand
};
use pocketmine\Server;
use pocketmine\utils\TextFormat as TF;

class KeysCmd extends PluginCommand {
    /** @var AlpineCore */
    private $plugin;
    
    /**
    * KeysCmd constructor.
    *
    * @param AlpineCore $plugin
    */
    public function __construct(AlpineCore $plugin){
        parent::__construct("keys", $plugin);
        $this->plugin = $plugin;
        $this->setPermission("core.cmd.setrank");
        $this->setUsage("/keys <key> <total> <username>");
        $this->setDescription("Give players a key to use at crates area!");
    }

    /**
    * @param CommandSender $sender
    * @param string $commandLabel
    * @param array $args
    */
    public function execute(CommandSender $sender, string $commandLabel, array $args){
        if(!isset($args[0]) || !isset($args[1]) || !isset($args[2])){
            if($sender->hasPermission("core.cmd.keys")){
                $sender->sendMessage(TF::RED . TF::BOLD . "»» " . TF::RESET . TF::GRAY . "Please use the command like /keys <key> <total> <player>");
                $sender->sendMessage(TF::RED . TF::BOLD . " * " . TF::RESET . TF::GRAY . "Keys: Voyager, Pioneer, Alpinist, Partner, Koth, Vote");
                return;
            }
        }
        if($sender->hasPermission("core.cmd.keys")){
            if($args[0] == "Voyager" || $args[0] == "Pioneer" || $args[0] == "Alpinist" || $args[0] == "Partner" || $args[0] == "Koth" || $args[0] == "Vote"){
                if(is_numeric($args[1])){
                    if($args[2] == "@a" || $args[2] == "all"){
                        foreach(AlpineCore::getInstance()->getServer()->getOnlinePlayers() as $all){
                            $type = 0;
                            if($args[0] == "Vote") $type = 0;
                            if($args[0] == "Koth") $type = 1;
                            if($args[0] == "Partner") $type = 2;
                            if($args[0] == "Voyager") $type = 3;
                            if($args[0] == "Pioneer") $type = 4;
                            if($args[0] == "Alpinist") $type = 5;
                            AlpineCore::getInstance()->getCratesManager()->giveKey($all, $type, (int) $args[1]);
                        }
                    }
                    $player = $this->plugin->getServer()->getPlayer($args[2]);
                    if($player != null){
                        $type = 0;
                        if($args[0] == "Vote") $type = 0;
                        if($args[0] == "Koth") $type = 1;
                        if($args[0] == "Partner") $type = 2;
                        if($args[0] == "Voyager") $type = 3;
                        if($args[0] == "Pioneer") $type = 4;
                        if($args[0] == "Alpinist") $type = 5;
                        AlpineCore::getInstance()->getCratesManager()->giveKey($player, $type, (int) $args[1]);
                        $player->sendMessage(TF::GREEN . TF::BOLD . "»» " . TF::RESET . TF::GRAY . "Your have been given x" . $args[1] . " " . TF::GREEN . $args[0] . " Keys");
                        $sender->sendMessage(TF::GREEN . TF::BOLD . "»» " . TF::RESET . TF::GRAY . $player->getName() . " has been given x" . $args[1] . " " . TF::GREEN . $args[0] . " Keys");
                     } else $sender->sendMessage(TF::RED . TF::BOLD . "»» " . TF::RESET . TF::GRAY . " That player is offline!");
                 } else $sender->sendMessage(TF::RED . TF::BOLD . "»» " . TF::RESET . TF::GRAY . " Please enter a numeric number for keys!");
             } else $sender->sendMessage(TF::RED . TF::BOLD . "»» " . TF::RESET . TF::GRAY . " Please enter a valid key type!");
        } else $sender->sendMessage(TF::RED . TF::BOLD . "»» " . TF::RESET . TF::GRAY . " You do not have permission for this command");
    }
}