<?php
declare(strict_types=1);
namespace hcf\commands\staff;

use hcf\{
   AlpineCore, AlpinePlayer
};
use jojoe77777\FormAPI\{
    FormAPI, SimpleForm, CustomForm
};
use pocketmine\command\{
   CommandSender, PluginCommand
};
use pocketmine\{
    Server, Player
};
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat as TF;

class MuteCmd extends PluginCommand {
   /** @var AlpineCore */
   private $plugin;

   /**
     * MuteCmd constructor.
     *
     * @param AlpineCore $plugin
     */
   public function __construct(AlpineCore $plugin){
      parent::__construct("mute", $plugin);
      $this->plugin = $plugin;
      $this->setPermission("core.cmd.mute");
      $this->setUsage("/mute [player] [time]");
      $this->setDescription("Mute a player, preventing them from talking in chat!");
   }

   /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     */
   public function execute(CommandSender $sender, string $commandLabel, array $args){
       if($sender->hasPermission("core.cmd.mute")){
           if(!isset($args[0] || !isset($args[1])){
               $sender->sendMessage(TF::RED . TF::BOLD . "»» " . TF::RESET . TF::GRAY . "Use the right args to mute a player Use: /mute [player] [time: eg 1]");
               return;
           }
           $time = $args[1];
           if(!is_numeric($time)){
               $sender->sendMessage(TF::RED . TF::BOLD . "»» " . TF::RESET . TF::GRAY . "Use the right args to mute a player Use: /mute [player] [time: eg 1]");
               return;
           }
           $player = AlpineCore::getInstance()->getServer()->getPlayer($args[1]);
           if($player != null){
               $form = new CustomForm(function (Player $sender, int $data = null) use ($player, $time): void {
                   $name = $player->getName();
                   if($data === null){
                       return true;
                   }
                   switch($result){
                       case 0:
                           $mute = time() + ($time * 60);
                           $player->setMuteTime($mute);
                           $player->sendMessage(TF::RED . TF::BOLD . "»» " . TF::RESET . TF::GRAY . "You have been muted by a staff member!");
                           $sender->sendMessage(TF::RED . TF::BOLD . "»» " . TF::RESET . TF::GRAY . "The mute was successful!");
                           break;

                       case 1:
                           $mute = time() + ($time * 60 * 60);
                           $player->setMuteTime($mute);
                           $player->sendMessage(TF::RED . TF::BOLD . "»» " . TF::RESET . TF::GRAY . "You have been muted by a staff member!");
                           $sender->sendMessage(TF::RED . TF::BOLD . "»» " . TF::RESET . TF::GRAY . "The mute was successful!");
                           break;

                       case 2:
                           $mute = time() + ($time * 60 * 60 * 24);
                           $player->setMuteTime($mute);
                           $player->sendMessage(TF::RED . TF::BOLD . "»» " . TF::RESET . TF::GRAY . "You have been muted by a staff member!");
                           $sender->sendMessage(TF::RED . TF::BOLD . "»» " . TF::RESET . TF::GRAY . "The mute was successful!");
                           break;
                   }
                   return false;
               });
               $form->setTitle(TF::RED . "Mute Menu");
               $form->addButton("Mute By Minute!");
               $form->addButton("Mute By Hours!");
               $form->addButton("Mute By Days!");
               $sender->sendForm($form);
           }
       }
   }
}