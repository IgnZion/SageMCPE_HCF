<?php
declare(strict_types=1);

namespace hcf\commands\staff;

use hcf\{
   AlpineCore, AlpinePlayer
};
use pocketmine\command\{
   CommandSender, PluginCommand
};
use pocketmine\item\Item;
use pocketmine\nbt\tag\{CompoundTag, ByteTag, ListTag};
use pocketmine\Server;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat as TF;

class KenzoBallCmd extends PluginCommand {
    /** @var AlpineCore */
    private $plugin;
    /**
      * KenzoBallCmd constructor.
      *
      * @param AlpineCore $plugin
      */
    public function __construct(AlpineCore $plugin){
        parent::__construct("kenzoball", $plugin);
        $this->plugin = $plugin;
        $this->setPermission("core.kenzoball");
        $this->setUsage("/kenzoball [player] [amount]");
        $this->setDescription("Gives a player kenzo teleportation balls");
    }
   
    /**
      * @param CommandSender $sender
      * @param string $commandLabel
      * @param array $args
      */
    public function execute(CommandSender $sender, string $commandLabel, array $args){
        if(!$sender->hasPermission("core.kenzoball")){
            $sender->sendMessage("". "§l§c»» §r§7You do not have permission to run this command!");
            return;
        }
        if(empty($args)){
            $sender->sendMessage("§l§c»» §r§7Use '/kenzoball <player> [amount=1]'");
            return;
        }
        if(($target = $this->plugin->getServer()->getPlayer($args[0])) === null){
            $sender->sendMessage("§l§c»» §r§7That player was not found!");
            return;
        }
        $amount = 1;
        if(isset($args[1])){
            if((int) $args[1] < 1){
                $sender->sendMessage("§l§c»» §r§7Please choose a number greater than 0!");
                return;
            }
            $amount = (int) $args[1];
        }
        $item = Item::get(Item::SNOWBALL, 0, $amount);
        $item->setNamedTagEntry(new ListTag("ench"));
        $item->setCustomName(TF::BOLD . TF::AQUA . "Swapper" . TF::RESET. TF::GRAY . " Ball");
        $item->setLore([
            TF::GRAY . " Switch Positions with anyone that is",
            TF::GRAY . " hit by this ball. Great for trapping!",
            "",
            TF::BOLD . TF::RED . "WARNING:" . TF::RESET . TF::RED . " 10 Seconds Cooldown!"]);
        $item->setCustomBlockData(new CompoundTag("", [
            new ByteTag("kenzoball", 1)
        ]));
        $target->getInventory()->addItem($item);
        $target->sendMessage("You have been given " . $amount . "x Kenzo Balls");
        if($target->getName() !== $sender->getName()){
            $sender->sendMessage("You have given " . $target->getName() . " " . $amount . "x Kenzo Balls");
        }
    }
}
