<?php
declare(strict_types=1);
namespace hcf\commands\economy;

use hcf\{
   AlpineCore, AlpinePlayer
};
use pocketmine\command\{
   CommandSender, PluginCommand
};
use pocketmine\Server;
use pocketmine\utils\TextFormat as TF;

class BalanceCmd extends PluginCommand {
   /** @var AlpineCore */
   private $plugin;

   /**
     * BalanceCmd constructor.
     *
     * @param AlpineCore $plugin
     */
   public function __construct(AlpineCore $plugin){
      parent::__construct("balance", $plugin);
      $this->plugin = $plugin;
      $this->setPermission("core.balance");
      $this->setUsage("/balance [user]");
      $this->setDescription("Shows a user's balance, without an ign it will show yours!");
   }

   /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     */
   public function execute(CommandSender $sender, string $commandLabel, array $args){
      if(!isset($args[0]) && $sender instanceof AlpinePlayer){
         $balance = $sender->getBalance();
         $sender->sendMessage(TF::GREEN . TF::BOLD . "»» " . TF::RESET . TF::GRAY . "Your balance is " . TF::GREEN . "$" . number_format($balance) . "§r");
      }

      if(isset($args[0])){
         $playername = $args[0];
         $player = $this->plugin->getServer()->getPlayer($playername);
         if($player != null){
            $balance = $player->getBalance();
            $sender->sendMessage(TF::BOLD . TF::GREEN . "»» " . TF::RESET . TF::GRAY . $player->getName() . " balance is $" . number_format($balance));
         } else {
         $sender->sendMessage(TF::RED . TF::BOLD . "»» " . TF::RESET . TF::GRAY . "That Player is offline or incorrect name inputted");
         }
      }
   }
}