<?php
declare(strict_types=1);
namespace hcf\commands\economy;

use hcf\{
   AlpineCore, AlpinePlayer
};
use pocketmine\command\{
   CommandSender, PluginCommand
};
use pocketmine\Server;
use pocketmine\utils\TextFormat as TF;

class GiveMoneyCmd extends PluginCommand {
   /** @var AlpineCore */
   private $plugin;

   /**
     * GiveMoneyCmd constructor.
     *
     * @param AlpineCore $plugin
     */
   public function __construct(AlpineCore $plugin){
      parent::__construct("givemoney", $plugin);
      $this->plugin = $plugin;
      $this->setPermission("core.cmd.givemoney");
      $this->setUsage("/givemoney [user] [amount]");
      $this->setDescription("Add money to other players balance! [Staff]");
   }

   /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     */
   public function execute(CommandSender $sender, string $commandLabel, array $args){
      if(isset($args[0]) && isset($args[1])){
         if($sender->hasPermission("core") || $sender->hasPermission("core.cmd.givemoney")){
            $playername = $args[0];
            $player = $this->plugin->getServer()->getPlayer($playername);
            if($player != null){
               if(is_numeric($args[1])){
                  $money = (int) $args[1];
                  $player->addMoney($money);
                  $sender->sendMessage("" . TF::RED . TF::BOLD . "»» " . TF::RESET . TF::GRAY . "$" . $money . " has been added to " . $player->getName() . " balance!");
               } else {
               $sender->sendMessage(TF::BOLD . TF::RED . "»» " . TF::RESET . TF::GRAY . "You must input a digit after player name!");
               }
            } else {
            $sender->sendMessage(TF::BOLD . TF::RED . "»» " . TF::RESET . TF::GRAY . "That Player is offline or wrong name inputted!");
            }
         } else {
         $sender->sendMessage(TF::BOLD . TF::RED . "»» " . TF::RESET . TF::GRAY . "This command is for [STAFF] only!");
         }
      } else {
      $sender->sendMessage(TF::BOLD . TF::RED . "»» " . TF::RESET . TF::GRAY . "Correct usage is /givemoney [user] [amount]");
      }
   }
}
