<?php
declare(strict_types=1);
namespace hcf\commands\economy;

use hcf\{
   AlpineCore, AlpinePlayer
};
use pocketmine\command\{
   CommandSender, PluginCommand
};
use pocketmine\Server;
use pocketmine\utils\TextFormat as TF;

class PayCmd extends PluginCommand {
   /** @var AlpineCore */
   private $plugin;

   /**
     * PayCmd constructor.
     *
     * @param AlpineCore $plugin
     */
   public function __construct(AlpineCore $plugin){
      parent::__construct("pay", $plugin);
      $this->plugin = $plugin;
      $this->setPermission("core.pay");
      $this->setUsage("/pay [user] [amount]");
      $this->setDescription("Pay other players by using your balance");
   }

   /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     */
   public function execute(CommandSender $sender, string $commandLabel, array $args){
      if(!$sender instanceof AlpinePlayer){
         $sender->sendMessage(TF::BOLD . TF::RED . "»» " . TF::RESET . TF::GRAY . "Only Alpine Players can use this command!");
      }

      if(isset($args[0]) && isset($args[1])){
         $playername = $args[0];
         $player = $this->plugin->getServer()->getPlayer($playername);
         if($player != null){
            if(is_numeric($args[1])){
               $money = (int) $args[1];
               $balance = (int) $sender->getBalance();
               if($balance >= $money){
                  $player->addMoney($money);
                  $sender->reduceMoney($money);
                  $player->sendMessage(TF::BOLD . TF::GREEN . "»» " . TF::RESET . TF::GRAY . $sender->getName() . " has sent you " . TF::GREEN . "$" . $money . "!" . TF::RESET);
                  $sender->sendMessage(TF::RED . TF::BOLD . "»» " . TF::RESET . TF::GRAY . $player->getName() . " has been sent " . TF::RED . "$" . $money . "!" . TF::RESET);
               } else {
               $sender->sendMessage(TF::BOLD . TF::RED . "»» " . TF::RESET . TF::GRAY . "You do not have enough money to send!");
               }
            } else {
            $sender->sendMessage(TF::BOLD . TF::RED . "»» " . TF::RESET . TF::GRAY . "You must input a digit after player name!");
            }
         } else {
         $sender->sendMessage(TF::BOLD . TF::RED . "»» " . TF::RESET . TF::GRAY . "That Player is offline or wrong name inputted!");
         }
      } else {
      $sender->sendMessage(TF::BOLD . TF::RED . "»» " . TF::RESET . TF::GRAY . "Correct usage is /pay [user] [amount]");
      }
   }
}