<?php
declare(strict_types=1);
namespace hcf\commands\economy;

use hcf\{
   AlpineCore, AlpinePlayer
};
use pocketmine\command\{
   CommandSender, PluginCommand
};
use pocketmine\Server;
use pocketmine\utils\TextFormat as TF;

class SetMoneyCmd extends PluginCommand {
   /** @var AlpineCore */
   private $plugin;

   /**
     * SetMoneyCmd constructor.
     *
     * @param AlpineCore $plugin
     */
   public function __construct(AlpineCore $plugin){
      parent::__construct("setmoney", $plugin);
      $this->plugin = $plugin;
      $this->setPermission("core.cmd.setmoney");
      $this->setUsage("/setmoney [user] [amount]");
      $this->setDescription("Set/Override a player's current balance! [Staff]");
   }

   /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     */
   public function execute(CommandSender $sender, string $commandLabel, array $args){
      if(isset($args[0]) && isset($args[1])){
         if($sender->hasPermission("core") || $sender->hasPermission("core.cmd.setmoney")){
            $playername = $args[0];
            $player = $this->plugin->getServer()->getPlayer($playername);
            if($player != null){
               if(is_numeric($args[1])){
                  $new = (int) $args[1];
                  if($new >= 0){
                     $player->setMoney($new);
                     $sender->sendMessage("" . TF::RED . TF::BOLD . "»» " . TF::RESET . TF::GRAY . "$" . $new . " is " . $player->getName() . " new balance!");
                  } else {
                  $sender->sendMessage(TF::RED . TF::BOLD . "»» " . TF::RESET . TF::GRAY . "Cannot set a balance below 0! #YouBad");
                  }
               } else {
               $sender->sendMessage(TF::BOLD . TF::RED . "»» " . TF::RESET . TF::GRAY . "You must input a digit after player name!");
               }
            } else {
            $sender->sendMessage(TF::BOLD . TF::RED . "»» " . TF::RESET . TF::GRAY . "That Player is offline or wrong name inputted!");
            }
         } else {
         $sender->sendMessage(TF::BOLD . TF::RED . "»» " . TF::RESET . TF::GRAY . "This command is for [STAFF] only!");
         }
      } else {
      $sender->sendMessage(TF::BOLD . TF::RED . "»» " . TF::RESET . TF::GRAY . "Correct usage is /setmoney [user] [amount]");
      }
   }
}
