<?php
declare(strict_types=1);
namespace hcf\commands;

use hcf\{
   AlpineCore, AlpinePlayer
};
use pocketmine\command\{
   CommandSender, PluginCommand
};
use pocketmine\Server;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat as TF;

class ChatCmd extends PluginCommand {
   /** @var AlpineCore */
   private $plugin;

   /**
     * ChatCmd constructor.
     *
     * @param AlpineCore $plugin
     */
   public function __construct(AlpineCore $plugin){
      parent::__construct("chat", $plugin);
      $this->plugin = $plugin;
      $this->setPermission("core.chat");
      $this->setUsage("/chat faction|staff|public");
      $this->setDescription("Change your chatting configuration!!");
   }

   /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     */
   public function execute(CommandSender $sender, string $commandLabel, array $args){
      if($sender instanceof AlpinePlayer){
         $chat = $sender->getChat();
         $public = AlpinePlayer::PUBLIC;
         $faction = AlpinePlayer::FACTION;
         $staff = AlpinePlayer::STAFF;
         if(isset($args[0])){
            switch($args[0]){
               case "faction":
               case "fac":
               case "f":
                  if($sender->IsInFaction()){
                     if($chat == $public || $chat == $staff){
                        $sender->sendMessage("" . "§l§a»» §r§7Your chat is now set to your faction!");
                        $sender->setChat($faction);
                     } else $sender->sendMessage("". "§l§c»» §r§7You are already in your faction's chat!");
                  } else $sender->sendMessage("" . "§l§c»» §r§7You must be in a faction to talk in faction's chat!");
               break;

               case "public":
                  if($chat == $faction || $chat == $staff){
                        $sender->sendMessage("" . "§l§a»» §r§7Your chat is now set to public!");
                        $sender->setChat($public);
                     } else $sender->sendMessage("". "§l§c»» §r§7You are already in the public chat!");
               break;

               case "staff":
                  if($sender->hasPermission ("core.staffchat")){
                     if($chat == $public || $chat == $faction){
                        $sender->sendMessage("" . "§l§a»» §r§7Your chat is now set to staff chat!");
                        $sender->setChat($staff);
                     } else $sender->sendMessage("". "§l§c»» §r§7You are already in staff chat!");
                  } else $sender->sendMessage("" . "§l§c»» §r§7You must be a staff to talk in this chat!");
               break;
            }
         } else $sender->sendMessage("§l§c»» §r§7Command: /chat faction|public|staff!");
      } else $sender->sendMessage("§l§c»» §r§7You must be a player to do that!");
   }
}