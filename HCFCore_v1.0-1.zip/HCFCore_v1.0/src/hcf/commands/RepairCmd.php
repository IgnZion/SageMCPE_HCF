<?php
declare(strict_types=1);
namespace hcf\commands;

use hcf\{AlpineCore, AlpinePlayer};
use pocketmine\command\{CommandSender, PluginCommand};
use pocketmine\Server;
use pocketmine\item\{Item, Armor, Tool};
use pocketmine\utils\TextFormat as TF;

class RepairCmd extends PluginCommand {
    /** @var AlpineCore */
    private $plugin;

    /**
     * PayCmd constructor.
     *
     * @param AlpineCore $plugin
     */
    public function __construct(AlpineCore $plugin){
        parent::__construct("repair", $plugin);
        $this->plugin = $plugin;
        $this->setPermission("core.repair");
        $this->setUsage("/repair [hand:all:armor]");
        $this->setDescription("Repair your items /repair [hand:all:armor]");
   }

   /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     */
    public function execute(CommandSender $sender, string $commandLabel, array $args){
        if(!$sender instanceof AlpinePlayer){
            $sender->sendMessage(TF::BOLD . TF::RED . "»» " . TF::RESET . TF::GRAY . "Only Alpine Players can use this command!");
            return;
        }
        $arg = "hand";
        if(isset($args[0])) $arg = strtolower($args[0]);
        if(!($arg === "hand" || $arg === "all" || $arg === "armor")){
            $sender->sendMessage(TF::BOLD . TF::RED . "»» " . TF::RESET . TF::GRAY . "/repair [armor:all:hand]");
            return;
        }
        if($arg == "hand"){
            $rank = $sender->getRank();
            if($rank == "Player"){
                $index = $sender->getInventory()->getHeldItemIndex();
                $item = $sender->getInventory()->getItem($index);
                $balance = (int) $sender->getBalance();
                $payment = 100;
                if($this->isRepairable($item)){
                    if($item->getDamage() > 0){
                        if($balance >= $payment){
                            $sender->getInventory()->setItem($index, $item->setDamage(0));
                            $sender->reduceMoney($payment);
                            $sender->sendMessage(TF::RED . TF::BOLD . "»» " . TF::RESET . TF::GRAY . "Your item has been repaired!" . TF::RESET);
                        } else $sender->sendMessage(TF::BOLD . TF::RED . "»» " . TF::RESET . TF::GRAY . "You do not have enough money to repair!");
                    } else $sender->sendMessage(TF::BOLD . TF::RED . "»» " . TF::RESET . TF::GRAY . "That item has no damage on it!");
                } else $sender->sendMessage(TF::BOLD . TF::RED . "»» " . TF::RESET . TF::GRAY . "That item is not repairable!");
            } else {
                $index = $sender->getInventory()->getHeldItemIndex();
                $item = $sender->getInventory()->getItem($index);
                $balance = (int) $sender->getBalance();
                $payment = 0;
                if($this->isRepairable($item)){
                    if($item->getDamage() > 0){
                        if($balance >= $payment){
                            $sender->getInventory()->setItem($index, $item->setDamage(0));
                            $sender->reduceMoney($payment);
                            $sender->sendMessage(TF::RED . TF::BOLD . "»» " . TF::RESET . TF::GRAY . "Your item has been repaired!" . TF::RESET);
                        } else $sender->sendMessage(TF::BOLD . TF::RED . "»» " . TF::RESET . TF::GRAY . "You do not have enough money to repair!");
                    } else $sender->sendMessage(TF::BOLD . TF::RED . "»» " . TF::RESET . TF::GRAY . "That item has no damage on it!");
                } else $sender->sendMessage(TF::BOLD . TF::RED . "»» " . TF::RESET . TF::GRAY . "That item is not repairable!");
            }
        }
        if($arg == "armor"){
            $rank = $sender->getRank();
            if($rank == "Player"){
                $balance = (int) $sender->getBalance();
                $payment = 100;
                foreach($sender->getArmorInventory()->getContents() as $index => $item){
                    if($this->isRepairable($item)){
                        if($item->getDamage() > 0){
                            if($balance >= $payment){
                                $sender->getArmorInventory()->setItem($index, $item->setDamage(0));
                                $sender->reduceMoney($payment);
                                $sender->sendMessage(TF::RED . TF::BOLD . "»» " . TF::RESET . TF::GRAY . "A piece of your armor has been repaired!" . TF::RESET);
                            } else $sender->sendMessage(TF::BOLD . TF::RED . "»» " . TF::RESET . TF::GRAY . "You do not have enough money to repair!");
                        } else $sender->sendMessage(TF::BOLD . TF::RED . "»» " . TF::RESET . TF::GRAY . "That item has no damage on it!");
                    } else $sender->sendMessage(TF::BOLD . TF::RED . "»» " . TF::RESET . TF::GRAY . "That item is not repairable!");
                }
            } else {
                $balance = (int) $sender->getBalance();
                $payment = 0;
                foreach($sender->getArmorInventory()->getContents() as $index => $item){
                    if($this->isRepairable($item)){
                        if($item->getDamage() > 0){
                            if($balance >= $payment){
                                $sender->getArmorInventory()->setItem($index, $item->setDamage(0));
                                $sender->reduceMoney($payment);
                                $sender->sendMessage(TF::RED . TF::BOLD . "»» " . TF::RESET . TF::GRAY . "A piece of your armor has been repaired!" . TF::RESET);
                            } else $sender->sendMessage(TF::BOLD . TF::RED . "»» " . TF::RESET . TF::GRAY . "You do not have enough money to repair!");
                        } else $sender->sendMessage(TF::BOLD . TF::RED . "»» " . TF::RESET . TF::GRAY . "That item has no damage on it!");
                    } else $sender->sendMessage(TF::BOLD . TF::RED . "»» " . TF::RESET . TF::GRAY . "That item is not repairable!");
                }
            }
        }
        if($arg == "all"){
            $rank = $sender->getRank();
            if($rank == "Player"){
                $balance = (int) $sender->getBalance();
                $payment = 100;
                foreach($sender->getArmorInventory()->getContents() as $index => $item){
                    if($this->isRepairable($item)){
                        if($item->getDamage() > 0){
                            if($balance >= $payment){
                                $sender->getArmorInventory()->setItem($index, $item->setDamage(0));
                                $sender->reduceMoney($payment);
                            } 
                        }
                    }
                }
                foreach($sender->getInventory()->getContents() as $index => $item){
                    if($this->isRepairable($item)){
                        if($item->getDamage() > 0){
                            if($balance >= $payment){
                                $sender->getInventory()->setItem($index, $item->setDamage(0));
                                $sender->reduceMoney($payment);
                            } 
                        }
                    }
                }
            } else {
                $balance = (int) $sender->getBalance();
                $payment = 0;
                foreach($sender->getArmorInventory()->getContents() as $index => $item){
                    if($this->isRepairable($item)){
                        if($item->getDamage() > 0){
                            if($balance >= $payment){
                                $sender->getArmorInventory()->setItem($index, $item->setDamage(0));
                                $sender->reduceMoney($payment);
                            } 
                        }
                    }
                }
                foreach($sender->getInventory()->getContents() as $index => $item){
                    if($this->isRepairable($item)){
                        if($item->getDamage() > 0){
                            if($balance >= $payment){
                                $sender->getInventory()->setItem($index, $item->setDamage(0));
                                $sender->reduceMoney($payment);
                            } 
                        }
                    }
                }
            }
        }
    }

    /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     */
    public function isRepairable(Item $item): bool {
        return $item instanceof Tool || $item instanceof Armor;
    }
}