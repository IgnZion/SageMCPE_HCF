<?php
declare(strict_types=1);
namespace hcf\commands;

use hcf\{
   AlpineCore, AlpinePlayer
};
use pocketmine\command\{
   CommandSender, PluginCommand
};
use pocketmine\Server;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat as TF;

class PvPTimerCmd extends PluginCommand {
   /** @var AlpineCore */
   private $plugin;

   /**
     * PvPTimerCmd constructor.
     *
     * @param AlpineCore $plugin
     */
   public function __construct(AlpineCore $plugin){
      parent::__construct("pvp", $plugin);
      $this->plugin = $plugin;
      $this->setPermission("core.pvp");
      $this->setUsage("/pvp");
      $this->setDescription("PvP Timer command");
   }

   /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     */
   public function execute(CommandSender $sender, string $commandLabel, array $args){
      if(!isset($args[0])){
         $sender->sendMessage("§l§a»» §r§7PvP Timer §l§a««§r\n§l§a * §r§7/pvp enable - §aDisables your PvP timer protection!§r\n§a§lWARNING: §r§7You will be allowed to enter claims but players will be able to attack you!§r\n\n§l§a * §r§7/pvp set <player> - §aStaff Only CMD that gives player back their pvptimer");
      }
      if(isset($args[0])){
         switch($args[0]){
            case "enable":
               if($sender->isPvP()){
                  $sender->unsetPvPTimer();
                  $sender->sendMessage("§l§a»» §r§7Your PvP Timer has been lifted and you can now PvP!");
               } else {
               $sender->sendMessage("§l§c»» §r§7You are not currently on a PvP Timer!");
               }
            break;

            case "set":
               if($sender->hasPermission("core.pvp.set") && isset($args[1])){
                  $s = $this->plugin->getServer();
                  $player = $s->getPlayer($args[1]);
                  if($player !== null) {
                     $player->resetPvPTimer();
                     $sender->sendMessage("§l§a»» §r§7You have set the player's PvP Timer!");
                  } else {
               $sender->sendMessage("§l§c»» §r§7That player is not online!");
                  }
               } else {
               $sender->sendMessage("§l§c»» §r§7You are not a staff member | please insert user names!");
               }
            break;
         }
      }
   }
}
