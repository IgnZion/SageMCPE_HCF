<?php
declare(strict_types=1);
namespace hcf\commands;

use hcf\AlpineCore;
use pocketmine\Server;
use hcf\commands\staff\{
    SetRankCmd, SotwCmd, StaffmodeCmd, KeysCmd, KenzoBallCmd, PermissionsCmd, 
    PartnerItemCmd, PunishCmd, StaffTeleportCmd, AlertsCmd
};
use hcf\commands\economy\{
    PayCmd, BalanceCmd, SetMoneyCmd, GiveMoneyCmd, TakeMoneyCmd
};

class Commands {

   public static function init(): void {
      $instance = AlpineCore::getInstance();
      $server = $instance->getServer();
      $map = $server->getCommandMap();

      //////////////////// Kits ////////////////////
      $map->register("kit", new KitsCmd($instance));
      //////////////////// Kits ////////////////////
      
      //////////////////// Ranks ////////////////////
      $map->register("setrank", new SetRankCmd($instance));
      //////////////////// Ranks ////////////////////
      
      //////////////////// Economy ////////////////////
      $map->register("pay", new PayCmd($instance));
      $map->register("balance", new BalanceCmd($instance));
      $map->register("setmoney", new SetMoneyCmd($instance));
      $map->register("givemoney", new GiveMoneyCmd($instance));
      $map->register("takemoney", new TakeMoneyCmd($instance));
      //////////////////// Economy ////////////////////

      //////////////////// Stats Related ////////////////////
      $map->register("stats", new StatsCmd($instance));
      //////////////////// Stats Related ////////////////////

      //////////////////// Factions ////////////////////
      $map->register("f", new FactionsCmd($instance));
      $map->register("sotw", new SotwCmd($instance));
      $map->register("pvp", new PvPTimerCmd($instance));
      $map->register("lives", new LivesCmd($instance));
      $map->register("revive", new ReviveCmd($instance));
      $map->register("reclaim", new ReclaimCmd($instance));
      $map->register("staffmode", new StaffmodeCmd($instance));
      $map->register("staffteleport", new StaffTeleportCmd($instance));
      //////////////////// Factions ////////////////////
      
      //////////////////// Misc ////////////////////
      $map->register("chat", new ChatCmd($instance));
      $map->register("keys", new KeysCmd($instance));
      $map->register("repair", new RepairCmd($instance));
      $map->register("rename", new RenameCmd($instance));
      $map->register("alerts", new AlertsCmd($instance));
      $map->register("punish", new PunishCmd($instance));
      $map->register("kenzoball", new KenzoBallCmd($instance));
      $map->register("partneritem", new PartnerItemCmd($instance));
      $map->register("permissions", new PermissionsCmd($instance));
      $map->register("clearinventory", new ClearInvCmd($instance));
      //////////////////// Misc ////////////////////
      $log = $server->getLogger();
      $log->notice("Commands Registered");
   }
}
