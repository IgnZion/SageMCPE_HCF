<?php
declare(strict_types=1);
namespace hcf\commands;

use hcf\{
   AlpineCore, AlpinePlayer
};
use pocketmine\command\{
   CommandSender, PluginCommand
};
use pocketmine\Server;
use pocketmine\utils\TextFormat as TF;

class ClearInvCmd extends PluginCommand {
   /** @var AlpineCore */
   private $plugin;

   /**
     * ClearInvCmd constructor.
     *
     * @param AlpineCore $plugin
     */
   public function __construct(AlpineCore $plugin){
      parent::__construct("clearinventory", $plugin);
      $this->plugin = $plugin;
      $this->setPermission("core.cmd.clearinv");
      $this->setUsage("/clearinventory <inventory|armor|all>");
      $this->setDescription("Choose to clear your inventory, armor or everything at once!");
      $this->setAliases(["ci", "clearinv"]);
   }

   /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     */
   public function execute(CommandSender $sender, string $commandLabel, array $args){
      if(!$sender->hasPermission("core.cmd.clearinv")){
         $sender->sendMessage("§l§c»» §r§7You do not have the required permission to use this!");
         return;
      }
      if(empty($args)){
         $sender->sendMessage("§l§c»» §r§7Use '/clearinventory <inventory|armor|all>'");
         return;
      }
      if(isset($args[0])){
         if($args[0] == "inventory"){
            $sender->sendMessage("§l§a»» §r§7Your inventory has been cleared!");
            $sender->getInventory()->clearAll();
            return;
         }

         if($args[0] == "armor"){
            $sender->sendMessage("§l§a»» §r§7Your armor inventory has been cleared!");
            $sender->getArmorInventory()->clearAll();
            return;
         }

         if($args[0] == "all"){
            $sender->sendMessage("§l§a»» §r§7Both your inventories have been cleared!");
            $sender->getInventory()->clearAll();
            $sender->getArmorInventory()->clearAll();
            return;
         }
      }
   }
}