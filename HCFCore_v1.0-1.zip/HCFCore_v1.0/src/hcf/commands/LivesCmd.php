<?php
declare(strict_types=1);
namespace hcf\commands;

use hcf\{
   AlpineCore, AlpinePlayer
};
use pocketmine\command\{
   CommandSender, PluginCommand
};
use pocketmine\Server;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat as TF;

class LivesCmd extends PluginCommand {
   /** @var AlpineCore */
   private $plugin;

   /**
     * LivesCmd constructor.
     *
     * @param AlpineCore $plugin
     */
   public function __construct(AlpineCore $plugin){
      parent::__construct("lives", $plugin);
      $this->plugin = $plugin;
      $this->setPermission("core.lives");
      $this->setUsage("/lives <player> <set|add|remove|give> <amount>");
      $this->setDescription("PvP Timer command");
   }

   /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     */
   public function execute(CommandSender $sender, string $commandLabel, array $args){
      if(!isset($args[0]) || !isset($args[1]) || !isset($args[2])){
         $sender->sendMessage(TF::BOLD . TF::GREEN . "»»" . TF::RESET . TF::GRAY . " Your total lives are: " . TF::GREEN . $sender->getLives());
         $sender->sendMessage(TF::BOLD . TF::GREEN . "»»" . TF::RESET . TF::GRAY . " Please use /lives <player> <set|add|remove|give> <amount>");
      }
      
      if(isset($args[0]) && !isset($args[1]) && !isset($args[2])){
         $player = $this->plugin->getServer()->getPlayer($args[0]);
         if($player == null){
            $sender->sendMessage("§l§a»» §r§7That player is not online!");
            return;
         }
         $sender->sendMessage("§l§a»» §r§7" . $player->getName() . TF::GRAY . " has a total of " . TF::GREEN . $player->getLives() . TF::GRAY . " Lives");
      }
      
      if(isset($args[1])){
         switch($args[1]){
            case "set":
               $player = $this->plugin->getServer()->getPlayer($args[0]);
               if(!$sender->hasPermission("core.lives.set")){
                  $sender->sendMessage("§l§a»» §r§7That command is for staff only!");
                  return;
               }
               if($player == null){
                  $sender->sendMessage("§l§a»» §r§7That player is not online!");
                  return;
               }
               if(is_numeric($args[2])){
                  $player->setLives((int) $args[2]);
                  $player->sendMessage("§l§a»» §r§7Your lives have been set to " . TF::GREEN . $args[2]);
                  $sender->sendMessage("§l§a»» §r§7You have set " . TF::GREEN . $player->getName() . TF::GRAY . " lives to " . TF::GREEN . $args[2]);
               } else {
                  $sender->sendMessage("§l§c»» §r§7Please insert a numeric number!");
               }
            break;

            case "add":
               $player = $this->plugin->getServer()->getPlayer($args[0]);
               if(!$sender->hasPermission("core.lives.add")){
                  $sender->sendMessage("§l§a»» §r§7That command is for staff only!");
                  return;
               }
               if($player == null){
                  $sender->sendMessage("§l§a»» §r§7That player is not online!");
                  return;
               }
               if(is_numeric($args[2])){
                  $player->setLives($player->getLives() + (int) $args[2]);
                  $player->sendMessage("§l§a»» §r§7New Lives have been added to your account: " . TF::GREEN . $args[2]);
                  $sender->sendMessage("§l§a»» §r§7You have added " . TF::GREEN . $args[2] . TF::GRAY . " lives to " . TF::GREEN . $player->getName());
               } else {
                  $sender->sendMessage("§l§c»» §r§7Please insert a numeric number!");
               }
            break;
            
            case "remove":
               $player = $this->plugin->getServer()->getPlayer($args[0]);
               if(!$sender->hasPermission("core.lives.remove")){
                  $sender->sendMessage("§l§a»» §r§7That command is for staff only!");
                  return;
               }
               if($player == null){
                  $sender->sendMessage("§l§a»» §r§7That player is not online!");
                  return;
               }
               if(is_numeric($args[2])){
                  $player->setLives($player->getLives() - (int) $args[2]);
                  $player->sendMessage("§l§a»» §r§7New Lives have been removed to your account: " . TF::GREEN . $args[2]);
                  $sender->sendMessage("§l§a»» §r§7You have removed " . TF::GREEN . $args[2] . TF::GRAY . " lives to " . TF::GREEN . $player->getName());
               } else {
                  $sender->sendMessage("§l§c»» §r§7Please insert a numeric number!");
               }
            break;
            
            case "give":
               $player = $this->plugin->getServer()->getPlayer($args[0]);
               if($player == null){
                  $sender->sendMessage("§l§a»» §r§7That player is not online!");
                  return;
               }
               if(is_numeric($args[2])){
                  if($player->getLives() >= $args[2]){
                     $player->setLives($player->getLives() + $args[2]);
                     $sender->setLives($sender->getLives() - $args[2]);
                     $player->sendMessage("§l§a»» §r§a" . $args[2] . TF::GRAY . " Lives have been given to you by " . TF::GREEN . $sender->getName());
                     $sender->sendMessage("§l§a»» §r§7You have given " . TF::GREEN . $args[2] . TF::GRAY . " lives to " . TF::GREEN . $player->getName());
                  } else {
                     $sender->sendMessage("§l§c»» §r§7Please insert a number below or equal to your total lives!");
                  }
               } else {
                  $sender->sendMessage("§l§c»» §r§7Please insert a numeric number!");
               }
            break;
         }
      }
   }
}
