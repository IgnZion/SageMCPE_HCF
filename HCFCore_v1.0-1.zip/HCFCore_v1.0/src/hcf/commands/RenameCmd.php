<?php
declare(strict_types=1);
namespace hcf\commands;

use hcf\{AlpineCore, AlpinePlayer};
use pocketmine\command\{CommandSender, PluginCommand};
use pocketmine\Server;
use pocketmine\utils\TextFormat as TF;

class RenameCmd extends PluginCommand {
    /** @var AlpineCore */
    private $plugin;

    /**
     * PayCmd constructor.
     *
     * @param AlpineCore $plugin
     */
    public function __construct(AlpineCore $plugin){
        parent::__construct("rename", $plugin);
        $this->plugin = $plugin;
        $this->setPermission("core.pay");
        $this->setUsage("/rename");
        $this->setDescription("Rename your items");
   }

   /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     */
    public function execute(CommandSender $sender, string $commandLabel, array $args){
        if(!$sender instanceof AlpinePlayer){
            $sender->sendMessage(TF::BOLD . TF::RED . "»» " . TF::RESET . TF::GRAY . "Only Alpine Players can use this command!");
            return;
        }
        $rank = $sender->getRank();
        if($rank == "Player"){
            $item = $sender->getInventory()->getItemInHand();
            if(isset($args[0])){
                $name = $args[0];
                $balance = (int) $sender->getBalance();
                if($balance >= 500){
                    $sender->reduceMoney(500);
                    $item->setCustomName($name);
                    $sender->getInventory()->setItemInHand($item);
                    $sender->sendMessage(TF::RED . TF::BOLD . "»» " . TF::RESET . TF::GRAY . "Your item has been renamed to " . $name . "!" . TF::RESET);
                } else {
                    $sender->sendMessage(TF::BOLD . TF::RED . "»» " . TF::RESET . TF::GRAY . "You do not have enough money to rename!");
                }
            } else {
                $sender->sendMessage(TF::BOLD . TF::RED . "»» " . TF::RESET . TF::GRAY . "You must input a name to rename!");
            }
        } else {
            $item = $sender->getInventory()->getItemInHand();
            if(isset($args[0])){
                $name = $args[0];
                $balance = (int) $sender->getBalance();
                if($balance >= 250){
                    $sender->reduceMoney(250);
                    $item->setCustomName($name);
                    $sender->getInventory()->setItemInHand($item);
                    $sender->sendMessage(TF::RED . TF::BOLD . "»» " . TF::RESET . TF::GRAY . "Your item has been renamed to " . $name . "!" . TF::RESET);
                } else {
                    $sender->sendMessage(TF::BOLD . TF::RED . "»» " . TF::RESET . TF::GRAY . "You do not have enough money to rename!");
                }
            } else {
                $sender->sendMessage(TF::BOLD . TF::RED . "»» " . TF::RESET . TF::GRAY . "You must input a name to rename!");
            }
        }
    }
}