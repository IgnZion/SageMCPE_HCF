<?php
declare(strict_types=1);
namespace hcf\commands;

use hcf\{
    AlpineCore, AlpinePlayer, tasks\async\ReviveCheckTask
};
use pocketmine\command\{
    CommandSender, PluginCommand
};
use pocketmine\Server;

class ReviveCmd extends PluginCommand {
    /** @var AlpineLobby */
    private $plugin;

    /**
     * ReviveCmd constructor.
     *
     * @param AlpineCore $plugin
     */
    public function __construct(AlpineCore $plugin){
        parent::__construct("revive", $plugin);
        $this->plugin = $plugin;
        $this->setPermission("core.revive");
        $this->setUsage("/revive <player>");
        $this->setAliases(["re", "rev"]);
        $this->setDescription("Use /revive to revive yourself, /revive <player> to revive another player");
    }

    /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     */
    public function execute(CommandSender $sender, string $commandLabel, array $args){
        if(!isset($args[0])){
            $async = AlpineCore::getInstance()->getServer()->getAsyncPool();
            $async->submitTask(new ReviveCheckTask((string) $sender->getName(), (string) $sender->getName()));
        } else {
            $async = AlpineCore::getInstance()->getServer()->getAsyncPool();
            $async->submitTask(new ReviveCheckTask((string) $args[0], (string) $sender->getName()));
        }
    }
}