<?php
declare(strict_types=1);
namespace hcf\commands;

use hcf\{AlpineCore, AlpinePlayer, FactionsManager, tile\BrewingStand, utils\Utils, tasks\TeleportTask};
use pocketmine\item\Item;
use pocketmine\math\Vector3;
use pocketmine\command\{
   CommandSender, PluginCommand
};
use pocketmine\nbt\NBT;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\Server;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat as TF;

class FactionsCmd extends PluginCommand {
   /** @var AlpineCore */
   private $plugin;

   /**
     * FactionsCmd constructor.
     *
     * @param AlpineCore $plugin
     */
   public function __construct(AlpineCore $plugin){
      parent::__construct("f", $plugin);
      $this->plugin = $plugin;
      $this->setPermission("core.factions");
      $this->setUsage("/f <args>");
      $this->setDescription("Factions command!");
      $this->setAliases(["faction", "fac", "factions", "hcf"]);
   }

   /**
     * @param string $name
     * @return int
     */
   public function getPlayerKills(string $name): int {
      $db = AlpineCore::getInstance()->getPlayerDatabase();
      $data = $db->prepare("SELECT kills FROM hcfdata WHERE username=?");
      $data->bind_param("s", $name);
      $data->bind_result($kills);
      $data->execute();
      while($data->fetch()){
         return (int) $kills;
      }
      $data->close();
   }

   /**
     * @return array
     */
   public function getHelp(): array {
      $help = [
         "/f tl",
         "/f create <name>",
         "/f disband",
         "/f leave",
         "/f accept | deny",
         "/f claim | unclaim",
         "/f sethome", 
         "/f home", // 
         "/f stuck", // 
         "/f balance",
         "/f who <player>",
         "/f info <faction>",
         "/f withdraw <amount>",
         "/f deposit <amount>",
         "/f invite <name>",
         "/f kick <name>",
         "/f leader <faction>",
         "/f members",
         "/f chat",
         "/f forcekick <player>",
         "/f forcedelete <faction>",
         "/f freeze <faction>",
         "/f dtr <faction> <amount>"
      ];
      return $help;
   }

   /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     */
   public function execute(CommandSender $sender, string $commandLabel, array $args){
      $svr = AlpineCore::getInstance();
      $mgr = AlpineCore::getFactionsManager();
      if($sender instanceof AlpinePlayer){
         if(!isset($args[0])){
            $sender->sendMessage("§l§c»» §r§7Invalid arguments, use command /f help to see the commands.");
            return;
         }
         switch(strtolower($args[0])){
            case "help":
            case "?":
               $sender->sendMessage("§l§a»» §r§7Faction Commands List!");
               foreach($this->getHelp() as $help){
                  $sender->sendMessage("§l§a * §r§7 " . $help);
                  $brewing = new BrewingStand();
                  $brewing->sendMenu($sender);
               }
               break;

            case "home":
               if(!$sender->isInFaction()){
                  $sender->sendMessage("§l§c»» §r§7You must be in a faction to do that!");
                  return;
               }
               if(!$mgr->isHome($sender->getFaction())){
                  $sender->sendMessage("§l§c»» §r§7Your faction doesn't have a home set!");
                  return;
               }
               if($mgr->isClaim($sender, $sender->getLevel())){
                  $x = (int) $sender->getX();
                  $z = (int) $sender->getZ();
                  if($mgr->getClaimer($x, $z) != $sender->getFaction()){
                     $sender->sendMessage("§l§c»» §r§7You cannot f home in another's faction base!");
                     return;
                  }
               }
               if($sender->isPvP()){
                  $sender->sendMessage("§l§c»» §r§7You cannot teleport home when on PvPTimer!");
                  return;
               }
               if($sender->isTeleporting()){
                  $sender->sendMessage("§l§c»» §r§7You are already teleporting!!");
                  return;
               }
               if($sender->isArcherTagged()){
                  $sender->sendMessage("§l§c»» §r§7You cannot teleport whilst in combat");
                  return;
               }
               if($sender->isSpawnTagged()){
                  $sender->sendMessage("§l§c»» §r§7You cannot teleport whilst in combat");
                  return;
               }
               $h = AlpinePlayer::HOME;
               $fac = $sender->getFaction();
               $sender->sendMessage("§l§a»» §r§7You will be teleported to your Faction's home in 10 seconds! Don't Move!");
               $sender->setTeleport($h);
               $sender->setTeleporting(true);
               $currentpos = new Vector3((int) $sender->getX(), (int) $sender->getY(), (int) $sender->getZ());
               $sender->setTeleportTask(new TeleportTask(AlpineCore::getInstance(), $sender, "§l§a»» §r§7You have been teleported to your faction's home successfully!", 10, $mgr->getHome($fac), $currentpos));
               break;

            case "stuck":
               if($sender->isTeleporting()){
                  $sender->sendMessage("§l§c»» §r§7You are already teleporting!!");
                  return;
               }
               if($sender->isPvP()){
                  $sender->sendMessage("§l§c»» §r§7You cannot teleport whilst on PvPTimer!");
                  return;
               }
               if($mgr->isClaim($sender, $sender->getLevel())){
                  if($sender->isInFaction()){
                     $x = (int) $sender->getX();
                     $z = (int) $sender->getZ();
                     if($mgr->getClaimer($x, $z) == $sender->getFaction()){
                        $sender->sendMessage("" . "§l§c»» §r§7You cannot teleport whilst on your claim!");
                        return;
                     }
                  }
               }
               $h = AlpinePlayer::STUCK;
               if($mgr->isClaim($sender, $sender->getLevel())){
                  $x = (int) $sender->getX();
                  $z = (int) $sender->getZ();
                  $db = $mgr->getDb();
                  $result = $db->query("SELECT * FROM claims WHERE $x <= x1 AND $x >= x2 AND $z <= z1 AND $z >= z2;");
                  $array = $result->fetchArray(SQLITE3_ASSOC);
                  $y = $sender->getLevel()->getHighestBlockAt((int) $array["x1"], (int) $array["z1"]);
                  $pos = new Vector3($array["x1"] + 1, $y + 4, $array["z1"] + 1);
                  $sender->sendMessage("" . "§l§a»» §r§7You will be teleported outside this base in 60 seconds! Don't Move!");
                  $sender->setTeleport($h);
                  $sender->setTeleporting(true);
                  $currentpos = new Vector3((int) $sender->getX(), (int) $sender->getY(), (int) $sender->getZ());
                  $sender->setTeleportTask(new TeleportTask(AlpineCore::getInstance(), $sender, "§l§a»» §r§7You have been teleported outside this base!", 60, $pos, $currentpos));
               } else $sender->sendMessage("" . "§l§c»» §r§7You cannot f stuck when not on claimed land!");
               break;

            case "forcejoin":
               if(isset($args[1])){
                  $l = $args[1];
                  if($mgr->isFaction($l)){
                    $members = count($mgr->getMembers($l));
                     if($sender->hasPermission("core.facs.forcejoin")){
                        if(!$sender->isInFaction()){
                           if($members < 5){
                              $sender->addToFaction($l);
                              $sender->sendMessage("" . "§l§a»» §r§7You force joined " . $l);
                           } else $sender->sendMessage("" . "§l§c»» §r§7That faction is already full!");
                        } else $sender->sendMessage("" . "§l§c»» §r§7You must leave your current faction to join!");
                     } else $sender->sendMessage("" . "§l§c»» §r§7You must be op to run this command!");
                  } else $sender->sendMessage("" . "§l§c»» §r§7That faction does not exist!");
               } else $sender->sendMessage("" . "§l§c»» §r§7Use /f forcejoin <faction>");
            break;

            case "accept":
               if($sender->isInvited()){
                  $f = $sender->getLastInvite();
                  if($sender->getInvitedTimeLeft() <= 0){
                     $sender->setInvited(false);
                     $sender->sendMessage("§c§l»» §r§7The invitation by " . $f . " has expired! Ask again if you wish to join!");
                     return;
                  }
                  if(count($mgr->getTotalMembers($f)) < 5){
                     $sender->addToFaction($f);
                     $sender->setInvited(false);
                     foreach ($mgr->getOnlineMembers($f) as $online){
                        $online->sendMessage("" . "§a§l»» §r§7" . $sender->getName() . " has joined your faction!");
                     }
                  } else {
                     $sender->sendMessage("§c§l»» §r§7The faction is already full!");
                  }
               } else {
                  $sender->sendMessage("§c§l»» §r§7You have no active request!");
               }
               break;

            case "deny":
               if($sender->isInvited()){
                  $f = $sender->getLastInvite();
                  $sender->setInvited(false);
                  foreach ($mgr->getOnlineMembers($f) as $online){
                        $online->sendMessage("" . "§a§l»» §r§7" . $sender->getName() . " has denied joining your faction!");
                  }
               } else {
                  $sender->sendMessage("§c§l»» §r§7You have no active request!");
               }
               break;

            case "invite":
               if(isset($args[1])){
                  if(!$sender->isInFaction()) return;
                     if($mgr->getLeader($sender->getFaction()) == $sender->getName() || $mgr->isOfficer($sender->getFaction(), $sender->getName())){
                        $fac = $sender->getFaction();
                        $svr = $this->plugin->getServer();
                        $who = $svr->getPlayer($args[1]);
                        if($who instanceof AlpinePlayer){
                           if($who->isInFaction()){
                              $sender->sendMessage("" . "§l§c»» §r§7That player is currently in a faction");
                              return;
                           }
                           if($who->isInvited()){
                              if($who->getInvitedTimeLeft() <= 0){
                                 $who->setInvited(false);
                              } else {
                                 $sender->sendMessage("" . "§c§l»» §r§7The player is currently invited by another faction! Wait a few seconds!");
                              }
                           } else {
                              $who->setInvited(true);
                              $who->setLastInvite($fac);
                              $who->setInvitedTime(20);
                              $who->sendMessage("§l§a»» §r§7You have been invited to §a" . $fac . "§7 by §a" . $sender->getName() . "§7 Type /f accept | deny to deny or join the faction!");
                              $sender->sendMessage("§l§a»» §r§7You have invited §a" . $who->getName() . "§7 to join the faction!");
                           }
                        } else {
                           $sender->sendMessage("§l§c»» §r§7That player isn't online currently!");
                     }
                  } else {
                     $sender->sendMessage("§l§c»» §r§7You do not have the sufficient rank to invite members to your faction!");
                  }
               } else {
                  $sender->sendMessage("§l§c»» §r§7Please input a users name to invite");
               }
               break;

            case "tl":
               if($sender->isInFaction()){
                  $f = $sender->getFaction();
                  foreach ($mgr->getOnlineMembers($f) as $online){
                        $online->sendMessage("❌" . TF::BOLD . TF::GRAY . "(" . TF::GREEN . $f . TF::GRAY . ") " . TF::WHITE . $sender->getName() . " needs help! Their coords are X: §a". $sender->getFloorX() . TF::WHITE . " Y: §a" . $sender->getFloorY() . TF::WHITE . " Z: §a" . $sender->getFloorZ());
                  }
               } else $sender->sendMessage("" . "§c§l»» §r§7You must be in a faction to do this action!!");
               break;

            case "info":
               if(isset($args[1])){
                  if($mgr->isFaction($args[1])){
                     $f = $args[1];
                     $dtr = $mgr->getDTR($f);
                     $max = $mgr->getMaxDTR($f);
                     $leader = $mgr->getLeader($f);
                     $leaderkills = $this->getPlayerKills($leader);
                     $points = $mgr->getPoints($f);
                     $coords = "Not Set";
                     if($mgr->isHome($f)){
                        $home = $mgr->getHome($f);
                        $coords = $home->getX() . ", " . $home->getY() . ", " . $home->getZ();
                     }
                     $count = count($mgr->getMembers($f));
                     $online = $mgr->getOnlineMembers($f);
                     $onlines = "";
                     if(count($online) > 0){
                        foreach($online as $player){
                           $okills = $player->getKills();
                           $onlines .= TF::GREEN . $player->getName() . TF::GOLD . " [" . $okills . "]" . TF::RESET . TF::GRAY . ", ";
                        }
                     } else {
                        $onlines = "None";
                     }
                     $ms = $mgr->getMembers($f);
                     $members = "";
                     if(count($ms) > 0){
                        foreach($ms as $member){
                           $members .= TF::GRAY . $member . TF::RESET . TF::GRAY . ", ";
                        }
                     } else {
                        $members = "none";
                     }
                     $os = $mgr->getOfficers($f);
                     $officers = "";
                     if(count($os) > 0){
                        foreach($os as $officer){
                           $officers .= TF::GRAY . $officer . TF::RESET . TF::GRAY . ", ";
                        }
                     } else {
                        $officers = "none";
                     }
                     $isfrozen = false;
                     $frozentime = 0;
                     if($mgr->isFrozen($f)){
                        $isfrozen = true;
                        $frozentime = $mgr->getFrozenTimeLeft($f);
                     }
                     $sender->sendMessage("" . TF::GOLD . TF::BOLD . "---------------------");
                     $sender->sendMessage("" . TF::RED . $f . TF::GRAY . "(" . $count . "/4)" . TF::GOLD . " | " . TF::YELLOW . "Home: " . TF::RED . $coords);
                     $sender->sendMessage(" " . TF::YELLOW . "Leader: " . TF::GREEN . $leader . TF::GOLD . "[" . $leaderkills . "]");
                     $sender->sendMessage(" " . TF::YELLOW . "Online: " . $onlines);
                     $sender->sendMessage(" " . TF::YELLOW . "Officers: " . $officers);
                     $sender->sendMessage(" " . TF::YELLOW . "Members: " . $members);
                     $sender->sendMessage(" " . TF::YELLOW . "Balance: " . TF::GREEN . "$" . $mgr->getBalance($f));
                     if($dtr <= 0.9){
                        $sender->sendMessage(" " . TF::YELLOW . "DTR: §c" . $dtr . "/" . $max);
                     } else {
                        $sender->sendMessage(" " . TF::YELLOW . "DTR: §a" . $dtr . "/" . $max);
                     }
                     if($isfrozen){
                        $sender->sendMessage(" " . TF::YELLOW . "DTR Freeze: " . TF::RED . Utils::IntToString($frozentime));
                     }
                     $sender->sendMessage(" " . TF::YELLOW . "Points: §7" . $points);
                     $sender->sendMessage("" . TF::GOLD . TF::BOLD . "---------------------");
                  } else {
                  $sender->sendMessage("§l§c»» §r§7That is not currently a faction!");
                  }
               }
               break;

            case "freeze":
               if(isset($args[1]) && $sender->hasPermission("core.facs.freeze")){
                  if($mgr->isFaction($args[1])){
                     $mgr->setFrozenTime($args[1], time() + (60 * 30));
                  }
               }
               break;

            case "dtr":
               if(isset($args[1])){
                  if($sender->hasPermission("core.facs.setdtr")){
                     if($mgr->isFaction($args[1])){
                        $mgr->setDTR($args[1], floatval($args[2]));
                        $sender->sendMessage("" . "§l§c»» §r§7You have set " . $args[1] . " DTR to " . $args[2] . "!");
                     }
                  }
               }
               break;
               case "unclaim":
                  if($sender->isInFaction()){
                     $db = $mgr->getDb();
                     $fac = $sender->getFaction();
                     $result = $db->query("SELECT * FROM claims WHERE faction = '$fac';");
                     $array = $result->fetchArray(SQLITE3_ASSOC);
                     if(!empty($array)) {
                        if($mgr->getLeader($fac) == $sender->getName()){
                           $db->exec("DELETE FROM claims WHERE faction = '$fac';");
                           $sender->sendMessage("" . "§a§l»» §r§7Your claim has been deleted!");
                        } else {
                        $sender->sendMessage("" . "§l§c»» §r§7You must be leader to unclaim!");
                        }
                     } else {
                     $sender->sendMessage("§l§c»» §r§7You do not have a claim to delete!");
                     }
                  } else {
                  $sender->sendMessage("§l§c»» §r§7You must be in a faction to do that!");
                  }
               break;
               case "claim":
                  if($sender->isInFaction()){
                     $fac = $sender->getFaction();
                     if($mgr->getDtr($fac) > 0.1){
                        if($mgr->getLeader($fac) == $sender->getName()){
                           if($sender->getLevel() == AlpineCore::$overworldLevel){
                               $sender->setClaim(false);
                               $sender->setClaiming(true);
                               $sender->setStep(AlpinePlayer::FIRST);
                               $wand = Item::get(Item::DIAMOND_HOE);
                               $wand->setCustomName(TF::BOLD . TF::GREEN . "Claiming" . TF::GRAY . " Wand");
                               $sender->getInventory()->addItem($wand);
                               $sender->sendMessage("" . "§a§l»» §r§7Please select your first location by tapping a block");
                            } else {
                               $sender->sendMessage("" . "§l§c»» §r§7You can only claim in the overworld!");
                            }
                        } else {
                            $sender->sendMessage("" . "§l§c»» §r§7You must be leader to claim!");
                        }
                     } else {
                         $sender->sendMessage("§l§c»» §r§7Your faction DTR is too low to be able to claim!");
                     }
                  } else {
                      $sender->sendMessage("§l§c»» §r§7You must be in a faction to do that!");
                  }
               break;

            case "make":
            case "create": 
               if(!$sender->isInFaction()){
                  if(isset($args[1])){
                     if(strlen($args[1]) < 10){
                        if(ctype_alnum($args[1])){
                           $fac = $args[1];
                           $mgr->createFaction($fac, $sender);
                        } else {
                        $sender->sendMessage("". "§l§c»» §r§7You can only use letters and numbers as a faction name.");
                        }
                     } else {
                     $sender->sendMessage("§l§c»» §r§7That name is too long!");
                     }
                   } else {
                   $sender->sendMessage("§l§c»» §r§7Please input a name for your Faction.");
                  }
               } else {
               $sender->sendMessage("§l§c»» §r§7You are already in a faction, use /f leave  if you wish to create a faction.");
               }
               break;

            case "delete":
            case "disband":
               if($sender->isInFaction()){
                  $fac = $sender->getFaction();
                  if($mgr->getLeader($fac) == $sender->getName()){
                     if(!$mgr->isFrozen($fac)){
                        foreach ($mgr->getOnlineMembers($fac) as $member){
                          $member->sendMessage("" . "§l§c»» §r§7The Faction has been disbanded by the leader!");
                        }
                        $mgr->disbandFaction($fac);
                     } else {
                     $sender->sendMessage("" . "§l§c»» §r§7You cannot disband faction on DTR Freeze");
                     }
                  } else {
                  $sender->sendMessage("§l§c»» §r§7You must be leader to delete faction!");
                  }
               } else {
               $sender->sendMessage("§l§c»» §r§7You must be in a faction to do that!");
               }
               break;

            case "leave":
            case "quit":
               if($sender->isInFaction()){
                  $faction = $sender->getFaction();
                  if($mgr->getLeader($faction) != $sender->getName()){
                     $dtr = $mgr->getDTR($faction);
                     $mgr->setDTR($faction, $dtr - 0.5);
                     foreach ($mgr->getOnlineMembers($faction) as $member){
                       $member->sendMessage("" . "§l§c»» §r§7" . $sender->getName() . " has left your faction!");
                     }
                     $sender->removeFromFaction();
                     $sender->sendMessage("§l§a»» §r§7You successfully left your faction!");
                  } else {
                  $sender->sendMessage("§l§c»» §r§7You cannot leave as the leader.");
                  }
               } else {
                  $sender->sendMessage("§l§c»» §r§7You must be in a faction to do that!");
               }
               break;

            case "balance":
               if($sender->isInFaction()){
                  $faction = $sender->getFaction();
                  $sender->sendMessage("§l§a»» §r§7Your Factions balance is: §a$" . $mgr->getBalance($faction));
               } else {
               $sender->sendMessage("§l§c»» §r§7You must be in a faction to use this.");
               }
               break;

            case "deposit":
            case "d":
               if($sender->isInFaction()){
                  $faction = $sender->getFaction();
                  if(isset($args[1])){
                     $l = $args[1];
                     if($l === "all" || $l === "a"){
                        $bal = $sender->getBalance();
                        $mgr->addBalance($faction, $sender->getBalance());
                        $sender->reduceMoney($bal);
                        $sender->sendMessage("" . "§l§a»» §r§7You donated §a$" . $bal . " §7to your factions bank!");
                        return;
                     }
                     if(is_numeric($l)){
                        if($sender->getBalance() >= $l){
                           $mgr->addBalance($faction, (int) $l);
                           $sender->reduceMoney((int) $l);
                           $sender->sendMessage("" . "§l§a»» §r§7You donated §a$" . $l . " §7to your faction!");
                        } else {
                        $sender->sendMessage("" . "§l§c»» §r§7You do not have enough money to donate!");
                        }
                     } else {
                     $sender->sendMessage("§l§c»» §r§7You must choose a valid number!");
                     }
                  } else {
                  $sender->sendMessage("§l§c»» §r§7Invalid arguments! /f d <amount>");
                  }
               } else {
               $sender->sendMessage("§l§c»» §r§7You must be in a faction to donate!");
               }
               break;

            case "chat":
            case "c":
               if($sender->isInFaction()){
                  if($sender->getChat() == AlpinePlayer::PUBLIC){
                     $sender->sendMessage("§l§a»» §r§7You have now been set to factions chat!");
                     $sender->setChat(AlpinePlayer::FACTION);
                  } else {
                  $sender->sendMessage("§l§a»» §r§7You have now been set to public chat!");
                  $sender->setChat(AlpinePlayer::PUBLIC);
                  }
               } else {
               $sender->sendMessage("§l§a»» §r§7You have now been set to factions chat!");
               }
               break;

            case "who":
               if(isset($args[1])){
                  $svr = $this->plugin->getServer();
                  $who = $svr->getPlayer($args[1]);
                  if($who instanceof AlpinePlayer){
                     if($who->isInFaction()){
                        $sender->sendMessage("" . "§l§a»» §r§7" . $who->getName() . "'s faction is " . $who->getFaction());
                     } else {
                     $sender->sendMessage("§l§c»» §r§7" . $who->getName() . " is not in a faction!");
                     }
                  } else {
                 $sender->sendMessage("§l§c»» §r§7That player is not online!");
                  }
               } else {
               $sender->sendMessage("§l§c»» §r§7Usage: /f who <player name>!");
               }
               break;

            case "withdraw":
               if($sender->isInFaction()){
                  $faction = $sender->getFaction();
                  if($mgr->getLeader($faction) == $sender->getName() || $mgr->isOfficer($faction, $sender->getName())){
                     if(isset($args[1])){
                        $l = $args[1];
                        if(is_numeric($l)){
                           $bal = $mgr->getBalance($faction);
                            if($bal >= $l){
                              $mgr->reduceBalance($faction, (int) $l);
                              $sender->addMoney((int) $l);
                              $sender->sendMessage("" . "§l§a»» §r§7You took §a$" . $l . " §7from your faction!");

                           } else {
                           $sender->sendMessage("" . "§l§c»» §r§7You do not have enough money in your faction bank!");
                           }
                        } else {
                       $sender->sendMessage("" . "§l§c»» §r§7You must choose a valid number!");
                        }
                     } else {
                     $sender->sendMessage("§l§c»» §r§7Invalid arguments! /f d <amount>");
                     }
                  } else {
                  $sender->sendMessage("§l§c»» §r§7You must be leader to withdraw!");
                  }
               } else {
               $sender->sendMessage("§l§c»» §r§7You must be in a faction to use that!");
               }
               break;

            case "members":
               if($sender->isInFaction()){
                  $faction = $sender->getFaction();
                  $members = $mgr->getMembers($faction);
                  $text = "";
                  foreach($members as $mem){
                     $text .= $mem . ", ";
                  }
                  $sender->sendMessage("§l§a»» §r§7Your faction members are: " . $text);
               } else {
               $sender->sendMessage("§l§c»» §r§7You must be in a faction to do that!");
               }
               break;

            case "kick":
               if($sender->isInFaction()){
                  $faction = $sender->getFaction();
                  if($mgr->getLeader($faction) == $sender->getName()){
                     if(isset($args[1])){
                        if($mgr->isMember($faction, $args[1]) || $mgr->isOfficer($faction, $args[1])){
                           $mgr->kick($args[1]);
                           $sender->sendMessage("" . "§l§a»» §r§7You successfully kicked " . $args[1] . " from your faction!");
                        } else {
                        $sender->sendMessage("" . "§l§c»» §r§7That player is not in your faction! Please right player full name!");
                        }
                      } else {
                      $sender->sendMessage("§l§c»» §r§7Please select a player to kick! /f kick <player name>!");
                     }
                  } else {
                  $sender->sendMessage("§l§c»» §r§7You must be faction leader to do that!");
                  }
               } else {
               $sender->sendMessage("§l§c»» §r§7You must be in a faction to do that!");
               }
               break;

            case "demote":
               if($sender->isInFaction()){
                  $faction = $sender->getFaction();
                  if($mgr->getLeader($faction) == $sender->getName()){
                     if(isset($args[1])){
                        $player = $this->plugin->getServer()->getPlayer($args[1]);
                        $name = $player->getName();
                        if($player instanceof AlpinePlayer){
                           if($mgr->isOfficer($faction, $name)){
                              $mgr->setMember($faction, $name);
                              $sender->sendMessage("" . "§l§a»» §r§7You have deomoted player!");
                              $player->sendMessage("" . "§l§a»» §r§7You have been demoted to Member of this faction!");
                           } else {
                           $sender->sendMessage("" . "§l§c»» §r§7That player cannot be deomoted!");
                           }
                        } else {
                        $sender->sendMessage("" . "§l§c»» §r§7That player is not online!");
                        }
                     } else {
                     $sender->sendMessage("§l§c»» §r§7You must select a player! /f promote <player name>");
                     }
                  } else {
                  $sender->sendMessage("§l§c»» §r§7You are not leader of faction!");
                  }
               } else {
               $sender->sendMessage("§l§c»» §r§7You must be in a faction to do this!");
               }
               break;

            case "promote":
               if($sender->isInFaction()){
                  $faction = $sender->getFaction();
                  if($mgr->getLeader($faction) == $sender->getName()){
                     if(isset($args[1])){
                        $player = $this->plugin->getServer()->getPlayer($args[1]);
                        if($player != null) $name = $player->getName();
                        if($player instanceof AlpinePlayer){
                           if($mgr->isMember($faction, $name)){
                              $mgr->setOfficer($faction, $name);
                              $sender->sendMessage("" . "§l§a»» §r§7You have promoted player!");
                              $player->sendMessage("" . "§l§a»» §r§7You have been promoted to Officer of this faction!");
                           } else {
                           $sender->sendMessage("" . "§l§c»» §r§7That player cannot be promoted!");
                           }
                        } else {
                        $sender->sendMessage("" . "§l§c»» §r§7That player is not online!");
                        }
                     } else {
                     $sender->sendMessage("§l§c»» §r§7You must select a player! /f promote <player name>");
                     }
                  } else {
                  $sender->sendMessage("§l§c»» §r§7You are not leader of faction!");
                  }
               } else {
               $sender->sendMessage("§l§c»» §r§7You must be in a faction to do this!");
               }
               break;

            case "leader":
               if($sender->isInFaction()){
                  $faction = $sender->getFaction();
                  if($mgr->getLeader($faction) == $sender->getName()){
                     if(isset($args[1])){
                        $player = $this->plugin->getServer()->getPlayer($args[1]);
                        if($player != null){
                            $name = $player->getName();
                        } else {
                            $name = $args[1];
                        }
                        if($player instanceof AlpinePlayer){
                           if($mgr->isMember($faction, $name) || $mgr->isOfficer($faction, $name)){
                              $sender->addToFaction($faction, FactionsManager::OFFICER);
                              $player->addToFaction($faction, FactionsManager::LEADER);
                              $sender->sendMessage("" . "§l§a»» §r§7You have selected a new leader and you turned to co leader!");
                              $player->sendMessage("" . "§l§a»» §r§7You have been set to the leader of your faction!");
                           } else {
                           $sender->sendMessage("" . "§l§c»» §r§7That player is not in your faction!");
                           }
                        } else {
                        $sender->sendMessage("" . "§l§c»» §r§7That player is not online!");
                        }
                     } else {
                     $sender->sendMessage("§l§c»» §r§7You must select a player! /f leader <player name>");
                     }
                  } else {
                  $sender->sendMessage("§l§c»» §r§7You are not leader of faction!");
                  }
               } else {
               $sender->sendMessage("§l§c»» §r§7You must be in a faction to do this!");
               }
               break;

            case "forcekick":
               if($sender->hasPermission("core.facs.forcekick")){
                  if(isset($args[1])){
                     $s = $this->plugin->getServer();
                     $wh = $s->getPlayer($args[1]);
                     if($wh->isInFaction()){
                        $mgr->kick($wh->getName());
                        $sender->sendMessage("" . "§l§a»» §r§7You successfully force kicked " . $wh->getName() . " from their faction!");
                     } else {
                     $sender->sendMessage("§l§c»» §r§7That player is not in a faction!");
                     }
                  } else {
                  $sender->sendMessage("§l§c»» §r§7You did not choose a name to kick! Args: /f forcekick <player>!");
                  }
               } else {
               $sender->sendMessage("§l§c»» §r§7Only staff can use that command!");
               }
               break;

            case "sethome":
               if($sender->isInFaction()){
                  $fac = $sender->getFaction();
                  if($mgr->getLeader($fac) == $sender->getName()){
                     $x = (int) $sender->getX();
                     $z = (int) $sender->getZ();
                     if(!$sender->isPvP()){
                        if($sender->isInClaim()){
                           if($mgr->getClaimer($x, $z) == $sender->getFaction()){
                              if($sender->getLevel() == AlpineCore::$overworldLevel){
                                 $mgr->setHome($fac, $sender);
                                 $sender->sendMessage("" . "§l§a»» §r§7Your Faction's Home has successfully been updated!");
                              } else {
                                 $sender->sendMessage("" . "§l§c»» §r§7You can only sethome in overworld!");
                              }
                           } else {
                           $sender->sendMessage("" . "§l§c»» §r§7You cannot set your faction's home outside your claim!");
                           }
                        } else {
                        $sender->sendMessage("" . "§l§c»» §r§7You are currently not located in your claim!");
                        }
                     } else {
                     $sender->sendMessage("" . "§l§c»» §r§7You are currently in pvptimer and cannot set your faction's home!");
                     }
                  } else {
                  $sender->sendMessage("" . "§l§c»» §r§7You are not currently the leader of your faction so you cannot set home!");
                  }
               } else {
               $sender->sendMessage("" . "§l§c»» §r§7You must be in a faction to do that!");
               }
               break;

            case "forcedelete":
               if($sender->hasPermission("core.facs.forcedelete")){
                  if(isset($args[1])){
                     if($mgr->isFaction($args[1])){
                        $fac = $args[1];
                        $mgr->disbandFaction($fac);
                     } else {
                     $sender->sendMessage("" . "§l§c»» §r§7You must choose a faction that exists to the server.");
                     }
                  } else {
                  $sender->sendMessage("§l§c»» §r§7You must do: /f forcedelete <faction>");
                  }
               } else {
               $sender->sendMessage("§l§c»» §r§7You must be a staff to do that!");
               }
               break;
               }
      } else {
          echo "Join Server God Damn it";
      }
   }
}
