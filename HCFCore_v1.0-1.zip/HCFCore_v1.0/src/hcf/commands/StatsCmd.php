<?php
declare(strict_types=1);
namespace hcf\commands;

use hcf\{
   AlpineCore, AlpinePlayer
};
use pocketmine\command\{
   CommandSender, PluginCommand
};
use pocketmine\Server;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat as TF;

class StatsCmd extends PluginCommand {
   /** @var AlpineCore */
   private $plugin;

   /**
     * StatsCmd constructor.
     *
     * @param AlpineCore $plugin
     */
   public function __construct(AlpineCore $plugin){
      parent::__construct("stats", $plugin);
      $this->plugin = $plugin;
      $this->setPermission("core.stats");
      $this->setUsage("/stats <pvp | mining>");
      $this->setDescription("Shows your PvP | Mining stats!");
   }

   /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     */
   public function execute(CommandSender $sender, string $commandLabel, array $args){
      if($sender instanceof AlpinePlayer){
         $kills = $sender->getKills();
         $deaths = $sender->getDeaths();

         if(isset($args[0])){
            switch($args[0]){
               case "pvp":
                  $sender->sendMessage("§l" . TF::AQUA . "»»»»»» " . TF::RESET . "§7PvP Stats" . TF::BOLD . TF::AQUA . " ««««««" . TF::RESET . "\n" . TF::GRAY . "Kills: §a" . $kills . "§r\n§7Deaths: §c" . $deaths . "§r\n§l" . TF::AQUA . "»»»»»» " . TF::RESET . "§7PvP Stats" . TF::BOLD . TF::AQUA . " ««««««§r");
               break;
            }
         } else {
         $sender->sendMessage(TF::BOLD . TF::RED . "»» " . TF::RESET . TF::GRAY . "Please use: /stats pvp>");
         }
      } else {
      $sender->sendMessage("NO CONSOLE");
      }
   }
}