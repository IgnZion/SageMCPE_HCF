<?php
declare(strict_types=1);
namespace hcf\commands;

use hcf\{
   AlpineCore, AlpinePlayer
};
use pocketmine\command\{
   CommandSender, PluginCommand
};
use pocketmine\Server;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat as TF;

class ReclaimCmd extends PluginCommand {
   /** @var AlpineCore */
   private $plugin;

   /**
     * ReclaimCmd constructor.
     *
     * @param AlpineCore $plugin
     */
   public function __construct(AlpineCore $plugin){
      parent::__construct("reclaim", $plugin);
      $this->plugin = $plugin;
      $this->setPermission("core.cmd.reclaim");
      $this->setUsage("/reclaim");
      $this->setDescription("Reclaim your keys and lives for your current rank! Only useable once per map!");
   }

   /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     */
   public function execute(CommandSender $sender, string $commandLabel, array $args){
       if(isset($args[0]) && isset($args[1])){
          $player = AlpineCore::getInstance()->getServer()->getPlayerExact($args[1]);
          if($sender->hasPermission("core.cmd.reclaim.reset") && $args[0] == "reset"){
              if($player instanceof AlpinePlayer){
                  $player->setReclaim(false);
                  $sender->sendMessage(TF::BOLD . TF::GREEN . "»» " . TF::RESET . TF::GRAY . $player->getName() . " reclaim has been reset so they can use it again!");
                  return;
              } else $sender->sendMessage(TF::BOLD . TF::RED . "»» " . TF::RESET . TF::GRAY . "Looks like that player is offline");
           }
       }
       $rank = strtolower($sender->getRank());
       if($sender instanceof AlpinePlayer){
           if($sender->usedReclaim() == true){
               $sender->sendMessage(TF::BOLD . TF::RED . "»» " . TF::RESET . TF::GRAY . "You already claimed your reclaim, if you think this an error contact available staff.");
               return;
           }
           if($sender->getRank() == "Player"){
               $sender->setReclaim(true);
               AlpineCore::getInstance()->getCratesManager()->giveKey($sender, 4, 3); //pioneer keys
               AlpineCore::getInstance()->getServer()->broadcastMessage("§l§a»» §r" . TF::GREEN . $sender->getName() . TF::GRAY . " redeemed their Default reclaim!");
               return;
           } elseif ($sender->hasPermission("core.reclaim.pioneer")){
               $sender->setReclaim(true);
               $sender->setLives($sender->getLives() + 10);
               AlpineCore::getInstance()->getCratesManager()->giveKey($sender, 4, 7); //pioneer keys
               AlpineCore::getInstance()->getCratesManager()->giveKey($sender, 3, 5); //voyager keys
               AlpineCore::getInstance()->getCratesManager()->giveKey($sender, 5, 3); //alpinist keys
               AlpineCore::getInstance()->getServer()->broadcastMessage("§l§a»» §r" . TF::GREEN . $sender->getName() . TF::GRAY . " redeemed their Voyager reclaim!");
               $sender->sendMessage(TF::BOLD . TF::GREEN . "»» " . TF::RESET . TF::GRAY . " You have succesfully redeemed your reclaim and received x10 Lives and Keys!");
               return;
           } elseif ($sender->hasPermission("core.reclaim.voyager")){
               $sender->setLives($sender->getLives() + 25);
               $sender->setReclaim(true);
               AlpineCore::getInstance()->getCratesManager()->giveKey($sender, 4, 10); //voyager keys
               AlpineCore::getInstance()->getCratesManager()->giveKey($sender, 3, 7); //pioneer keys
               AlpineCore::getInstance()->getCratesManager()->giveKey($sender, 5, 5); //alpinist keys
               $sender->sendMessage(TF::BOLD . TF::GREEN . "»» " . TF::RESET . TF::GRAY . " You have succesfully redeemed your reclaim and received x25 Lives and Keys!");
               AlpineCore::getInstance()->getServer()->broadcastMessage("§l§a»» §r" . TF::GREEN . $sender->getName() . TF::GRAY . " redeemed their Pioneer reclaim!");
               return;
           } elseif ($sender->hasPermission("core.reclaim.alpinist")){
               $sender->setLives($sender->getLives() + 40);
               $sender->setReclaim(true);
               AlpineCore::getInstance()->getCratesManager()->giveKey($sender, 4, 15); //voyager keys
               AlpineCore::getInstance()->getCratesManager()->giveKey($sender, 3, 10); //pioneer keys
               AlpineCore::getInstance()->getCratesManager()->giveKey($sender, 5, 7); //alpinist keys
               AlpineCore::getInstance()->getCratesManager()->giveKey($sender, 2, 2); //partner keys
               $sender->sendMessage(TF::BOLD . TF::GREEN . "»» " . TF::RESET . TF::GRAY . " You have succesfully redeemed your reclaim and received x40 Lives and Keys!");
               AlpineCore::getInstance()->getServer()->broadcastMessage("§l§a»» §r" . TF::GREEN . $sender->getName() . TF::GRAY . " redeemed their Alpinist reclaim!");
               return;
           } elseif ($sender->hasPermission("core.reclaim.partner")){
               $sender->setLives($sender->getLives() + 30);
               $sender->setReclaim(true);
               AlpineCore::getInstance()->getCratesManager()->giveKey($sender, 4, 15); //voyager keys
               AlpineCore::getInstance()->getCratesManager()->giveKey($sender, 3, 10); //pioneer keys
               AlpineCore::getInstance()->getCratesManager()->giveKey($sender, 5, 7); //alpinist keys
               AlpineCore::getInstance()->getCratesManager()->giveKey($sender, 2, 5); //partner keys
               $sender->sendMessage(TF::BOLD . TF::GREEN . "»» " . TF::RESET . TF::GRAY . " You have succesfully redeemed your reclaim and received x30 Lives and Keys!");
               AlpineCore::getInstance()->getServer()->broadcastMessage("§l§a»» §r" . TF::GREEN . $sender->getName() . TF::GRAY . " redeemed their Partner reclaim!");
               return;
           } elseif ($sender->hasPermission("core.reclaim.youtuber")){
               $sender->setLives($sender->getLives() + 10);
               $sender->setReclaim(true);
               AlpineCore::getInstance()->getCratesManager()->giveKey($sender, 4, 10); //voyager keys
               AlpineCore::getInstance()->getCratesManager()->giveKey($sender, 3, 7); //pioneer keys
               AlpineCore::getInstance()->getCratesManager()->giveKey($sender, 5, 5); //alpinist keys
               AlpineCore::getInstance()->getCratesManager()->giveKey($sender, 2, 3); //partner keys
               $sender->sendMessage(TF::BOLD . TF::GREEN . "»» " . TF::RESET . TF::GRAY . " You have succesfully redeemed your reclaim and received x30 Lives and Keys!");
               AlpineCore::getInstance()->getServer()->broadcastMessage("§l§a»» §r" . TF::GREEN . $sender->getName() . TF::GRAY . " redeemed their YouTuber reclaim!");
               return;
           } elseif ($sender->hasPermission("core.reclaim.nitrobooster")){
               $sender->setLives($sender->getLives() + 10);
               $sender->setReclaim(true);
               AlpineCore::getInstance()->getCratesManager()->giveKey($sender, 4, 5); //voyager keys
               AlpineCore::getInstance()->getCratesManager()->giveKey($sender, 3, 5); //pioneer keys
               AlpineCore::getInstance()->getCratesManager()->giveKey($sender, 5, 5); //alpinist keys
               AlpineCore::getInstance()->getCratesManager()->giveKey($sender, 2, 3); //partner keys
               AlpineCore::getInstance()->getServer()->broadcastMessage("§l§a»» §r" . TF::GREEN . $sender->getName() . TF::GRAY . " redeemed their NitroBooster reclaim!");
               $sender->sendMessage(TF::BOLD . TF::GREEN . "»» " . TF::RESET . TF::GRAY . " You have succesfully redeemed your reclaim and received x10 Lives and Keys!");
               return;
           }
       }
   }
}