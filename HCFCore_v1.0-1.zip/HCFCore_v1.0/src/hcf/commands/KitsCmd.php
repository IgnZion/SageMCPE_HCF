<?php
declare(strict_types=1);
namespace hcf\commands;

use hcf\{
   AlpineCore, AlpinePlayer
};
use pocketmine\command\{
   CommandSender, PluginCommand
};
use pocketmine\Server;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat as TF;

class KitsCmd extends PluginCommand {
   /** @var AlpineCore */
   private $plugin;

   /**
     * KitsCmd constructor.
     *
     * @param AlpineCore $plugin
     */
   public function __construct(AlpineCore $plugin){
      parent::__construct("kit", $plugin);
      $this->plugin = $plugin;
      $this->setPermission("core.cmd.kits");
      $this->setUsage("/kit");
      $this->setDescription("Shows kit UI with all server kits!");
   }

   /**
     * @param CommandSender $sender
     * @param string $commandLabel
     * @param array $args
     */
   public function execute(CommandSender $sender, string $commandLabel, array $args){
      $svr = $this->plugin->getServer();
      if($sender->hasPermission("core.cmd.kits")) $sender->sendMessage("TO RESET KITS: /kit <player-ign> <Bard|Archer|Diamond|Starter|Miner|Rogue|Master>");
      if(isset($args[0]) && isset($args[1])){
         $player = $svr->getPlayerExact($args[0]);
         if($sender->hasPermission("core.cmd.kits")){
            if($player instanceof AlpinePlayer){
               if($args[1] == "Bard" || $args[1] == "Archer" || $args[1] == "Diamond" || $args[1] == "Miner" || $args[1] == "Starter" || $args[1] == "Rogue" || $args[1] == "Master" || $args[1] == "Builder" || $args[1] == "Brewer") {
                  $kit = strtolower($args[1]);
                  $player->unsetKitCooldown($kit);
                  $sender->sendMessage(TF::BOLD . TF::GREEN . "»» " . TF::RESET . TF::GRAY . $player->getName() . " " . $args[1] . " has been reset so they can use it again!");
               } else $sender->sendMessage(TF::BOLD . TF::RED . "»» " . TF::RESET . TF::GRAY . "You entered the wrong kit! Kits: " . TF::RED . "Bard, Archer, Diamond, Miner, Starter, Rogue, Master, Brewer, Builder");
            } else $sender->sendMessage(TF::BOLD . TF::RED . "»» " . TF::RESET . TF::GRAY . " There is no player online at the moment by that name!");
         } else $sender->sendMessage(TF::BOLD . TF::RED . "»» " . TF::RESET . TF::GRAY . " You do not have permissions to reset kit cooldowns!");
      } else {
         if($sender instanceof AlpinePlayer){
            AlpineCore::getKitsManager()->sendMenu($sender);
         } else $sender->sendMessage("YOU NO PLAYER!");
      }
   }
}