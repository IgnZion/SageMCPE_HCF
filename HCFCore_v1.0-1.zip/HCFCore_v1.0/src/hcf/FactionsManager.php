<?php
declare(strict_types=1);
namespace hcf;

use pocketmine\math\Vector3;
use pocketmine\level\Level;
use pocketmine\level\Position;
use pocketmine\utils\TextFormat;

class FactionsManager {
   private $plugin;
   private $db;
   private $frozens = [];
   const CLAIM = 1;
   const SPAWN = 2;
   const RAIDABLE = 3;
   const LEADER = 0;
   const COLEADER = 1;
   const OFFICER = 2;
   const MEMBER = 3;

   /**
     * FactionsManager constructor.
     *  @param AlpineCore $plugin
     */
   public function __construct(AlpineCore $plugin){
      $this->plugin = $plugin;
      $db = new \SQLite3($this->plugin->getDataFolder() . "FactionsData.db");
      $this->setDb($db);
      $this->getDb()->exec("CREATE TABLE IF NOT EXISTS claims(faction TEXT PRIMARY KEY, type INT, x1 INT, z1 INT, x2 INT, z2 INT);");
      $this->getDb()->exec("CREATE TABLE IF NOT EXISTS players(name TEXT PRIMARY KEY, rank INT, faction TEXT);");
      $this->getDb()->exec("CREATE TABLE IF NOT EXISTS homes(name TEXT PRIMARY KEY, x INT, y INT, z INT);");
      $this->getDb()->exec("CREATE TABLE IF NOT EXISTS dtrs(name TEXT PRIMARY KEY, dtr DOUBLE);");
      $this->getDb()->exec("CREATE TABLE IF NOT EXISTS allies(ID INT PRIMARY KEY, faction1 TEXT, faction2 TEXT);");
      $this->getDb()->exec("CREATE TABLE IF NOT EXISTS balances(name TEXT PRIMARY KEY, balance INT);");
      $this->getDb()->exec("CREATE TABLE IF NOT EXISTS freeze(name TEXT PRIMARY KEY, dtrfreeze BIGINT);");
      $this->getDb()->exec("CREATE TABLE IF NOT EXISTS points(name TEXT PRIMARY KEY, facpoints DOUBLE);");
   }
   /**
     * @return \SQLite3
     */
   public function getDb(): \SQLite3 {
      return $this->db;
   }
   /**
     * @param \SQLite3 $db
     */
   public function setDb(\SQLite3 $db){
      $this->db = $db;
   }
   /** 
     * @param string $name
     * @return bool
     */
   public function isFaction(string $name): bool {
      $result = $this->getDb()->query("SELECT * FROM players WHERE faction = '$name';");
      $array = $result->fetchArray(SQLITE3_ASSOC);
      return !empty($array);
   }
   /**
     * @param string $name
     * @param AlpinePlayer $player
     */
   public function createFaction(string $name, AlpinePlayer $player){
      if($this->isFaction($name)){
         $player->sendMessage("§l§c»» §r§7This Faction's name already exists!");
      } else {
         $player->sendMessage("§l§a»» §r§7You have successfully made the faction: " . $name . "!");
         $player->addToFaction($name, self::LEADER);
         $this->setBalance($name, 0);
         $this->setDTR($name, 1.5);
         $this->setPoints($name, 0);
         $svr = $this->plugin->getServer();
         $svr->broadcastMessage("§l§a»»» §r§7 The Faction " . $name . " has been created by " . $player->getName());
      }
   }

   /**
     * @param string $faction1
     * @param string $faction2
     */
   public function setAllies(string $faction1, string $faction2){
      $this->getDb()->exec("INSERT OR REPLACE INTO allies(faction1, faction2) VALUES ('$faction1', '$faction2');");
   }
   /**
     * @param string $faction1
     * @param string $faction2
     */
   public function unsetAllies(string $faction1, string $faction2){
      $this->getDb()->exec("DELETE FROM allies WHERE (faction1 = '$faction1' && faction2 = '$faction2');");
   }

   /**
     * @param string $name
     * @return array
     */
   public function getOfficers(string $name): array {
      $members = [];
      $result = $this->getDb()->query("SELECT * FROM players WHERE faction = '$name' AND rank = 2;");
      while($array = $result->fetchArray(SQLITE3_ASSOC)){
         $members[] = $array["name"];
      }
      return $members;
   }

   /**
     * @param string $name
     * @param string $player
     */
   public function setOfficer(string $name, string $player) {
      $this->getDb()->exec("INSERT OR REPLACE INTO players(name, rank, faction) VALUES ('$player', " . self::OFFICER . ", '$name');");
   }

   /**
     * @param string $name
     * @param string $player
     */
   public function setMember(string $name, string $player) {
      $this->getDb()->exec("INSERT OR REPLACE INTO players(name, rank, faction) VALUES ('$player', " . self::MEMBER . ", '$name');");
   }


   /**
     * @param string $name
     * @return array
     */
   public function getMembers(string $name): array {
      $members = [];
      $result = $this->getDb()->query("SELECT * FROM players WHERE faction = '$name' AND rank = 3;");
      while($array = $result->fetchArray(SQLITE3_ASSOC)){
         $members[] = $array["name"];
      }
      return $members;
   }

   /**
     * @param string $name
     * @return array
     */
   public function getTotalMembers(string $name): array {
      $members = [];
      $result = $this->getDb()->query("SELECT * FROM players WHERE faction = '$name';");
      while($array = $result->fetchArray(SQLITE3_ASSOC)){
         $members[] = $array["name"];
      }
      return $members;
   }

   /**
     * @param string $name
     * @param string $player
     * @return bool
     */
   public function isMember(string $name, string $player): bool {
      return in_array($player, $this->getMembers($name));
   }

   /**
     * @param string $name
     * @param string $player
     * @return bool
     */
   public function isOfficer(string $name, string $player): bool {
      return in_array($player, $this->getOfficers($name));
   }

   /**
     * @param string $name
     */
   public function kick(string $name){
      $this->getDb()->exec("DELETE FROM players WHERE name = '$name';");
   }

 /**
     * @param string $name
     */
   public function getPoints(string $name){
     $result = $this->getDb()->query("SELECT * FROM points WHERE name = '$name';");
      $array = $result->fetchArray(SQLITE3_ASSOC);
      return $array["facpoints"];
   }

  /**
     * @param string $name
     * @param float $amount
     */
   public function setPoints(string $name, float $amount){
      $this->getDb()->exec("INSERT OR REPLACE INTO points(name, facpoints) VALUES ('$name', " . $amount . ");");
   }

   /**
     * @param string $name
     * @param float $amount
     */
   public function addPoints(string $name, float $amount){
      $this->setPoints($name, $this->getPoints($name) + $amount);
   }

   /**
     * @param string $name
     * @param float $amount
     */
   public function movePoints(string $name, float $amount){
      $this->setPoints($name, $this->getPoints($name) - $amount);
   }

   /**
     * @param string $name
     */
   public function getDTR(string $name) {
      $result = $this->getDb()->query("SELECT * FROM dtrs WHERE name = '$name';");
      $array = $result->fetchArray(SQLITE3_ASSOC);
      return $array["dtr"];
   }

   /**
     * @param string $name
     * @param float $amount
     */
   public function setDTR(string $name, float $amount){
      $this->getDb()->exec("INSERT OR REPLACE INTO dtrs(name, dtr) VALUES ('$name', " . $amount . ");");
   }

   public function reduceDTR(string $name){
      $dtr = $this->getDTR($name);
      if($dtr <= 1){
         $this->setDTR($name, $dtr - 1);
         $this->setFrozenTime($name, time() + (60 * 30));
         foreach ($this->getOnlineMembers($name) as $player){
            if($player instanceof AlpinePlayer){
               $player->sendMessage("§l§c»» §r§7Your faction is raidable!" . TextFormat::BOLD . TextFormat::RED . " DTR: " . TextFormat::RESET . TextFormat::RED . $dtr);
            }
         }
      } else {
            $this->setDTR($name, $dtr - 1);
            $this->setFrozenTime($name, time() + (60 * 30));
      }
      foreach ($this->getOnlineMembers($name) as $player){
         if($player instanceof AlpinePlayer){
            $player->sendMessage("§l§c»» §r§7Your faction lost 1 DTR");
         }
      }
   }

   /**
     * @param string $name
     */
   public function addDTR(string $name){
      $dtr = $this->getDTR($name);
      if(!$this->isFrozen($name)){
         if($dtr < $this->getMaxDTR($name)){
            $this->setDTR($name, $dtr + 0.5);
            foreach ($this->getOnlineMembers($name) as $player){
               if($player instanceof AlpinePlayer){
                  $player->sendMessage("§l§a»» §r§7You gained +0.5 DTR");
               }
            }
         }
      }
   }

   /**
     * @param string $name
     * @return float
     */
   public function getMaxDTR(string $name): float {
      $total = count($this->getTotalMembers($name));
      if($total == 4){
         $max = 4.5;
      } else {
         $max = $total + 0.5;
      }
      return $max;
   }

   /**
     * @param string $name
     * @return string
     */
   public function getLeader(string $name): string {
      $result = $this->getDb()->query("SELECT * FROM players WHERE faction = '$name' AND rank = 0;");
      $array = $result->fetchArray(SQLITE3_ASSOC);
      return strval($array["name"]);
   }

   /**
     * @param string $name
     * @param string $leader
     */
   public function setLeader(string $name, string $leader) {
      $this->getDb()->exec("INSERT OR REPLACE INTO players(name, rank, faction) VALUES ('$leader', " . self::LEADER . ", '$name');");
   }

   /**
     * @param string $name
     * @param int $amount
     */
   public function setBalance(string $name, int $amount) {
      $this->getDb()->exec("INSERT OR REPLACE INTO balances(name, balance) VALUES ('$name', " . $amount . ");");
   }

   /**
     * @param string $name
     * @return int
     */
   public function getBalance(string $name): int {
      $result = $this->getDb()->query("SELECT * FROM balances WHERE name = '$name';");
      $array = $result->fetchArray(SQLITE3_ASSOC);
      return intval($array["balance"]);
   }

   /**
     * @param string $name
     * @param int $amount
     */
   public function addBalance(string $name, int $amount) {
      $this->setBalance($name, $this->getBalance($name) + $amount);
   }

   /**
     * @param string $name
     * @param int $amount
     */
   public function reduceBalance(string $name, int $amount) {
      $this->setBalance($name, $this->getBalance($name) - $amount);
   }

   /**
     * @param string $name
     */
   public function disbandFaction(string $name){
      $this->getDb()->exec("DELETE FROM players WHERE faction = '$name';");
      $this->getDb()->exec("DELETE FROM homes WHERE name = '$name';");
      $this->getDb()->exec("DELETE FROM balances WHERE name = '$name';");
      $this->getDb()->exec("DELETE FROM dtrs WHERE name = '$name';");
      $this->getDb()->exec("DELETE FROM claims WHERE faction = '$name';");
      $this->getDb()->exec("DELETE FROM points WHERE name = '$name';");
      foreach ($this->getOnlineMembers($name) as $member){
         $player = $this->plugin->getServer()->getPlayer($member);
         $player->sendMessage("§l§c»» §r§7Your Faction has been disbanded");
         $player->removeFromFaction();
      }
   }

   /**
     * @param string $name
     * @return AlpinePlayer[]
     */
   public function getOnlineMembers(string $name): array {
      $online = [];
      $result = $this->getDb()->query("SELECT * FROM players WHERE faction = '$name';");
      while ($array = $result->fetchArray(SQLITE3_ASSOC)){
         if ($player = $this->plugin->getServer()->getPlayer($array["name"])){
            $online[] = $player;
         }
      }
      return $online;
   }

   /**
     * @param string $name
     * @return bool
     */
   public function isHome(string $name): bool {
      $result = $this->getDb()->query("SELECT * FROM homes WHERE name = '$name';");
      $array = $result->fetchArray(SQLITE3_ASSOC);
      return !empty($array);
   }

   /**
     * @param string $name
     * @return Vector3
     */
   public function getHome(string $name): Vector3 {
      $result = $this->getDb()->query("SELECT * FROM homes WHERE name = '$name';");
      $array = $result->fetchArray(SQLITE3_ASSOC);
      return new Vector3($array["x"], $array["y"], $array["z"]);
   }

   /**
     * @param string $name
     * @param AlpinePlayer $pos
     */
   public function setHome(string $name, AlpinePlayer $pos) {
      $this->getDb()->exec("INSERT OR REPLACE INTO homes(name, x, y, z) VALUES ('$name', " . $pos->getFloorX() . ", " . $pos->getFloorY() . ", " . $pos->getFloorZ() . ");");
   }

   /**
     * @return array
     */
   public function getAllFactions(): array {
      $result = $this->getDb()->query("SELECT * FROM players;");
      $all = [];
      while ($fac = $result->fetchArray(SQLITE3_ASSOC)){
         $all[] = $fac["faction"];
      }
      return $all;
   }

   /**
     * @param string $fac
     * return bool
     */
   public function isFrozen(string $fac): bool {
      $time = $this->getFrozenTimeLeft($fac);
      if($time >= 0){
         return true;
      } else {
      return false;
      }
   }
   /**
     * @param string $faction
     * @param int $time
     */
   public function setFrozenTime(string $faction, int $time) {
      $this->getDb()->exec("INSERT OR REPLACE INTO freeze(name, dtrfreeze) VALUES ('$faction', " . $time . ");");
   }

  /**
    * @param string $faction
    * @return int
    */
   public function getFrozenTime(string $faction): int {
      $result = $this->getDb()->query("SELECT * FROM freeze WHERE name = '$faction';");
      $array = $result->fetchArray(SQLITE3_ASSOC);
      return intval($array["dtrfreeze"]);
   }

   /**
     * @param string $faction
     * @return int
     */
   public function getFrozenTimeLeft(string $faction): int {
      $time = $this->getFrozenTime($faction) - time();
      return $time;
   }

    /**
     * @param string $name
     * @return string
     */
    public function getFaction(string $name): string {
        $result = AlpineCore::getFactionsManager()->getDb()->query("SELECT * FROM players WHERE name = '$name';");
        $array = $result->fetchArray(SQLITE3_ASSOC);
        return $array["faction"];
    }

    /**
     * @param string $name
     * @return $bool
     */
    public function isInFaction(string $name): bool {
        $result = AlpineCore::getFactionsManager()->getDb()->query("SELECT * FROM players WHERE name = '$name';");
        $array = $result->fetchArray(SQLITE3_ASSOC);
        return empty($array) == false;
    }

   /**
     * @param string $name
     * @param Vector3 $pos1
     * @param Vector3 $pos2
     * @param int $type
     */
   public function claim(string $name, Vector3 $pos1, Vector3 $pos2, int $type = self::CLAIM) {
      $x1 = max($pos1->getX(), $pos2->getX());
      $z1 = max($pos1->getZ(), $pos2->getZ());
      $x2 = min($pos1->getX(), $pos2->getX());
      $z2 = min($pos1->getZ(), $pos2->getZ());
      $db = $this->getDb()->prepare("INSERT OR REPLACE INTO claims (faction, type, x1, z1, x2, z2) VALUES (:faction, :type, :x1, :z1, :x2, :z2);");
      $db->bindValue(":faction", $name);
      $db->bindValue(":type", $type);
      $db->bindValue(":x1", $x1);
      $db->bindValue(":z1", $z1);
      $db->bindValue(":x2", $x2);
      $db->bindValue(":z2", $z2);
      $db->execute();
    }

   /**
     * @param Vector3 $pos
     * @return bool
     */
   public function isClaim(Vector3 $pos, Level $level): bool {
      $x = $pos->getX();
      $z = $pos->getZ();
      $result = $this->getDb()->query("SELECT * FROM claims WHERE $x <= x1 AND $x >= x2 AND $z <= z1 AND $z >= z2;");
      $array = $result->fetchArray(SQLITE3_ASSOC);
      if($level != AlpineCore::$overworldLevel) return false;
      return empty($array) == false;
   }

   /**
     * @param Vector3 $pos
     * @return bool
     */
   public function isSpawnClaim(Vector3 $pos, Level $level): bool {
      $x1 = max(-75, 75);
      $z1 = max(-75, 75);
      $x2 = min(-75, 75);
      $z2 = min(-75, 75);
      $x = $pos->getX();
      $z = $pos->getZ();
      if($level == AlpineCore::$overworldLevel){
          if($x <= $x1 && $x >= $x2 && $z <= $z1 && $z >= $z2){
              return true;
          } else return false;
      } else return false;
   }

   /**
     * @param Vector3 $pos
     * @return bool
     */
   public function isRoad(Vector3 $pos, Level $level): bool{
      $x = $pos->getX();
      $z = $pos->getZ();
      if($level == AlpineCore::$overworldLevel){
          if($x < max(-9, 9) && $x > min(-9, 9) && $z < max(75, 4000) && $z > min(75, 4000)){
             return true;
          } elseif($x < max(75, 4000) && $x > min(75, 4000) && $z < max(-9, 9) && $z > min(-9, 9)){
             return true;
          } elseif($x < max(-9, 9) && $x > min(-9, 9) && $z < max(-75, -4000) && $z > min(-75, -4000)){
             return true;
          } elseif($x < max(-4000, -75) && $x > min(-4000, -75) && $z < max(-9, 9) && $z > min(-9, 9)){
             return true;
          } else {
             return false;
          }
      } else return false;
   }

   /**
     * @param Vector3 $pos
     * @return string
     */
   public function getRoad(Vector3 $pos, Level $level): string {
      $x = $pos->getX();
      $z = $pos->getZ();
      if($level == AlpineCore::$overworldLevel && $x < max(-9, 9) && $x > min(-9, 9) && $z < max(75, 4000) && $z > min(75, 4000)) return "South Road";
      if($level == AlpineCore::$overworldLevel && $x < max(75, 4000) && $x > min(75, 4000) && $z < max(-9, 9) && $z > min(-9, 9)) return "East Road";
      if($level == AlpineCore::$overworldLevel && $x < max(-9, 9) && $x > min(-9, 9) && $z < max(-75, -4000) && $z > min(-75, -4000)) return "North Road";
      if($level == AlpineCore::$overworldLevel && $x < max(-4000, -75) && $x > min(-4000, -75) && $z < max(-9, 9) && $z > min(-9, 9)) return "West Road";
   }

   /**
     * @param Vector3 $pos
     * @return bool
     */
   public function isNetherSpawnClaim(Vector3 $pos, Level $level): bool {
      $x1 = max(-51, 51);
      $z1 = max(-51, 51);
      $x2 = min(-51, 51);
      $z2 = min(-51, 51);
      $x = $pos->getX();
      $z = $pos->getZ();
      if($level == AlpineCore::$netherLevel){
          if($x <= $x1 && $x >= $x2 && $z <= $z1 && $z >= $z2){
              return true;
          } else return false;
      } else return false;
   }

   /**
     * @param Vector3 $pos
     * @return bool
     */
   public function isNetherRoad(Vector3 $pos, Level $level): bool{
      $x = $pos->getX();
      $z = $pos->getZ();
      if($level == AlpineCore::$netherLevel){
          if($x < max(-9, 9) && $x > min(-9, 9) && $z < max(51, 4000) && $z > min(51, 4000)){
             return true;
          } elseif($x < max(51, 4000) && $x > min(51, 4000) && $z < max(-9, 9) && $z > min(-9, 9)){
             return true;
          } elseif($x < max(-9, 9) && $x > min(-9, 9) && $z < max(-51, -4000) && $z > min(-51, -4000)){
             return true;
          } elseif($x < max(-4000, -51) && $x > min(-4000, -51) && $z < max(-9, 9) && $z > min(-9, 9)){
             return true;
          } else {
             return false;
          }
      } else return false;
   }
   /**
     * @param Vector3 $pos
     * @return string
     */
   public function getNetherRoad(Vector3 $pos, Level $level): string {
      $x = $pos->getX();
      $z = $pos->getZ();
      if($level == AlpineCore::$netherLevel && $x < max(-9, 9) && $x > min(-9, 9) && $z < max(51, 4000) && $z > min(51, 4000)) return "South Road";
      if($level == AlpineCore::$netherLevel && $x < max(51, 4000) && $x > min(51, 4000) && $z < max(-9, 9) && $z > min(-9, 9)) return "East Road";
      if($level == AlpineCore::$netherLevel && $x < max(-9, 9) && $x > min(-9, 9) && $z < max(-51, -4000) && $z > min(-51, -4000)) return "North Road";
      if($level == AlpineCore::$netherLevel && $x < max(-4000, -51) && $x > min(-4000, -51) && $z < max(-9, 9) && $z > min(-9, 9)) return "West Road";
   }

   /**
     * @param Vector3 $pos
     * @return bool
     */
   public function isFactionClaim(Vector3 $pos, Level $level): bool {
      $x = $pos->getX();
      $z = $pos->getZ();
      $result = $this->getDb()->query("SELECT * FROM claims WHERE $x <= x1 AND $x >= x2 AND $z <= z1 AND $z >= z2 AND type = 1;");
      $array = $result->fetchArray(SQLITE3_ASSOC);
      if(empty($array) == false) {
         if($level == AlpineCore::$overworldLevel){
             if($this->getDTR($array["faction"]) <= 0){
                 return false;
             } else {
                 return true;
             }
         } else {
             return false;
         }
      } else {
          return false;
      }
   }

   /**
     * @param int $x
     * @param int $z
     * @return string
     */
   public function getClaimer(int $x, int $z): string {
      $result = $this->getDb()->query("SELECT * FROM claims WHERE $x <= x1 AND $x >= x2 AND $z <= z1 AND $z >= z2;");
      $array = $result->fetchArray(SQLITE3_ASSOC);
      return $array["faction"];
   }

   /**
     * @param int $x
     * @param int $z
     * @return int
     */
   public function getClaimType(int $x, int $z): int {
      $result = $this->getDb()->query("SELECT * FROM claims WHERE $x <= x1 AND $x >= x2 AND $z <= z1 AND $z >= z2;");
      $array = $result->fetchArray(SQLITE3_ASSOC);
      return $array["type"];
   }
}