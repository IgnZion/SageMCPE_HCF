<?php
declare(strict_types=1);
namespace hcf;

use mysqli;
use pocketmine\{
   plugin\PluginBase, level\Level, Server,
   event\Listener, utils\Config, item\enchantment\Enchantment
};
use hcf\{
   tasks\Tasks, tasks\ClosureTask, tasks\PingTask,
   events\Events, events\timers\SOTW,
   blocks\BlocksManager,
   items\ItemsManager, level\LevelManager,
   entity\EntityManager, tile\Tile, manager, manager\LoggerManager,
   manager\KitsManager, manager\ShopManager, manager\CratesManager, manager\PunishManager,
   commands\Commands
};
use muqsit\invmenu\{
   InvMenu, InvMenuHandler
};
//use cosmoverse\antivpn\{AntiVPN, api\AntiVPNResult};

class AlpineCore extends PluginBase implements Listener {
   /** @var AntiVPN */
   //public $antivpn; 
   /** @var mysqli */
   public $mysqli;
   /** @var Config */
   public $coredata;
   /** @var Config */
   public $permissions;
   /** @var AlpineCore */
   private static $instance;
   /** @var int[] */
   public static $onPortal = [];
   /** @var string */
   public static $endName = "world_the_end";
   /** @var Level */
   public static $endLevel;
   /** @var string */
   public static $netherName = "world_nether";
   /** @var Level */
   public static $netherLevel;
   /** @var string */
   public static $overworldLevelName = "world";
   /** @var Level */
   public static $overworldLevel;
   /** @var FactionsManager */
   public static $FactionsManager;
   /** @var LoggerManager */
   public static $LoggerManager;
   /** @var KitsManager */
   public static $KitsManager;
   /** @var ShopManager */
   public static $ShopManager;
   /** @var CratesManager */
   public static $CratesManager;
   /** @var PunishManager */
   public static $PunishManager;

   public function onEnable(){
      self::$instance = $this;
      self::$FactionsManager = new FactionsManager($this);
      self::$LoggerManager = new LoggerManager($this);
      self::$KitsManager = new KitsManager($this);
      self::$ShopManager = new ShopManager($this);
      self::$CratesManager = new CratesManager($this);
      self::$PunishManager = new PunishManager($this);
      self::$netherName = "world_nether";
      self::$endName = "world_the_end";
      self::$overworldLevelName = "world";
      self::$endLevel = Server::getInstance()->getLevelByName(self::$endName);
      self::$netherLevel = Server::getInstance()->getLevelByName(self::$netherName);
      self::$overworldLevel = Server::getInstance()->getLevelByName(self::$overworldLevelName);
      Tasks::init();
      Events::init();
      Commands::init();
      LevelManager::init();
      ItemsManager::init();
      EntityManager::init();
      BlocksManager::init();
      Tile::init();
      $this->plugin()->registerEvents($this, $this);
      $folder = $this->getDataFolder();
      @mkdir($folder);
      $this->saveResource("CoreData.json");
      $this->saveResource("Permissions.yml");
      $this->coredata = new Config($folder . "CoreData.json", Config::JSON, ["Sotw" => ["time" => 0, "enabled" => false], "Eotw" => 0, "claim" => ["perblock" => 5]]);
      $this->coredata->save();
      $this->permissions = new Config($folder. "Permissions.yml", Config::YAML, ["player" => ["core.testpermission"], "nitrobooster" => ["core.testpermission"], "voyager" => ["core.testpermission"], "pioneer" => ["core.testpermission"], "alpinist" => ["core.testpermission"], "youtuber" => ["core.testpermission"], "partner" => ["core.testpermission"], "trainee" => ["core.testpermission"], "mod" => ["core.testpermission"], "srmod" => ["core.testpermission"], "admin" => ["core.testpermission"], "sradmin" => ["core.testpermission"], "manager" => ["core.testpermission"], "owner" => ["core.testpermission"]]);
      $this->permissions->save();
      if(!InvMenuHandler::isRegistered()){
         InvMenuHandler::register($this);
      }
      //$this->antivpn = new AntiVPN($this, "0D8581E4FDABB211F2578E4D1A593F920CA0BD8436170AB7544EA27669B62783", 2);
      mysqli_report(MYSQLI_REPORT_ALL & ~MYSQLI_REPORT_INDEX);
      $this->mysqli = new mysqli("na02-db.cus.mc-panel.net", "db_195488", "4a721b4368", "db_195488");
      if($this->mysqli->connect_error){
         $this->getServer()->shutdown();
      }
      $this->mysqli->query("CREATE TABLE IF NOT EXISTS playerdata(username VARCHAR(20) PRIMARY KEY, rank TEXT, permissions TEXT, elo INT, tags TEXT, banned INT, bannedtimes INT, banduration INT, warnings INT, muted INT, cid TEXT, ip TEXT, skin TEXT);");
      $this->mysqli->query("CREATE TABLE IF NOT EXISTS hcfdata(username VARCHAR(20) PRIMARY KEY, money INT, kills INT, deaths INT, pvpenabled INT, pvptime INT, gapcooldown INT, reclaim INT, staffmode INT, inventory TEXT, helmet TEXT, chestplate TEXT, leggings TEXT, boots TEXT);");
      $this->mysqli->query("CREATE TABLE IF NOT EXISTS kitsdata(username VARCHAR(20) PRIMARY KEY, starter INT, bard INT, miner INT, rogue INT, diamond INT, archer INT, master INT, builder INT, brewer INT);");
      $this->mysqli->query("CREATE TABLE IF NOT EXISTS deathbandata(username VARCHAR(20) PRIMARY KEY, lives INT, time INT, deathbanned TEXT, zombielogger TEXT);");
      $logger = $this->getServer()->getLogger();
      $this->getScheduler()->scheduleRepeatingTask(new PingTask($this, $this->mysqli), 600);
      $this->getScheduler()->scheduleDelayedRepeatingTask(new ClosureTask($this), 6000, 6000);
   }

   public function onDisable(){
      $players = $this->getServer()->getOnlinePlayers();
      $logger = $this->getServer()->getLogger();
      foreach($players as $player){
         $player->saveIt();
      }
      $this->getPlayerDatabase()->close();
      //$this->antivpn->close();
      $logger->notice("HCF has been disabled");
    }

   public static function getInstance(): AlpineCore {
      return self::$instance;
   }

   public static function getShopManager(): ShopManager {
      return self::$ShopManager;
   }

   public static function getFactionsManager(): FactionsManager {
      return self::$FactionsManager;
   }

   public static function getLoggerManager(): LoggerManager {
      return self::$LoggerManager;
   }

   public static function getKitsManager(): KitsManager {
      return self::$KitsManager;
   }

   public static function getCratesManager(): CratesManager {
      return self::$CratesManager;
   }

   public static function getPunishManager(): PunishManager {
      return self::$PunishManager;
   }

   public function plugin(){
      return $this->getServer()->getPluginManager();
   }

   public function getPlayerDatabase(): mysqli {
      return $this->mysqli;
   }

   /*public function getAntiVPN(): AntiVPN {
      return $this->antivpn;
   }*/

   public function setPlayerDatabase($database) {
       $this->mysqli = $database;
   }
         
   public function getData() {
      return $this->coredata;
   }

   public function getRankPermissions(){
      return $this->permissions;
   }

   public function autoSave(): void {
       foreach($this->getServer()->getOnlinePlayers() as $player){
           $player->saveIt();
       }
       echo "Player Data Saved!";
   }
}