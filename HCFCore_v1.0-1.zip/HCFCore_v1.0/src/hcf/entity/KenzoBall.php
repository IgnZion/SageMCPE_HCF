<?php
declare(strict_types=1);

namespace hcf\entity;

use hcf\{AlpinePlayer, AlpineCore};
use pocketmine\entity\Entity;
use pocketmine\entity\projectile\Snowball;
use pocketmine\math\RayTraceResult;

class KenzoBall extends Snowball {

    protected function onHitEntity(Entity $entityHit, RayTraceResult $hitResult) : void{
        $thrower = $this->getOwningEntity();
        if(!$thrower instanceof AlpinePlayer || !$entityHit instanceof AlpinePlayer){
            $this->flagForDespawn();
            return;
        }
        if($thrower->distanceSquared($entityHit) > 144){
            $this->flagForDespawn();
            return;
        }
        $mgr = AlpineCore::getFactionsManager();
        if($entityHit instanceof AlpinePlayer && $mgr->isSpawnClaim($entityHit, $entityHit->getLevel())){
            $this->flagForDespawn();
            return;
        }
        if($thrower instanceof AlpinePlayer && $mgr->isSpawnClaim($thrower, $thrower->getLevel())){
            $this->flagForDespawn();
            return;
        }
        $throwerPos = $thrower->asPosition();
        $thrower->teleport($entityHit);
        $entityHit->teleport($throwerPos);
        $this->flagForDespawn();
    }
}
