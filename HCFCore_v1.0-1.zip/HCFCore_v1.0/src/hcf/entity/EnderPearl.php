<?php
declare(strict_types=1);
namespace hcf\entity;

use hcf\AlpinePlayer;
use pocketmine\math\Vector3;
use pocketmine\entity\Entity;
use pocketmine\entity\projectile\Throwable;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\network\mcpe\protocol\LevelEventPacket;

class EnderPearl extends Throwable {
    const NETWORK_ID = self::ENDER_PEARL;

    /**
     * @param int $currentTick
     * @return bool
     */
    public function onUpdate(int $currentTick): bool {
        $player = $this->getOwningEntity();
        if($this->isCollided || $this->age > 1200){
            if($this->y > 0 && $player instanceof AlpinePlayer){
                $pk1 = new LevelEventPacket();
                $pk1->data = 0;
                $pk1->evid = 2010; //Portal Particles
                $pk1->position = new Vector3($player->getX(), $player->getY(), $player->getZ());
                $player->getServer()->broadcastPacket($player->getLevel()->getPlayers(), $pk1);

                $player->teleport($this->getPosition());
                $player->attack(new EntityDamageEvent($player, EntityDamageEvent::CAUSE_FALL, mt_rand(1, 3)));

                $pk2 = new LevelEventPacket();
                $pk2->data = 0;
                $pk2->evid = 2010; //Portal Particles
                $pk2->position = new Vector3($player->getX(), $player->getY(), $player->getZ());
                $player->getServer()->broadcastPacket($player->getLevel()->getPlayers(), $pk2);

                $pk3 = new LevelEventPacket();
                $pk3->data = 0;
                $pk3->evid = LevelEventPacket::EVENT_SOUND_ENDERMAN_TELEPORT;
                $pk3->position = new Vector3($player->getX(), $player->getY(), $player->getZ());
                $player->getServer()->broadcastPacket($player->getLevel()->getPlayers(), $pk3);
            }
            $this->close();
        }
        return parent::onUpdate($currentTick);
    }

    /**
     * @param Entity $entity
     */
    public function onCollideWithEntity(Entity $entity){
        return;
    }
}