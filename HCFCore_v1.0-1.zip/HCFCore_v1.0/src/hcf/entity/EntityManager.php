<?php
declare(strict_types=1);

namespace hcf\entity;

use pocketmine\entity\Entity;
use hcf\entity\entity\{CaveSpider, Cow, Creeper, Enderman, Skeleton, Spider,};

class EntityManager {

   public static function init() {
      Entity::registerEntity(KenzoBall::class, true);
      Entity::registerEntity(BetterEnderPearl::class, true, ['EnderPearl', 'minecraft:enderpearl']);

      //Entity::registerEntity(CaveSpider::class, true, ['CaveSpider', 'minecraft:cavespider']);
      //Entity::registerEntity(Cow::class, true, ['Cow', 'minecraft:cow']);
      //Entity::registerEntity(Creeper::class, true, ['Creeper', 'minecraft:creeper']);
      //Entity::registerEntity(Enderman::class, true, ['Enderman', 'minecraft:enderman']);
      //Entity::registerEntity(Skeleton::class, true, ['Skeleton', 'minecraft:skeleton']);
      //Entity::registerEntity(Spider::class, true, ['Spider', 'minecraft:spider']);
   }
}
