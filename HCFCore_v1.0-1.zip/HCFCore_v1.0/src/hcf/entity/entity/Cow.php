<?php
declare(strict_types=1);
namespace hcf\entity\entity;

use hcf\AlpinePlayer;
use pocketmine\entity\Animal;
use pocketmine\item\{Item, enchantment\Enchantment};
use pocketmine\event\{EntityDamageByEntityEvent, EntityDamageEvent};

class Cow extends Animal {

    const NETWORK_ID = self::COW;

    public $width = 0.9;
    public $height = 1.3;

    /**
     * @return string
     */
    public function getName(): string {
        return "Cow";
    }

    /**
     * @return array
     */
    public function getDrops(): array {
        $cause = $this->lastDamageCause;
        if($cause instanceof EntityDamageByEntityEvent){
            $damager = $cause->getDamager();
            if($damager instanceof AlpinePlayer){
                $level = $damager->getInventory()->getItemInHand()->getEnchantmentLevel(Enchantment::LOOTING);
                if($level > 0){
                    return [Item::get(Item::RAW_BEEF, 0, mt_rand(1, 3) + mt_rand(0, 1 + $level)), Item::get(Item::LEATHER, 0, mt_rand(0,2) + mt_rand(0, 1 + $level))];
                } else return [Item::get(Item::RAW_BEEF, 0, mt_rand(1, 3)), Item::get(Item::LEATHER, 0, mt_rand(0,2))];
            }
        }
        return [Item::get(Item::RAW_BEEF, 0, mt_rand(1, 3)), Item::get(Item::LEATHER, 0, mt_rand(0,2))];
    }
}