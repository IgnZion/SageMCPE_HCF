<?php
declare(strict_types=1);
namespace hcf\entity\entity;

use pocketmine\entity\Monster;

abstract class Undead extends Monster {
}