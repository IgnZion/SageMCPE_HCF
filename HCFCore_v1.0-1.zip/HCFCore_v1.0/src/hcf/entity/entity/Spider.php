<?php
declare(strict_types=1);
namespace hcf\entity\entity;

use hcf\AlpinePlayer;
use pocketmine\entity\Monster;
use pocketmine\item\{Item, enchantment\Enchantment};
use pocketmine\event\{EntityDamageByEntityEvent, EntityDamageEvent};

class Spider extends Monster {

    const NETWORK_ID = self::SPIDER;

    public $width = 1.4;
    public $height = 0.9;

    /**
     * @return string
     */
    public function getName(): string {
        return "Spider";
    }

    /**
     * @return array
     */
    public function getDrops(): array {
        $cause = $this->lastDamageCause;
        if($cause instanceof EntityDamageByEntityEvent){
            $damager = $cause->getDamager();
            if($damager instanceof AlpinePlayer){
                $level = $damager->getInventory()->getItemInHand()->getEnchantmentLevel(Enchantment::LOOTING);
                if($level > 0){
                    return [Item::get(Item::STRING, 0, mt_rand(0, 1 + $level))];
                } else return [Item::get(Item::STRING, 0, 1)];
            }
        }
        return [Item::get(Item::STRING, 0, 1)];
    }
}