<?php
declare(strict_types=1);
namespace hcf\entity\entity;

use hcf\AlpinePlayer;
use pocketmine\item\{Item, enchantment\Enchantment};
use pocketmine\event\{EntityDamageByEntityEvent, EntityDamageEvent};

class Skeleton extends Undead {
    const NETWORK_ID = self::SKELETON;

    public $width = 0.6;
    public $height = 1.99;

    /**
     * @return string
     */
    public function getName(): string {
        return "Skeleton";
    }

    /**
     * @return array
     */
    public function getDrops(): array {
        $cause = $this->lastDamageCause;
        if($cause instanceof EntityDamageByEntityEvent){
            $damager = $cause->getDamager();
            if($damager instanceof AlpinePlayer){
                $level = $damager->getInventory()->getItemInHand()->getEnchantmentLevel(Enchantment::LOOTING);
                if($level > 0){
                    return [Item::get(Item::ARROW, 0, mt_rand(0, 1 + $level)), Item::get(Item::BONE, 0, mt_rand(0, 1 + $level))];
                } else return [Item::get(Item::ARROW, 0, mt_rand(1, 2)), Item::get(Item::BONE, 0, mt_rand(1, 2))];
            }
        }
        return [Item::get(Item::ARROW, 0, mt_rand(1, 2)), Item::get(Item::BONE, 0, mt_rand(1, 2))];
    }
}