<?php
declare(strict_types=1);
namespace hcf\entity;

use hcf\{AlpineCore, AlpinePlayer};

use pocketmine\item\Item;
use pocketmine\math\Vector3;
use pocketmine\level\Level;
use pocketmine\entity\Entity;
use pocketmine\block\BlockIds;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\entity\projectile\Throwable;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\utils\TextFormat as TF;
use pocketmine\level\sound\EndermanTeleportSound;

class BetterEnderPearl extends Throwable {

    const NETWORK_ID = self::ENDER_PEARL;

    public $width = 0.25;
    public $length = 0.25;
    public $height = 0.25;

    protected $gravity = 0.03;
    protected $drag = 0.01;

    private $hasTeleportedShooter = false;
    private $shootingEntity;
    private $last;

    /**
     * BetterEnderPearl constructor.
     *
     * @param Level $level
     * @param CompoundTag $nbt
     * @param Entity|null $shootingEntity
     */
    public function __construct(Level $level, CompoundTag $nbt, Entity $shootingEntity = null){
        parent::__construct($level, $nbt, $shootingEntity);
        $this->shootingEntity = $shootingEntity;
        $this->setLast(new Vector3(0, 0, 0));
        if($this->getPosition()->getLevel()->getBlockIdAt((int) $this->x, (int) $this->y, (int) $this->z) != 0){
            if($shootingEntity != null) $shootingEntity->teleport($shootingEntity);
            $this->flagForDespawn();
        }
     }

     /**
      *
      */
    public function teleportShooter() {
        if(AlpineCore::getFactionsManager()->isSpawnClaim($this->getPosition(), $this->getLevel())){
            $this->flagForDespawn();
            return;
        }
        if(!$this->hasTeleportedShooter){
            $this->hasTeleportedShooter = true;
            if($this->y > 0){
                $this->shootingEntity->getInventory()->removeItem(Item::get(Item::ENDER_PEARL, 0, 1));
                $this->shootingEntity->attack(new EntityDamageEvent($this->shootingEntity, EntityDamageEvent::CAUSE_FALL, 2));
                $this->shootingEntity->teleport($this->getLast());
                $this->shootingEntity->getLevel()->addSound(new EndermanTeleportSound($this->getPosition()->asVector3()), [$this->shootingEntity]);
                $this->flagForDespawn();
            }
            $this->flagForDespawn();
        }
    }

    /**
     * @return bool
     */
    public function isGoingToCollide(): bool {
        $x = $this->x - 1;
        for($x; $x < ($this->x + 1); ++$x){
            $z = $this->z - 1;
            for($z; $z < ($this->z + 1); ++ $z){
                $block = $this->getLevel()->getBlockAt((int) $x, (int) $this->y, (int) $z);
                if($block->getId() == BlockIds::WOODEN_SLAB || $block->getId() == BlockIds::STONE_SLAB || $block->getId() == BlockIds::CHEST){
                    return false;
                }
                if($block->isSolid()){
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * @param int $currentTick
     * @return bool
     */
    public function onUpdate(int $currentTick): bool {
        if($this->closed) return false;
        $this->checkLast();
        $this->timings->startTiming();
        $hasUpdate = parent::onUpdate($currentTick);
        if($this->isCollided){
            $this->teleportShooter();
            $hasUpdate = true;
        }
        $this->timings->stopTiming();
        return $hasUpdate;
    }

    public function checkLast() {
        $x = $this->getPosition()->getFloorX();
        $y = $this->getPosition()->getFloorY();
        $z = $this->getPosition()->getFloorZ();
        $new = $this->getPosition();
        if($new->distanceSquared($this->getLast()) > 1){
            $this->setLast(new Vector3($x, $y, $z));
        }
    }

    /**
     * @param Vector3 $last
     */
    public function setLast(Vector3 $last){
        $this->last = $last;
    }

    /**
     * @return Vector3
     */
    public function getLast(): Vector3 {
        return $this->last;
    }
}